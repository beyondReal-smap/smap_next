from flask import Flask, g, render_template, request, session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import datetime
from apscheduler.schedulers.background import BackgroundScheduler
import time
import json
import sys
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime as dt, timedelta
import os
import random

db = SQLAlchemy()
migrate = Migrate()

# 현재 스크립트 파일의 디렉토리 경로를 가져옵니다.
current_dir = os.path.dirname(os.path.abspath(__file__))

# 로그 디렉토리 설정 (현재 디렉토리에 'logs' 폴더 생성)
log_dir = os.path.join(current_dir, "logs")
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 로거 설정
logger = logging.getLogger("smap")
logger.setLevel(logging.DEBUG)

# 로그 파일 핸들러 설정
log_file = os.path.join(log_dir, "smap.log")
file_handler = RotatingFileHandler(log_file, maxBytes=10000000, backupCount=5)
file_handler.setLevel(logging.DEBUG)

# 로그 포맷 설정
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# 로거에 핸들러 추가
logger.addHandler(file_handler)


def create_app(config=None):
    # print("run SMAP : create_app()")
    logger.info("Application started")
    app = Flask(__name__)

    """Flask Configs"""
    from .configs import DevelopmentConfig, ProductionConfig

    if not config:
        if app.config["DEBUG"]:
            config = DevelopmentConfig()
        else:
            config = ProductionConfig()
    print("run with:", config)
    app.config.from_object(config)

    """SOCKETIO INIT"""
    # io.init_app(app, cors_allowed_origins="*")

    """CSRF INIT"""
    # csrf.init_app(app)

    """DB INIT"""
    db.init_app(app)
    if (app.config["SQLALCHEMY_DATABASE_URI"]).startswith("sqllite"):
        migrate.init_app(app, db, render_as_batch=True)
    else:
        migrate.init_app(app, db)

    """Routes INIT"""
    from smap.routes import base_route

    app.register_blueprint(base_route.bp)

    """Restx INIT"""
    from smap.apis import blueprint as api

    app.register_blueprint(api)

    """APScheduler INIT"""

    # 스케쥴 count 변경 함수
    def schedule_count_update(update_type, sst_idx, count):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                if count is None:
                    update_count = 1
                else:
                    update_count = int(count) + 1
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                if update_type == 1:
                    # 진입카운트 증가
                    schedule.sst_entry_cnt = update_count
                    db.session.commit()
                elif update_type == 2:
                    # 이탈카운트 증가
                    schedule.sst_exit_cnt = update_count
                    db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    # 스케쥴 위치값 변경 함수
    def schedule_status_update(sst_idx, sst_in_chk):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                schedule.sst_in_chk = sst_in_chk
                db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    def schedule_status_push_update(sst_idx, sst_schedule_chk):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                schedule.sst_schedule_chk = sst_schedule_chk
                db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    def location_status_update(slt_idx, slt_enter_chk):
        from smap.models import smap_location_t

        with app.app_context():
            try:
                location = smap_location_t.get_one_idx(slt_idx)
                if location:
                    location.slt_enter_chk = slt_enter_chk
                    location.slt_udate = dt.now()  # Use the alias dt
                    db.session.commit()
                    return True
                else:
                    print(f"Location with slt_idx {slt_idx} not found.")
                    return False
            except Exception as e:
                logger.error(e)
                return False

    # ------------------ 스케줄러 함수 ------------------
    # push err log 저장
    def push_err_log_add(plt_idx, pelt_err_title, pelt_err_msg, mt_id=None):
        from smap.models import push_err_log_t

        with app.app_context():
            try:
                now = dt.now()
                push_err_data = push_err_log_t.push_err_log_t(
                    mt_id=mt_id,
                    plt_idx=plt_idx,
                    pelt_err_title=pelt_err_title,
                    pelt_err_msg=pelt_err_msg,
                    pelt_wdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                )
                db.session.add(push_err_data)
                db.session.commit()
            except Exception as e:
                print("오류 저장 중 에러" + e)
        return 0

    # push log 저장 함수
    def push_log_add(
        mt_idx,
        sst_idx,
        plt_condition,
        plt_memo,
        plt_title,
        plt_content,
        push_result,
        push_json="",
    ):
        from smap.models import push_log_t
        from smap.models import member_t

        with app.app_context():
            try:
                now = dt.now()
                plt_status = 1
                if push_result["result"] == True:
                    plt_status = 2
                elif push_result["result"] == False:
                    plt_status = 4

                push_json_txt = ""
                if push_json != "":
                    push_json_txt = json.dumps(push_json)

                push_log_data = push_log_t.Push_log_t(
                    plt_type=2,
                    mt_idx=mt_idx,
                    sst_idx=sst_idx,
                    plt_condition=plt_condition,
                    plt_memo=plt_memo,
                    plt_title=plt_title,
                    plt_content=plt_content,
                    plt_sdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                    plt_status=plt_status,
                    plt_read_chk="N",
                    plt_show="Y",
                    plt_wdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                    push_json=push_json_txt,
                )
                db.session.add(push_log_data)
                db.session.commit()

                if push_result["result"] == False:
                    if mt_idx is None or mt_idx == "":
                        push_err_log_add(
                            push_log_data.plt_idx,
                            "push_log_add 오류",
                            push_result["msg"],
                            "멤버 없음",
                        )
                    else:
                        member_info = member_t.find_one_idx(mt_idx)
                        if not member_info is None:
                            push_err_log_add(
                                push_log_data.plt_idx,
                                "push_log_add 오류",
                                push_result["msg"],
                                member_info.mt_idx,
                            )
                        else:
                            push_err_log_add(
                                push_log_data.plt_idx,
                                "push_log_add 오류",
                                push_result["msg"],
                                "멤버 찾을 수 없음",
                            )
            except Exception as e:
                if mt_idx is None or mt_idx == "":
                    push_err_log_add(None, "push_log_add 오류", e)
                else:
                    member_info = member_t.find_one_idx(mt_idx)
                    if not member_info is None:
                        push_err_log_add(
                            None, "push_log_add 오류", e, member_info.mt_idx
                        )
                    else:
                        push_err_log_add(
                            None, "push_log_add 오류", e, "멤버 찾을 수 없음"
                        )
                logger.error(e)

    # 예약 push 상태와 일시 변경
    def loop_push_update(pft_idx, u_type):
        from smap.models import push_fcm_t

        with app.app_context():
            now = dt.now()
            fcm_info = push_fcm_t.find_idx_one(pft_idx)

            if not fcm_info is None:
                if u_type == 1:
                    # 발송 시작
                    fcm_info.pft_status = 2
                    fcm_info.pft_sdate = now
                else:
                    # 발송 종료
                    fcm_info.pft_status = 3
                    fcm_info.pft_edate = now
                db.session.commit()
                return True
            else:
                return False

    def set_push_message(recipient, member_name, title, arrival_messages, mt_lang):
        selected_message = random.choice(arrival_messages)

        if recipient == "member":
            name_prefix = ""
            good_news = ""
            current_location = txt_key_current_location[mt_lang]
            welcome = txt_key_welcome_member[mt_lang]
        else:
            name_prefix = f"{member_name}{txt_key_name_suffix[mt_lang]}"
            good_news = f"{txt_key_good_news[mt_lang]}{member_name}{txt_key_name_suffix[mt_lang]}"
            current_location = f"{txt_key_current_location_prefix[mt_lang]}{member_name}{txt_key_name_suffix[mt_lang]}"
            welcome = txt_key_welcome_others[mt_lang]

        push_title = selected_message["push_title"]
        push_content = selected_message["push_content"].format(
            name_prefix=name_prefix,
            title=title,
            good_news=good_news,
            current_location=current_location,
            welcome=welcome,
        )

        return push_title, push_content

    txt_key_current_location = {
        "ko": "현재 위치: ",
        "en": "Current location: ",
        "vi": "Vị trí hiện tại: ",
        "id": "Lokasi saat ini: ",
        "th": "สถานที่ปัจจุบัน: ",
        "ja": "現在の場所: ",
        "es": "Ubicación actual: ",
        "fr": "Emplacement actuel: ",
        "hi": "वर्तमान स्थान: "
    }

    txt_key_welcome_member = {
        "ko": "즐거운 시간 되세요! 👋",
        "en": "Have a great time! 👋",
        "vi": "Chúc bạn có một thời gian tuyệt vời! 👋",
        "id": "Semoga waktu yang menyenangkan! 👋",
        "th": "หวังว่าจะมีเวลาที่ดี! 👋",
        "ja": "楽しい時間を過ごしてください! 👋",
        "es": "¡Que lo pases bien! 👋",
        "fr": "Amusez-vous bien! 👋",
        "hi": "आनंददायक समय बिताएं! 👋"
    }

    txt_key_name_suffix = {
        "ko": "님이 ",
        "en": " has ",
        "vi": " đã ",
        "id": " telah ",
        "th": " ได้ ",
        "ja": "さんが ",
        "es": " ha ",
        "fr": " a ",
        "hi": " ने "
    }

    txt_key_good_news = {
        "ko": "좋은 소식! ",
        "en": "Good news! ",
        "vi": "Tin tốt! ",
        "id": "Kabar baik! ",
        "th": "ข่าวดี! ",
        "ja": "良いニュースです! ",
        "es": "¡Buenas noticias! ",
        "fr": "Bonne nouvelle! ",
        "hi": "अच्छी खबर! "
    }

    txt_key_current_location_prefix = {
        "ko": "님의 현재 위치: ",
        "en": "'s current location: ",
        "vi": "Vị trí hiện tại của ",
        "id": "Lokasi saat ini: ",
        "th": "สถานที่ปัจจุบันของ ",
        "ja": "さんの現在の場所: ",
        "es": "Ubicación actual de ",
        "fr": "Emplacement actuel de ",
        "hi": "का वर्तमान स्थान: "
    }

    txt_key_welcome_others = {
        "ko": "환영해주세요! 👋",
        "en": "Welcome them! 👋",
        "vi": "Chào đón họ! 👋",
        "id": "Sambut mereka! 👋",
        "th": "ต้อนรับพวกเขา! 👋",
        "ja": "歓迎しましょう! 👋",
        "es": "¡Denles la bienvenida! 👋",
        "fr": "Accueillez-les! 👋",
        "hi": "उनका स्वागत करें! 👋"
    }

    # 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때
    def ps_1():
        logger.info(f"ps_1 일정장소 시작")
        from smap.models import member_t
        from smap.models import push_log_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member

        txt_key_push_title_arrival = {
            "ko": "일정장소 도착알림 📍",
            "en": "Arrival at scheduled location 📍",
            "vi": "Đã đến địa điểm đã đặt 📍",
            "id": "Pemberitahuan kedatangan di lokasi terjadwal 📍",
            "th": "การแจ้งเตือนการมาถึงสถานที่ตามกำหนดการ 📍",
            "ja": "予定場所到着通知 📍",
            "es": "Notificación de llegada al lugar programado 📍",
            "fr": "Notification d'arrivée au lieu prévu 📍",
            "hi": "निर्धारित स्थान पर पहुंचने की सूचना 📍"
        }

        txt_key_push_content_arrival = {
            "ko": "{name_prefix}'{title}' 장소에 도착했어요! 🎉",
            "en": "{name_prefix} has arrived at '{title}'! 🎉",
            "vi": "{name_prefix} đã đến '{title}'! 🎉",
            "id": "{name_prefix} telah tiba di '{title}'! 🎉",
            "th": "{name_prefix} ได้มาถึง '{title}' แล้ว! 🎉",
            "ja": "{name_prefix}さんが'{title}'に到着しました! 🎉",
            "es": "{name_prefix} ha llegado a '{title}'! 🎉",
            "fr": "{name_prefix} est arrivé(e) à '{title}'! 🎉",
            "hi": "{name_prefix} '{title}' पर पहुंच गया/गई है! 🎉"
        }

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "일정에 입력한 장소의 100미터 반경에 들어왔을때"

            # 일정이 있는 100M 진입 전인 스케쥴 리스트
            push_list = smap_schedule_t.get_now_schedule_in_members()
            for pt in push_list:
                mt_idx = None
                sst_idx = pt.sst_idx

                if pt.sgt_idx is not None and pt.sgdt_idx != 0:
                    sgt_idx = str(pt.sgt_idx)

                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if group_member is not None:
                        mt_idx = str(group_member.mt_idx)

                if mt_idx is not None:
                    # 본인이 작성한 push 문시
                    if int(pt.mt_idx) != int(mt_idx):
                        try:
                            # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                            member_location = member_location_log_t.getDistance(
                                str(pt.sst_location_lat),
                                str(pt.sst_location_long),
                                mt_idx,
                            )
                            if member_location is not None:
                                distance = kmTom(member_location.distance)
                                formatted_distance = "{:,.1f}".format(distance)
                                push_json = {
                                    "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                    "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                    "distance": formatted_distance,
                                }
                                if 100.0 >= distance:
                                    logger.info(f"ps_1 일정장소 도착 - {pt.mt_idx}")
                                    if int(pt.sst_entry_cnt) == 0:
                                        group_data = get_group_member(sgt_idx, mt_idx)

                                        for recipient in ["order", "leader", "member"]:
                                            if group_data[recipient] != {}:
                                                if recipient in ["order", "leader"]:
                                                    if (
                                                        group_data[recipient]["mt_idx"] != group_data["member"]["mt_idx"]
                                                    ):
                                                        push_title = txt_key_push_title_arrival[group_data[recipient]["mt_lang"]]
                                                        push_content = txt_key_push_content_arrival[group_data[recipient]["mt_lang"]].format(
                                                            name_prefix=group_data["member"]["mt_name"],
                                                            title=pt.sst_title
                                                        )
                                                        group_data[recipient]["push_title"] = push_title
                                                        group_data[recipient]["push_content"] = push_content
                                                        group_data[recipient]["push_txt"] = push_content
                                                        group_data[recipient]["send"] = "Y"
                                                    else:
                                                        group_data[recipient]["send"] = "N"
                                                else:  # member
                                                    push_title = txt_key_push_title_arrival[group_data[recipient]["mt_lang"]]
                                                    push_content = txt_key_push_content_arrival[group_data[recipient]["mt_lang"]].format(
                                                        name_prefix="",
                                                        title=pt.sst_title
                                                    )
                                                    group_data[recipient]["push_title"] = push_title
                                                    group_data[recipient]["push_content"] = push_content
                                                    group_data[recipient]["push_txt"] = push_content
                                                    group_data[recipient]["send"] = "Y"
                                            else:
                                                group_data[recipient]["send"] = "N"

                                        # order가 member와 같을 때 leader에게 메시지를 보내지 않도록 처리
                                        if (
                                            group_data["order"] != {}
                                            and group_data["order"]["mt_idx"]
                                            == group_data["member"]["mt_idx"]
                                        ):
                                            group_data["leader"]["send"] = "N"

                                        for key, group in group_data.items():
                                            if group != "":
                                                if group["send"] == "Y":
                                                    push_result = send_push(
                                                        group["mt_token_id"],
                                                        group["push_title"],
                                                        group["push_content"],
                                                    )
                                                    push_log_add(
                                                        group["mt_idx"],
                                                        pt.sst_idx,
                                                        plt_condition,
                                                        plt_memo,
                                                        group["push_title"],
                                                        group["push_txt"],
                                                        push_result,
                                                        push_json,
                                                    )

                                        # 진입 여부 상태 수정
                                        schedule_result = schedule_status_update(
                                            sst_idx, "Y"
                                        )
                                        # 진입 발송 증가
                                        schedule_count_update(
                                            1, pt.sst_idx, pt.sst_entry_cnt
                                        )
                        except Exception as e:
                            if mt_idx is None or mt_idx == "":
                                push_err_log_add(
                                    None,
                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                    e,
                                    "멤버없음",
                                )
                            else:
                                member_info = member_t.find_one_idx(mt_idx)
                                if member_info is None:
                                    push_err_log_add(
                                        None,
                                        "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                        e,
                                        "멤버 찾을 수 없음",
                                    )
                                else:
                                    push_err_log_add(
                                        None,
                                        "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                        e,
                                        member_info.mt_idx,
                                    )
                            logger.error("[ps_1][" + member_info.mt_idx + "] - " + e)

                    else:
                        # 진입 여부 상태 수정
                        schedule_result = schedule_status_update(sst_idx, "Y")
                        # 진입 발송 증가
                        schedule_count_update(1, pt.sst_idx, pt.sst_entry_cnt)
            print("30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때")

    # 장소알림 - 일정에 입력한 장소의 100미터 반경에서 이탈했을때
    def ps_2():
        logger.info(f"ps_2 일정장소 출발 시작")
        import logging
        from smap.models import member_t
        from smap.models import push_log_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        # Configure logging
        logging.basicConfig(
            filename="error.log",
            level=logging.DEBUG,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

        # Define the messages list for departure
        txt_key_push_title_departure = {
            "ko": "일정장소 출발알림 👋",
            "en": "Departure from scheduled location 👋",
            "vi": "Đã rời khỏi địa điểm đã đặt 👋",
            "id": "Pemberitahuan keberangkatan dari lokasi terjadwal 👋",
            "th": "การแจ้งเตือนการออกจากสถานที่ตามกำหนดการ 👋",
            "ja": "予定場所出発通知 👋",
            "es": "Notificación de salida del lugar programado 👋",
            "fr": "Notification de départ du lieu prévu 👋",
            "hi": "निर्धारित स्थान से प्रस्थान की सूचना 👋"
        }

        txt_key_push_content_departure = {
            "ko": "{name_prefix}'{title}' 장소에서 출발했어요!",
            "en": "{name_prefix} has departed from '{title}'!",
            "vi": "{name_prefix} đã rời khỏi '{title}'!",
            "id": "{name_prefix} telah berangkat dari '{title}'!",
            "th": "{name_prefix} ได้ออกจาก '{title}' แล้ว!",
            "ja": "{name_prefix}さんが'{title}'を出発しました!",
            "es": "{name_prefix} ha salido de '{title}'!",
            "fr": "{name_prefix} est parti(e) de '{title}'!",
            "hi": "{name_prefix} '{title}' से प्रस्थान कर गया/गई है!"
        }

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "일정에 입력한 장소의 100미터 반경에서 이탈했을때"

            # 일정이 있는 50M 진입 후인 스케쥴 리스트
            push_list = smap_schedule_t.get_now_schedule_out_members()

            # Log the contents of push_list
            logging.debug("Push list contents: %s", push_list)

            for pt in push_list:
                logging.debug("pt list contents: %s", pt)
                mt_idx = None
                sst_idx = pt.sst_idx

                if not pt.sgt_idx is None and pt.sgdt_idx != 0:
                    sgt_idx = str(pt.sgt_idx)

                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if not group_member is None:
                        mt_idx = str(group_member.mt_idx)

                if not mt_idx is None:
                    if int(pt.mt_idx) != int(mt_idx):
                        # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                        member_location = member_location_log_t.getDistance(
                            str(pt.sst_location_lat), str(pt.sst_location_long), mt_idx
                        )
                        if not member_location is None:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)
                            push_json = {
                                "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                "distance": formatted_distance,
                            }
                            if 100.0 <= distance:
                                logger.info(f"ps_2 일정장소 출발 - {pt.mt_idx}")
                                try:
                                    logging.debug(
                                        f"pt.sst_exit_cnt : {pt.sst_exit_cnt} pt.sst_in_chk : {pt.sst_in_chk}"
                                    )
                                    if (
                                        int(pt.sst_exit_cnt) == 0
                                        and pt.sst_in_chk == "Y"
                                    ):
                                        # 그룹 정보 가져오기
                                        group_data = get_group_member(sgt_idx, mt_idx)

                                        if group_data["order"] != {}:
                                            # 오더전송
                                            if (
                                                group_data["order"]["mt_idx"]
                                                != group_data["member"]["mt_idx"]
                                            ):
                                                group_data["order"]["push_title"] = txt_key_push_title_departure[group_data["order"]["mt_lang"]]
                                                group_data["order"]["push_content"] = txt_key_push_content_departure[group_data["order"]["mt_lang"]].format(
                                                    name_prefix=group_data["member"]["mt_name"] + "님이 ",
                                                    title=str(pt.sst_title),
                                                )
                                                group_data["order"]["push_txt"] = group_data["order"]["push_content"]
                                                group_data["order"]["send"] = "Y"
                                            else:
                                                group_data["order"]["send"] = "N"
                                        else:
                                            group_data["order"]["send"] = "N"

                                        if group_data["leader"] != {}:
                                            # 리더전송
                                            if (
                                                group_data["order"]["mt_idx"]
                                                == group_data["member"]["mt_idx"]
                                            ):
                                                group_data["leader"]["send"] = "N"
                                            else:
                                                if (
                                                    group_data["leader"]["mt_idx"]
                                                    != group_data["member"]["mt_idx"]
                                                ):
                                                    group_data["leader"]["push_title"] = txt_key_push_title_departure[group_data["leader"]["mt_lang"]]
                                                    group_data["leader"]["push_content"] = txt_key_push_content_departure[group_data["leader"]["mt_lang"]].format(
                                                        name_prefix=group_data["member"]["mt_name"] + "님이 ",
                                                        title=str(pt.sst_title),
                                                    )
                                                    group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]
                                                    group_data["leader"]["send"] = "Y"
                                                else:
                                                    group_data["leader"]["send"] = "N"
                                        else:
                                            group_data["leader"]["send"] = "N"

                                        if group_data["member"] != {}:
                                            # 그룹원 전송
                                            group_data["member"]["push_title"] = txt_key_push_title_departure[group_data["member"]["mt_lang"]]
                                            group_data["member"]["push_content"] = txt_key_push_content_departure[group_data["member"]["mt_lang"]].format(
                                                name_prefix="", title=str(pt.sst_title)
                                            )
                                            group_data["member"]["push_txt"] = group_data["member"]["push_content"]
                                            group_data["member"]["send"] = "N"
                                        else:
                                            group_data["member"]["send"] = "N"

                                        for key, group in group_data.items():
                                            # #테스트
                                            # if group['mt_idx'] == 79 or group['mt_idx'] == 98 or group['mt_idx'] == 80:
                                            if group["send"] == "Y":
                                                push_result = send_push(
                                                    group["mt_token_id"],
                                                    group["push_title"],
                                                    group["push_content"],
                                                )
                                                push_log_add(
                                                    group["mt_idx"],
                                                    pt.sst_idx,
                                                    plt_condition,
                                                    plt_memo,
                                                    group["push_title"],
                                                    group["push_txt"],
                                                    push_result,
                                                    push_json,
                                                )

                                                logging.debug(
                                                    f"pt.sst_idx : {pt.sst_idx} "
                                                )
                                                # 진입 여부 상태 수정
                                                schedule_result = (
                                                    schedule_status_update(
                                                        pt.sst_idx, "N"
                                                    )
                                                )
                                                # 진입 카운트 증가
                                                schedule_count_update(
                                                    2, pt.sst_idx, pt.sst_exit_cnt
                                                )
                                    else:
                                        # 진입 여부 상태 수정
                                        schedule_result = schedule_status_update(
                                            pt.sst_idx, "N"
                                        )
                                        # 진입 카운트 증가
                                        schedule_count_update(
                                            2, pt.sst_idx, pt.sst_exit_cnt
                                        )
                                except Exception as e:
                                    try:
                                        if mt_idx is None or mt_idx == "":
                                            push_err_log_add(
                                                None,
                                                "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                e,
                                                "멤버 없음",
                                            )
                                        else:
                                            member_info = member_t.find_one_idx(mt_idx)
                                            if member_info is None:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                    e,
                                                    "멤버 찾을 수 없음",
                                                )
                                            else:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                    e,
                                                    member_info.mt_idx,
                                                )
                                        logger.error(
                                            "[ps_2]["
                                            + member_info.mt_idx
                                            + "] - "
                                            + str(e)
                                        )
                                        logging.error(
                                            "[ps_2] - Member ID: %s - Error: %s",
                                            (
                                                member_info.mt_idx
                                                if member_info
                                                else "Unknown"
                                            ),
                                            str(e),
                                        )
                                    except Exception as e:
                                        logging.error("Failed to log error: %s", str(e))

                    else:
                        # 진입 여부 상태 수정
                        schedule_result = schedule_status_update(pt.sst_idx, "N")
                        # 진입 카운트 증가
                        schedule_count_update(2, pt.sst_idx, pt.sst_exit_cnt)
            print("30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에서 이탈했을때")

    # 장소알림 - 내장소에 입력한 장소의 100미터 반경에 들어왔을때
    def ps_3():
        logger.info(f"ps_3 내장소 진입 시작")

        from smap.models import member_t
        from smap.models import smap_location_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import kmTom, send_push, get_group_member

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            push_list = smap_location_t.getInMyplaysList()
            logger.info(f"ps_3 push_list - {len(push_list)}")

            txt_key_push_title_arrival = {
                "ko": "내장소 방문알림 🚩",
                "en": "Arrival notification at my place 🚩",
                "vi": "Thông báo đến địa điểm của tôi 🚩",
                "id": "Pemberitahuan kedatangan di tempat saya 🚩",
                "th": "การแจ้งเตือนการมาถึงสถานที่ของฉัน 🚩",
                "ja": "私の場所への到着通知 🚩",
                "es": "Notificación de llegada a mi lugar 🚩",
                "fr": "Notification d'arrivée à mon endroit 🚩",
                "hi": "मेरे स्थान पर आगमन की सूचना 🚩"
            }

            txt_key_push_content_arrival = {
                "ko": "{name_prefix}님이 내장소 '{title}'에 방문했어요!",
                "en": "{name_prefix} has visited my place '{title}'!",
                "vi": "{name_prefix} đã đến '{title}' của tôi!",
                "id": "{name_prefix} telah mengunjungi tempat saya '{title}'!",
                "th": "{name_prefix} ได้มาที่สถานที่ของฉัน '{title}' แล้ว!",
                "ja": "{name_prefix}さんが私の場所'{title}'に来ました!",
                "es": "{name_prefix} ha visitado mi lugar '{title}'!",
                "fr": "{name_prefix} a visité mon endroit '{title}'!",
                "hi": "{name_prefix} मेरे स्थान '{title}' पर आया/आई है!"
            }

            for pt in push_list:
                try:  # 각 push_list 항목 처리를 try-except 블록으로 감쌈
                    # logger.info(f"ps_3 내장소 방문 - {pt.mt_idx} / {pt.slt_lat} / {pt.slt_long}")
                    # logger.info(f'ps_3 pt value: {pt}')

                    if pt is not None:
                        # logger.info(f'ps_3 pt is not None: {pt} / pt.insert_mt_idx : {pt.insert_mt_idx} / pt.mt_idx : {pt.mt_idx} / pt.slt_enter_alarm : {pt.slt_enter_alarm.value}')
                        # 본인이 등록한 내장소 push 무시
                        # if pt.insert_mt_idx != pt.mt_idx:
                        # logger.info(f"ps_3 내장소 방문 - slt_enter_alarm : {pt.slt_enter_alarm}")
                        if pt.slt_enter_alarm == "Y":
                            # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                            logger.info(
                                f"ps_3 내장소 방문 - slt_lat : {pt.slt_lat} / slt_long : {pt.slt_long} / mt_idx : {pt.mt_idx}"
                            )
                            member_location = member_location_log_t.getDistance(
                                str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx)
                            )

                            logger.info(
                                f"ps_3 내장소 방문 거리 - {kmTom(member_location.distance)}"
                            )

                            if member_location is not None:
                                distance = kmTom(member_location.distance)
                                formatted_distance = "{:,.1f}".format(distance)
                                push_json = {
                                    "lat": "{:.7f}".format(float(pt.slt_lat)),
                                    "lng": "{:.7f}".format(float(pt.slt_long)),
                                    "distance": str(formatted_distance),
                                }
                                # 마지막 위치 시간과 현재 시간의 차이 계산
                                last_location_time = member_location.mlt_gps_time
                                current_time = dt.now()
                                time_difference = current_time - last_location_time
                                logger.info(
                                    f"ps_3 내장소 방문 - time_difference : {time_difference}"
                                )
                                logger.info(
                                    f"ps_3 내장소 방문 - distance : {distance} / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work}"
                                )

                                if 100.0 >= distance:
                                    try:
                                        # 속도가 1이상이거나 이전보다 걸음수가 오른 경우
                                        b_member_lotacion = (
                                            member_location_log_t.find_last2_mt_idx(
                                                pt.mt_idx
                                            )
                                        )
                                        if not b_member_lotacion is None:
                                            if (
                                                member_location.mlt_speed > float(1)
                                            ) or (
                                                member_location.mt_health_work
                                                > b_member_lotacion.mt_health_work
                                            ):
                                                group_detail = (
                                                    smap_group_detail_t.get_one_idx(
                                                        pt.sgdt_idx
                                                    )
                                                )
                                                # 장소 정보 가져오기
                                                location_detail = (
                                                    smap_location_t.get_one_idx(
                                                        pt.slt_idx
                                                    )
                                                )

                                                if not group_detail is None:
                                                    group_data = get_group_member(
                                                        group_detail.sgt_idx, pt.mt_idx
                                                    )
                                                    if group_data["order"] != {}:
                                                        group_data["order"]["push_title"] = txt_key_push_title_arrival[group_data["order"]["mt_lang"]]
                                                        group_data["order"]["push_content"] = txt_key_push_content_arrival[group_data["order"]["mt_lang"]].format(
                                                            name_prefix=group_data["member"]["mt_name"],
                                                            title=str(location_detail.slt_title)
                                                        )
                                                        group_data["order"]["push_txt"] = group_data["order"]["push_content"]

                                                        # 오너가 등록한 경우 오너에서 push send
                                                        group_data["order"]["send"] = "Y" if pt.insert_mt_idx == group_data["order"]["mt_idx"] else "N"

                                                    else:
                                                        group_data["order"]["send"] = "N"

                                                    if group_data["leader"] != {}:
                                                        group_data["leader"]["push_title"] = txt_key_push_title_arrival[group_data["leader"]["mt_lang"]]
                                                        group_data["leader"]["push_content"] = txt_key_push_content_arrival[group_data["leader"]["mt_lang"]].format(
                                                            name_prefix=group_data["member"]["mt_name"],
                                                            title=str(location_detail.slt_title)
                                                        )
                                                        group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]

                                                        # 리더가 등록한 경우 리더에거 push send
                                                        group_data["leader"]["send"] = "Y" if pt.insert_mt_idx == group_data["leader"]["mt_idx"] else "N"

                                                    else:
                                                        group_data["leader"]["send"] = "N"

                                                    for key, group in group_data.items():
                                                        if group != "" and key != "member":
                                                            if group["send"] == "Y":
                                                                push_result = send_push(
                                                                    group["mt_token_id"],
                                                                    group["push_title"],
                                                                    group["push_content"],
                                                                )
                                                                push_log_add(
                                                                    group["mt_idx"],
                                                                    pt.slt_idx,
                                                                    plt_condition,
                                                                    plt_memo,
                                                                    group["push_title"],
                                                                    group["push_txt"],
                                                                    push_result,
                                                                )

                                                    # 진입여부 수정
                                                    location_result = (
                                                        location_status_update(
                                                            pt.slt_idx, "Y"
                                                        )
                                                    )
                                    except Exception as e:
                                        if pt.mt_idx is None or pt.mt_idx == "":
                                            push_err_log_add(
                                                None,
                                                "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                e,
                                                "멤버 없음",
                                            )
                                        else:
                                            member_info = member_t.find_one_idx(
                                                pt.mt_idx
                                            )
                                            if member_info is None:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                    e,
                                                    "멤버 찾을 수 없음",
                                                )
                                            else:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                    e,
                                                    member_info.mt_id,
                                                )
                                        print(e)
                                        pass

                        # else:
                        #     logger.info(f"ps_3 내장소 방문 - 입력한 사람과 대상이 같아. mt_idx : {pt.mt_idx}")
                except Exception as e:  # 예외 발생 시 에러 로깅 및 처리
                    logger.error(f"ps_3 내장소 처리 중 오류 발생: {e}")
                    print(f"ps_3 내장소 처리 중 오류 발생: {e}")
                    # 필요에 따라 추가적인 오류 처리 로직 추가 가능

            print("30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때")

    # 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때
    def ps_4():
        logger.info("ps_4 내장소 이탈 시작")
        from smap.models import (
            member_t,
            smap_location_t,
            smap_group_detail_t,
            member_location_log_t,
        )
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import datetime

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            push_list = smap_location_t.getOutMyplaysList()

            txt_key_push_title_exit = {
                "ko": "내장소 이탈알림 🚀",
                "en": "Notification of leaving my place 🚀",
                "vi": "Thông báo rời khỏi địa điểm của tôi 🚀",
                "id": "Pemberitahuan meninggalkan tempat saya 🚀",
                "th": "การแจ้งเตือนออกจากสถานที่ของฉัน 🚀",
                "ja": "私の場所を離れた通知 🚀",
                "es": "Notificación de salida de mi lugar 🚀",
                "fr": "Notification de départ de mon endroit 🚀",
                "hi": "मेरे स्थान से निकलने की सूचना 🚀"
            }

            txt_key_push_content_exit = {
                "ko": "{name_prefix}님이 내장소 '{title}'에서 이탈했어요!",
                "en": "{name_prefix} has left my place '{title}'!",
                "vi": "{name_prefix} đã rời khỏi '{title}' của tôi!",
                "id": "{name_prefix} telah meninggalkan tempat saya '{title}'!",
                "th": "{name_prefix} ได้ออกจากสถานที่ของฉัน '{title}' แล้ว!",
                "ja": "{name_prefix}さんが私の場所'{title}'を離れました!",
                "es": "{name_prefix} ha salido de mi lugar '{title}'!",
                "fr": "{name_prefix} a quitté mon endroit '{title}'!",
                "hi": "{name_prefix} मेरे स्थान '{title}' से निकल गया/गई है!"
            }

            for pt in push_list:
                logger.info(
                    f"ps_4 내장소 이탈 - {pt.mt_idx} / {pt.slt_lat} / {pt.slt_long} / {pt.mt_idx}"
                )
                logger.info(pt)

                if pt is not None:
                    # 본인이 등록한 내장소 push 무시
                    if pt.slt_enter_alarm == "Y":
                        logger.info(
                            f"ps_4 내장소 이탈 - slt_lat : {pt.slt_lat} / slt_long : {pt.slt_long} / mt_idx : {pt.mt_idx}"
                        )
                        member_location = member_location_log_t.getDistance(
                            str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx)
                        )

                        if member_location is not None:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)

                            push_json = {
                                "lat": "{:.7f}".format(float(pt.slt_lat)),
                                "lng": "{:.7f}".format(float(pt.slt_long)),
                                "distance": str(formatted_distance),
                            }

                            last_location_time = member_location.mlt_gps_time
                            current_time = dt.now()
                            time_difference = current_time - last_location_time

                            logger.info(
                                f"ps_4 내장소 이탈 - distance : {distance} / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work}"
                            )

                            if distance >= 100.0:
                                try:
                                    b_member_location = (
                                        member_location_log_t.find_last2_mt_idx(
                                            pt.mt_idx
                                        )
                                    )
                                    logger.info(
                                        f"ps_4 내장소 이탈 - b_member_location not None / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work} / b_member_location.mt_health_work : {b_member_location.mt_health_work}"
                                    )

                                    if b_member_location is not None:
                                        if (member_location.mlt_speed > float(1)) or (
                                            member_location.mt_health_work
                                            > b_member_location.mt_health_work
                                        ):
                                            group_detail = (
                                                smap_group_detail_t.get_one_idx(
                                                    pt.sgdt_idx
                                                )
                                            )
                                            location_detail = (
                                                smap_location_t.get_one_idx(pt.slt_idx)
                                            )

                                            if group_detail is not None:
                                                group_data = get_group_member(
                                                    group_detail.sgt_idx, pt.mt_idx
                                                )
                                                if group_data["order"]:
                                                    group_data["order"][
                                                        "push_title"
                                                    ] = txt_key_push_title_exit[group_data["order"]["mt_lang"]]
                                                    group_data["order"][
                                                        "push_content"
                                                    ] = txt_key_push_content_exit[group_data["order"]["mt_lang"]].format(
                                                        name_prefix=group_data["member"]["mt_name"],
                                                        title=str(location_detail.slt_title)
                                                    )
                                                    group_data["order"]["push_txt"] = (
                                                        group_data["order"][
                                                            "push_content"
                                                        ]
                                                    )
                                                    group_data["order"]["send"] = "Y"
                                                else:
                                                    group_data["order"]["send"] = "N"

                                                if group_data["leader"]:
                                                    group_data["leader"][
                                                        "push_title"
                                                    ] = txt_key_push_title_exit[group_data["leader"]["mt_lang"]]
                                                    group_data["leader"][
                                                        "push_content"
                                                    ] = txt_key_push_content_exit[group_data["leader"]["mt_lang"]].format(
                                                        name_prefix=group_data["member"]["mt_name"],
                                                        title=str(location_detail.slt_title)
                                                    )
                                                    group_data["leader"]["push_txt"] = (
                                                        group_data["leader"][
                                                            "push_content"
                                                        ]
                                                    )

                                                    # 리더가 등록한 경우 리더에거 push send
                                                    if (
                                                        pt.insert_mt_idx
                                                        == group_data["leader"][
                                                            "mt_idx"
                                                        ]
                                                    ):
                                                        group_data["leader"][
                                                            "send"
                                                        ] = "Y"
                                                    else:
                                                        group_data["leader"]["send"] = "N"
                                                else:
                                                    group_data["leader"]["send"] = "N"

                                                for key, group in group_data.items():
                                                    if group and key != "member":
                                                        if group["send"] == "Y":
                                                            push_result = send_push(
                                                                group["mt_token_id"],
                                                                group["push_title"],
                                                                group["push_content"],
                                                            )
                                                            push_log_add(
                                                                group["mt_idx"],
                                                                pt.slt_idx,
                                                                plt_condition,
                                                                plt_memo,
                                                                group["push_title"],
                                                                group["push_txt"],
                                                                push_result,
                                                                push_json,
                                                            )

                                            # 진입여부 수정
                                            location_result = location_status_update(
                                                pt.slt_idx, "N"
                                            )
                                except Exception as e:
                                    member_info = (
                                        member_t.find_one_idx(pt.mt_idx)
                                        if pt.mt_idx
                                        else None
                                    )

                                    if member_info is None:
                                        push_err_log_add(
                                            None,
                                            "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때 오류",
                                            e,
                                            "멤버 없음",
                                        )
                                    else:
                                        push_err_log_add(
                                            None,
                                            "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때 오류",
                                            e,
                                            member_info.mt_idx,
                                        )
                                    logger.error(
                                        f'[ps_4][{member_info.mt_idx if member_info else "None"}] - {e}'
                                    )
            print(
                "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            )

    # 일정알림 - 일정에 입력한 알림주기에 알림
    def ps_5():
        logger.info(f"ps_5 일정알림 시작")
        from smap.models import member_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push, get_group_member

        with app.app_context():
            plt_condition = "1분 - 일정알림"
            plt_memo = "일정에 입력한 알림주기에 알림"
            sst_pick_type_arr = {"minute": "분", "hour": "시간", "day": "일"}
            
            txt_key_push_title = {
                    "ko": "일정 시작알림 ⏰",
                    "en": "Schedule start notification ⏰",
                    "vi": "Thông báo bắt đầu lịch trình ⏰",
                    "id": "Pemberitahuan mulai jadwal ⏰",
                    "th": "การแจ้งเตือนเริ่มตารางเวลา ⏰",
                    "ja": "スケジュール開始通知 ⏰",
                    "es": "Notificación de inicio de programación ⏰",
                    "fr": "Notification de début de calendrier ⏰",
                    "hi": "अनुसूची शुरू होने की सूचना ⏰"
                }

            txt_key_push_content = {
                "ko": "'{title}' 일정 {pick_result}{pick_type} 전 입니다.",
                "en": "It's {pick_result} {pick_type} before the '{title}' schedule.",
                "vi": "Còn {pick_result} {pick_type} trước lịch trình '{title}'.",
                "id": "Ini {pick_result} {pick_type} sebelum jadwal '{title}'.",
                "th": "เหลือ {pick_result} {pick_type} ก่อนตารางเวลา '{title}'",
                "ja": "'{title}'のスケジュールまで{pick_result} {pick_type}前です。",
                "es": "Faltan {pick_result} {pick_type} antes del horario '{title}'.",
                "fr": "Il reste {pick_result} {pick_type} avant le calendrier '{title}'.",
                "hi": "'{title}' अनुसूची से पहले {pick_result} {pick_type} बचे हैं।"
            }

            push_list = smap_schedule_t.get_now_schedule_push()
            for pt in push_list:
                puth_type = 1  # 1개인 2 그룹
                mt_idx = None
                if pt.sgt_idx is None and pt.sgdt_idx == 0:
                    puth_type = 1
                    mt_idx = str(pt.mt_idx)
                else:
                    puth_type = 2
                    sgt_idx = str(pt.sgt_idx)
                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if not group_member is None:
                        mt_idx = str(group_member.mt_idx)

                if not mt_idx is None:
                    try:
                        logger.info(f"ps_5 일정알림 - {pt.mt_idx}")
                        if puth_type == 1:
                            # 본인의 정보가져오기
                            member = member_t.find_one_idx(mt_idx)
                            mt_name = member.mt_name
                            if (
                                not member.mt_nickname is None
                                and member.mt_nickname != ""
                            ):
                                mt_name = member.mt_nickname


                            push_title = txt_key_push_title[member.mt_lang]
                            push_content = txt_key_push_content[member.mt_lang].format(
                                title=str(pt.sst_title),
                                pick_result=str(pt.sst_pick_result),
                                pick_type=sst_pick_type_arr[pt.sst_pick_type]
                            )
                            push_txt = push_content
                            push_result = send_push(
                                member.mt_token_id, push_title, push_content
                            )
                            push_log_add(
                                member.mt_idx,
                                pt.sst_idx,
                                plt_condition,
                                plt_memo,
                                push_title,
                                push_txt,
                                push_result,
                            )

                            schedule_status_push_update(pt.sst_idx, "Y")
                        else:
                            # 그룹
                            group_data = get_group_member(sgt_idx, mt_idx)
                            if group_data["order"] != {}:
                                # 오더전송
                                if (
                                    group_data["order"]["mt_idx"]
                                    != group_data["member"]["mt_idx"]
                                ):
                                    group_data["order"]["push_title"] = txt_key_push_title[group_data["order"]["mt_lang"]]
                                    group_data["order"]["push_content"] = txt_key_push_content[group_data["order"]["mt_lang"]].format(
                                        name_prefix=group_data["member"]["mt_name"] + "님의",
                                        title=str(pt.sst_title),
                                        pick_result=str(pt.sst_pick_result),
                                        pick_type=sst_pick_type_arr[pt.sst_pick_type]
                                    )
                                    group_data["order"]["push_txt"] = group_data["order"]["push_content"]
                                    group_data["order"]["send"] = "Y"
                                else:
                                    group_data["order"]["send"] = "N"

                            if group_data["leader"] != {}:
                                # 리더전송
                                if (
                                    group_data["order"]["mt_idx"]
                                    == group_data["member"]["mt_idx"]
                                ):
                                    group_data["leader"]["send"] = "N"
                                else:
                                    if (
                                        group_data["leader"]["mt_idx"]
                                        != group_data["member"]["mt_idx"]
                                    ):
                                        group_data["leader"]["push_title"] = txt_key_push_title[group_data["leader"]["mt_lang"]]
                                        group_data["leader"]["push_content"] = txt_key_push_content[group_data["leader"]["mt_lang"]].format(
                                            name_prefix=group_data["member"]["mt_name"] + "님의",
                                            title=str(pt.sst_title),
                                            pick_result=str(pt.sst_pick_result),
                                            pick_type=sst_pick_type_arr[pt.sst_pick_type]
                                        )
                                        group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]
                                        group_data["leader"]["send"] = "Y"
                                    else:
                                        group_data["leader"]["send"] = "N"
                            else:
                                group_data["leader"]["send"] = "N"

                            if group_data["member"] != {}:
                                group_data["member"]["push_title"] = txt_key_push_title[group_data["member"]["mt_lang"]]
                                group_data["member"]["push_content"] = txt_key_push_content[group_data["member"]["mt_lang"]].format(
                                    title=str(pt.sst_title),
                                    pick_result=str(pt.sst_pick_result),
                                    pick_type=sst_pick_type_arr[pt.sst_pick_type]
                                )
                                group_data["member"]["push_txt"] = group_data["member"]["push_content"]
                                group_data["member"]["send"] = "Y"
                            else:
                                group_data["member"]["send"] = "N"

                            for key, group in group_data.items():
                                if group != "":
                                    if group["send"] == "Y":
                                        push_result = send_push(
                                            group["mt_token_id"],
                                            group["push_title"],
                                            group["push_content"],
                                        )
                                        push_log_add(
                                            group["mt_idx"],
                                            pt.sst_idx,
                                            plt_condition,
                                            plt_memo,
                                            group["push_title"],
                                            group["push_txt"],
                                            push_result,
                                        )
                            schedule_status_push_update(pt.sst_idx, "Y")
                    except Exception as e:
                        if mt_idx is None or mt_idx == "":
                            push_err_log_add(
                                None,
                                "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_5][" + member_info.mt_idx + "] - " + e)
            print("1분 - 일정알림 - 일정에 입력한 알림주기에 알림")

    def ps_6():
        logger.info(f"ps_6 일정출발 알림 시작")
        from smap.models import member_t
        from smap.models import smap_schedule_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import kmTom, get_group_member, send_push

        with app.app_context():
            plt_condition = "5분 - 장소+일정알림"
            plt_memo = "일정 시작 30분 전 움직임이 없을 경우"
            push_list = smap_schedule_t.start_befor30()
            
            txt_key_push_title = {
                "ko": "일정 이동알림 🔔",
                "en": "Schedule movement notification 🔔",
                "vi": "Thông báo di chuyển lịch trình 🔔",
                "id": "Pemberitahuan pergerakan jadwal 🔔",
                "th": "การแจ้งเตือนการเคลื่อนไหวของตารางเวลา 🔔",
                "ja": "スケジュール移動通知 🔔",
                "es": "Notificación de movimiento de programación 🔔",
                "fr": "Notification de mouvement de calendrier 🔔",
                "hi": "अनुसूची गतिविधि की सूचना 🔔"
            }

            txt_key_push_content = {
                "ko": "{name_prefix}님이 다음 '{title}' 일정을 위해서 이동을 시작해야할 시간이에요.",
                "en": "{name_prefix} needs to start moving for the next '{title}' schedule.",
                "vi": "{name_prefix} cần bắt đầu di chuyển cho lịch trình '{title}' tiếp theo.",
                "id": "{name_prefix} perlu mulai bergerak untuk jadwal '{title}' berikutnya.",
                "th": "{name_prefix} ต้องเริ่มเคลื่อนไหวสำหรับตารางเวลา '{title}' ถัดไป",
                "ja": "{name_prefix}さんは次の'{title}'のスケジュールのために移動を開始する必要があります。",
                "es": "{name_prefix} necesita comenzar a moverse para el próximo horario '{title}'.",
                "fr": "{name_prefix} doit commencer à se déplacer pour le prochain calendrier '{title}'.",
                "hi": "{name_prefix} को अगली '{title}' अनुसूची के लिए चलना शुरू करना होगा।"
            }

            for pt in push_list:
                member_location = member_location_log_t.getDistance(
                    str(pt.sst_location_lat), str(pt.sst_location_long), str(pt.mt_idx)
                )

                if member_location is not None:                    
                    # 현재 시간을 가져옵니다.
                    current_time = dt.now()

                    # member_location에는 mlt_gps_time이 있을 것이므로 이를 datetime 객체로 변환합니다.
                    mlt_gps_time = dt.strptime(
                        member_location["mlt_gps_time"], "%Y-%m-%d %H:%M:%S"
                    )

                    # 현재 시간과 mlt_gps_time의 차이를 계산합니다.
                    time_difference = current_time - mlt_gps_time

                    if time_difference <= timedelta(minutes=35):
                        try:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)
                            push_json = {
                                "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                "distance": str(formatted_distance),
                            }

                            if 500.0 < distance:
                                logger.info(f"ps_6 일정출발 알림 - {pt.mt_idx}")
                                group_data = get_group_member(pt.sgt_idx, pt.mt_idx)

                                if group_data["order"] != {}:
                                    if group_data["order"]["mt_idx"] != group_data["member"]["mt_idx"]:
                                        group_data["order"]["push_title"] = txt_key_push_title[group_data["order"]["mt_lang"]]
                                        group_data["order"]["push_content"] = txt_key_push_content[group_data["order"]["mt_lang"]].format(
                                            name_prefix=group_data["member"]["mt_name"] + "님이",
                                            title=str(pt.sst_title)
                                        )
                                        group_data["order"]["push_txt"] = group_data["order"]["push_content"]
                                        group_data["order"]["send"] = "Y"
                                    else:
                                        group_data["order"]["send"] = "N"
                                else:
                                    group_data["order"]["send"] = "N"

                                if group_data["leader"] != {}:
                                    if group_data["order"]["mt_idx"] == group_data["member"]["mt_idx"]:
                                        group_data["leader"]["send"] = "N"
                                    else:
                                        if group_data["leader"]["mt_idx"] != group_data["member"]["mt_idx"]:
                                            group_data["leader"]["push_title"] = txt_key_push_title[group_data["leader"]["mt_lang"]]
                                            group_data["leader"]["push_content"] = txt_key_push_content[group_data["leader"]["mt_lang"]].format(
                                                name_prefix=group_data["member"]["mt_name"] + "님이",
                                                title=str(pt.sst_title)
                                            )
                                            group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]
                                            group_data["leader"]["send"] = "Y"
                                        else:
                                            group_data["leader"]["send"] = "N"
                                else:
                                    group_data["leader"]["send"] = "N"

                                if group_data["member"] != {}:
                                    group_data["member"]["push_title"] = txt_key_push_title[group_data["member"]["mt_lang"]]
                                    group_data["member"]["push_content"] = txt_key_push_content[group_data["member"]["mt_lang"]].format(
                                        name_prefix="",
                                        title=str(pt.sst_title)
                                    )
                                    group_data["member"]["push_txt"] = group_data["member"]["push_content"]
                                    group_data["member"]["send"] = "Y"
                                else:
                                    group_data["member"]["send"] = "N"

                                for key, group in group_data.items():
                                    if group != "":
                                        if group["send"] == "Y":
                                            push_result = send_push(
                                                group["mt_token_id"],
                                                group["push_title"],
                                                group["push_content"],
                                            )
                                            push_log_add(
                                                group["mt_idx"],
                                                pt.sst_idx,
                                                plt_condition,
                                                plt_memo,
                                                group["push_title"],
                                                group["push_txt"],
                                                push_result,
                                                push_json,
                                            )
                        except Exception as e:
                            if pt.mt_idx is None or pt.mt_idx == "":
                                push_err_log_add(
                                    None,
                                    "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                    e,
                                    "멤버 없음",
                                    )
                            else:
                                member_info = member_t.find_one_idx(pt.mt_idx)
                                if member_info is None:
                                    push_err_log_add(
                                            None,
                                            "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                            e,
                                            "멤버 찾을 수 없음",
                                        )
                                else:
                                    push_err_log_add(
                                        None,
                                        "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                        e,
                                        member_info.mt_idx,
                                        )
                            logger.error(f"[ps_6][{member_info.mt_idx}] - {e}")

            print("5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우")

    # 구독 - 가입 후 3일 남음
    def ps_7():
        import datetime
        from smap.models import member_t
        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "오전 10시 = 구독"
            plt_memo = "가입 후 11일 경과"
            after_3_day = dt.now() + timedelta(days=3)
            after_3_day_s = {
                "ko": after_3_day.strftime("%m월%d일"),
                "en": after_3_day.strftime("%B %d"),
                "vi": after_3_day.strftime("%d tháng %m"),
                "id": after_3_day.strftime("%d %B"),
                "th": after_3_day.strftime("%d %B"),
                "ja": after_3_day.strftime("%m月%d日"),
                "es": after_3_day.strftime("%d de %B"),
                "fr": after_3_day.strftime("%d %B"),
                "hi": after_3_day.strftime("%d %B")
            }
            
            txt_key_push_title = {
                "ko": "서비스 안내 🧾",
                "en": "Service Information 🧾",
                "vi": "Thông tin dịch vụ 🧾",
                "id": "Informasi Layanan 🧾",
                "th": "ข้อมูลบริการ 🧾",
                "ja": "サービス情報 🧾",
                "es": "Información del servicio 🧾",
                "fr": "Informations sur le service 🧾",
                "hi": "सेवा जानकारी 🧾"
            }

            txt_key_push_content = {
                "ko": "안녕하세요, {name_prefix} 님!\nSMAP Pro 서비스 구독 기간이 곧 종료될 예정이에요.\n{after_3_day_s}부터는 Basic 서비스로 전환됩니다.\n감사합니다!",
                "en": "Hello, {name_prefix}!\nYour SMAP Pro service subscription period is about to expire.\nFrom {after_3_day_s}, it will be converted to the Basic service.\nThank you!",
                "vi": "Xin chào, {name_prefix}!\nThời hạn đăng ký dịch vụ SMAP Pro của bạn sắp hết hạn.\nTừ {after_3_day_s}, nó sẽ được chuyển đổi sang dịch vụ Cơ bản.\nCảm ơn bạn!",
                "id": "Halo, {name_prefix}!\nPeriode langganan layanan SMAP Pro Anda segera berakhir.\nDari {after_3_day_s}, akan dikonversi ke layanan Dasar.\nTerima kasih!",
                "th": "สวัสดี {name_prefix}!\nระยะเวลาการสมัครใช้บริการ SMAP Pro ของคุณกำลังจะหมดอายุ\nตั้งแต่ {after_3_day_s} จะถูกแปลงเป็นบริการพื้นฐาน\nขอบคุณ!",
                "ja": "こんにちは、{name_prefix}さん!\nSMAP Proサービスの契約期間が間もなく終了します。\n{after_3_day_s}からBasicサービスに切り替わります。\nありがとうございました!",
                "es": "¡Hola, {name_prefix}!\nEl período de suscripción al servicio SMAP Pro está a punto de expirar.\nA partir de {after_3_day_s}, se convertirá al servicio Básico.\n¡Gracias!",
                "fr": "Bonjour, {name_prefix} !\nVotre période d'abonnement au service SMAP Pro est sur le point d'expirer.\nÀ partir du {after_3_day_s}, il sera converti en service de base.\nMerci !",
                "hi": "नमस्ते, {name_prefix}!\nआपकी SMAP Pro सेवा सदस्यता अवधि समाप्त होने वाली है।\n{after_3_day_s} से, यह बेसिक सेवा में बदल जाएगी।\nधन्यवाद!"
            }

            # 구독하지 않은 오더 list
            push_list = member_t.getNotJoinGroup3()
            for pt in push_list:
                if pt.sgdt_owner_chk == "Y":
                    try:
                        mt_name = pt.mt_name
                        if not pt.mt_nickname is None and pt.mt_nickname != "":
                            mt_name = pt.mt_nickname

                        push_content = txt_key_push_content[pt.mt_lang].format(name_prefix=mt_name, after_3_day_s=after_3_day_s)
                        push_txt = push_content
                        push_result = send_push(pt.mt_token_id, txt_key_push_title[pt.mt_lang], push_content)
                        push_log_add(pt.mt_idx, None, plt_condition, plt_memo, txt_key_push_title[pt.mt_lang], push_txt, push_result)
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, "멤버 없음")
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, "멤버 찾을 수 없음")
                            else:
                                push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, member_info.mt_idx)
                        logger.error("[ps_7][" + str(pt.mt_idx) + "] - " + str(e))
            print("오전 10시 - 구독 - 가입 후 11일 경과")

    # 구독 - 가입 후 13일 경과
    def ps_8():
        from smap.models import member_t
        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "오전 10시 = 구독"
            plt_memo = "가입 후 11일 경과"
            
            txt_key_push_title = {
                "ko": "서비스 안내 🧾",
                "en": "Service Information 🧾",
                "vi": "Thông tin dịch vụ 🧾",
                "id": "Informasi Layanan 🧾",
                "th": "ข้อมูลบริการ 🧾",
                "ja": "サービス情報 🧾",
                "es": "Información del servicio 🧾",
                "fr": "Informations sur le service 🧾",
                "hi": "सेवा जानकारी 🧾"
            }

            txt_key_push_content = {
                "ko": "안녕하세요, {name_prefix} 님! \n내일부터 내장소 입력이 2개로 제한되고, 일부 광고가 표시될 예정입니다.",
                "en": "Hello, {name_prefix}!\nStarting tomorrow, the number of 'My Places' entries will be limited to 2, and some ads will be displayed.",
                "vi": "Xin chào, {name_prefix}!\nBắt đầu từ ngày mai, số lượng nhập 'Địa điểm của tôi' sẽ bị giới hạn là 2 và một số quảng cáo sẽ được hiển thị.",
                "id": "Halo, {name_prefix}!\nMulai besok, jumlah entri 'Tempat Saya' akan dibatasi menjadi 2, dan beberapa iklan akan ditampilkan.",
                "th": "สวัสดี {name_prefix}!\nตั้งแต่พรุ่งนี้เป็นต้นไป จำนวนรายการ 'สถานที่ของฉัน' จะถูกจำกัดเพียง 2 รายการ และจะมีการแสดงโฆษณาบางส่วน",
                "ja": "こんにちは、{name_prefix}さん!\n明日から「マイプレイス」の入力が2件に制限され、一部の広告が表示されます。",
                "es": "¡Hola, {name_prefix}!\nA partir de mañana, el número de entradas de 'Mis Lugares' se limitará a 2 y se mostrarán algunos anuncios.",
                "fr": "Bonjour, {name_prefix} !\nÀ partir de demain, le nombre d'entrées 'Mes lieux' sera limité à 2 et certaines publicités seront affichées.",
                "hi": "नमस्ते, {name_prefix}!\nकल से, 'मेरे स्थान' प्रविष्टियों की संख्या 2 तक सीमित हो जाएगी, और कुछ विज्ञापन प्रदर्शित किए जाएंगे।"
            }

            # 구독하지 않은 오더 list
            push_list = member_t.getNotJoinGroup11()
            for pt in push_list:
                if pt.sgdt_owner_chk == "Y":
                    try:
                        mt_name = pt.mt_name
                        if not pt.mt_nickname is None and pt.mt_nickname != "":
                            mt_name = pt.mt_nickname

                        push_content = txt_key_push_content[pt.mt_lang].format(name_prefix=mt_name)
                        push_result = send_push(pt.mt_token_id, txt_key_push_title[pt.mt_lang], push_content)
                        push_txt = push_content
                        push_log_add(pt.mt_idx, None, plt_condition, plt_memo, txt_key_push_title[pt.mt_lang], push_txt, push_result)
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, "멤버없음")
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, "멤버 찾을 수 없음")
                            else:
                                push_err_log_add(None, "오전 10시 - 구독 - 가입 후 11일 경과", e, member_info.mt_idx)
                        logger.error("[ps_8][" + str(pt.mt_idx) + "] - " + str(e))
            print("오전 10시 - 구독 - 가입 후 13일 경과")

    # 날씨 - 오전 7시 + 사용자위치
    def ps_9():
        from smap.models import member_t
        from smap.apis.weather import Weather
        from smap.models import member_location_log_t
        from smap.apis.lib_func import (
            get_latlong_to_add_naver,
            send_push,
            get_weather_emoji,
            get_weather_sky,
        )

        with app.app_context():
            plt_condition = "오전 7시 - 날씨"
            plt_memo = "해당일 일기예보 발송"

            now = dt.now()
            now = now.strftime("%Y-%m-%d")

            push_list = member_t.getTokenList()
            for pt in push_list:
                try:
                    logger.info(f"ps_9 날씨 - pt.mt_idx : {pt.mt_idx}")

                    # 최근 위치 가져오기
                    member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
                    if member_info is None:
                        # 해당 계정 마지막 로그 구하기
                        member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                        if member_info is None:
                            # 서울 명동으로 위치 지정
                            mlt_lat = 37.56668050000000
                            mlt_long = 126.97841470000000
                        else:
                            mlt_lat = float(member_info.mlt_lat)
                            mlt_long = float(member_info.mlt_long)
                    else:
                        logger.info(
                            f"ps_9 날씨 - mlt_lat : {member_info.mlt_lat} / mlt_long : {member_info.mlt_long}"
                        )
                        mlt_lat = float(member_info.mlt_lat)
                        mlt_long = float(member_info.mlt_long)

                    # 단기예보
                    categorys1 = ["TMN", "TMX", "POP"]
                    user_weather = Weather()
                    response1 = user_weather.requestForecast(
                        mlt_lat, mlt_long, 6, "", 0
                    )
                    today_weather1 = user_weather.parseWeather(response1, categorys1)

                    # 초단기예보
                    categorys2 = ["SKY", "PTY"]
                    response2 = user_weather.requestForecast(
                        mlt_lat, mlt_long, 0, "", 0
                    )
                    today_weather2 = user_weather.parseWeather(response2, categorys2)
                    emoji = get_weather_emoji(today_weather2)

                    # 사용자 위치로 주소 가져오기
                    coords = f"{mlt_long},{mlt_lat}"
                    user_add = get_latlong_to_add_naver(coords)

                    txt_key_push_title = {
                        "ko": f"날씨 정보 {emoji}",
                        "en": f"Weather Information {emoji}",
                        "vi": f"Thông tin thời tiết {emoji}",
                        "id": f"Informasi Cuaca {emoji}",
                        "th": f"ข้อมูลสภาพอากาศ {emoji}",
                        "ja": f"天気情報 {emoji}",
                        "es": f"Información meteorológica {emoji}",
                        "fr": f"Informations météorologiques {emoji}",
                        "hi": f"मौसम की जानकारी {emoji}"
                    }

                    txt_key_push_content = {
                        "ko": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\n강수확률 : {today_weather1['POP']}\n최저기온 : {today_weather1['TMN']}\n최고기온 : {today_weather1['TMX']}",
                        "en": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nProbability of Precipitation: {today_weather1['POP']}\nMinimum Temperature: {today_weather1['TMN']}\nMaximum Temperature: {today_weather1['TMX']}",
                        "vi": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nXác suất có mưa: {today_weather1['POP']}\nNhiệt độ thấp nhất: {today_weather1['TMN']}\nNhiệt độ cao nhất: {today_weather1['TMX']}",
                        "id": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nProbabilitas Hujan: {today_weather1['POP']}\nSuhu Minimum: {today_weather1['TMN']}\nSuhu Maksimum: {today_weather1['TMX']}",
                        "th": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nโอกาสที่จะมีฝนตก: {today_weather1['POP']}\nอุณหภูมิต่ำสุด: {today_weather1['TMN']}\nอุณหภูมิสูงสุด: {today_weather1['TMX']}",
                        "ja": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\n降水確率: {today_weather1['POP']}\n最低気温: {today_weather1['TMN']}\n最高気温: {today_weather1['TMX']}",
                        "es": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nProbabilidad de precipitación: {today_weather1['POP']}\nTemperatura mínima: {today_weather1['TMN']}\nTemperatura máxima: {today_weather1['TMX']}",
                        "fr": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nProbabilité de précipitations: {today_weather1['POP']}\nTempérature minimale: {today_weather1['TMN']}\nTempérature maximale: {today_weather1['TMX']}",
                        "hi": f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\nवर्षा की संभावना: {today_weather1['POP']}\nन्यूनतम तापमान: {today_weather1['TMN']}\nअधिकतम तापमान: {today_weather1['TMX']}"
                    }

                    push_title = txt_key_push_title[pt.mt_lang]
                    push_content = txt_key_push_content[pt.mt_lang]
                    push_result = send_push(pt.mt_token_id, push_title, push_content)
                    push_txt = push_content
                    push_log_add(
                        pt.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )

                    logger.info(f"회원 {pt.mt_idx}에 대한 처리 완료")

                except Exception as e:
                    error_message = f"[ps_9][{pt.mt_idx}] - {str(e)}"
                    logger.error(error_message)
                    try:
                        # 에러 로그 추가 및 관리자 푸시 알림
                        member_info = member_t.find_one_idx(pt.mt_idx)
                        if member_info is None:
                            push_err_log_add(
                                None,
                                "오전 7시 - 날씨",
                                e,
                                "멤버 찾을 수 없음",
                            )
                        else:
                            push_err_log_add(
                                None,
                                "오전 7시 - 날씨",
                                e,
                                member_info.mt_idx,
                            )
                        admin_send_push(error_message)
                    except Exception as inner_e:
                        logger.error(f"추가 에러 처리 중 오류 발생: {str(inner_e)}")

            logger.info("오전 7시 - 날씨 - 해당일 일기예보 발송 완료")

    # 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우
    def ps_10():
        from smap.models import member_t
        from smap.models import smap_group_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "가입후 3시간 경과 "
            plt_memo = "그룹 생성 안했을 경우"
            
            txt_key_push_title = {
                "ko": "그룹을 생성해보세요. 👫 ",
                "en": "Try creating a group. 👫",
                "vi": "Hãy thử tạo một nhóm. 👫",
                "id": "Cobalah membuat grup. 👫",
                "th": "ลองสร้างกลุ่ม 👫",
                "ja": "グループを作成してみてください。 👫",
                "es": "Intenta crear un grupo. 👫",
                "fr": "Essayez de créer un groupe. 👫",
                "hi": "एक समूह बनाने का प्रयास करें। 👫"
            }

            txt_key_push_content = {
                "ko": "서비스를 더 잘 이용하시려면 그룹을 생성해보세요.\n그룹을 통해 그룹원의 위치를 파악하고, 일정을 공유할 수 있습니다.",
                "en": "To better utilize the service, try creating a group.\nYou can track the location of group members and share schedules through the group.",
                "vi": "Để sử dụng dịch vụ tốt hơn, hãy thử tạo một nhóm.\nBạn có thể theo dõi vị trí của các thành viên trong nhóm và chia sẻ lịch trình thông qua nhóm.",
                "id": "Untuk lebih memanfaatkan layanan, cobalah membuat grup.\nAnda dapat melacak lokasi anggota grup dan berbagi jadwal melalui grup.",
                "th": "เพื่อใช้บริการได้ดียิ่งขึ้น ลองสร้างกลุ่ม\nคุณสามารถติดตามตำแหน่งของสมาชิกในกลุ่มและแชร์ตารางเวลาผ่านกลุ่ม",
                "ja": "サービスをより良く活用するために、グループを作成してみてください。\nグループを通じて、メンバーの位置を確認したり、スケジュールを共有することができます。",
                "es": "Para aprovechar mejor el servicio, intenta crear un grupo.\nPuedes rastrear la ubicación de los miembros del grupo y compartir horarios a través del grupo.",
                "fr": "Pour mieux utiliser le service, essayez de créer un groupe.\nVous pouvez suivre l'emplacement des membres du groupe et partager des horaires via le groupe.",
                "hi": "सेवा का बेहतर उपयोग करने के लिए, एक समूह बनाने का प्रयास करें।\nआप समूह के माध्यम से सदस्यों के स्थान का पता लगा सकते हैं और कार्यक्रम साझा कर सकते हैं।"
            }

            push_list = member_t.getSignIn3()
            for pt in push_list:
                sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
                sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
                sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)

                if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgdt_cnt == 0:
                    try:
                        push_title = txt_key_push_title[pt.mt_lang]
                        push_content = txt_key_push_content[pt.mt_lang]
                        push_txt = push_content
                        push_result = send_push(
                            pt.mt_token_id, push_title, push_content
                        )
                        push_log_add(
                            pt.mt_idx,
                            None,
                            plt_condition,
                            plt_memo,
                            push_title,
                            push_txt,
                            push_result,
                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "가입후 3시간 경과 ",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "가입후 3시간 경과 ",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "가입후 3시간 경과 ",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_10][" + str(pt.mt_idx) + "] - " + str(e))
            print("가입후 3시간 경과 - 그룹 생성 안했을 경우")

    # 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우
    def ps_11():
        from smap.models import member_t
        from smap.models import smap_group_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "가입후 24시간 경과 "
            plt_memo = "그룹 생성 안했을 경우"
            
            txt_key_push_title = {
                "ko": "그룹을 생성해보세요. 👥",
                "en": "Try creating a group. 👥",
                "vi": "Hãy thử tạo một nhóm. 👥",
                "id": "Cobalah membuat grup. 👥",
                "th": "ลองสร้างกลุ่ม 👥",
                "ja": "グループを作成してみてください。 👥",
                "es": "Intenta crear un grupo. 👥",
                "fr": "Essayez de créer un groupe. 👥",
                "hi": "एक समूह बनाने का प्रयास करें। 👥"
            }

            txt_key_push_content = {
                "ko": "그룹을 만들면 서비스를 더 효과적으로 이용할 수 있습니다.\n 지금 바로 그룹을 만들어보세요.",
                "en": "Creating a group will allow you to use the service more effectively.\n Try creating a group right now.",
                "vi": "Tạo nhóm sẽ giúp bạn sử dụng dịch vụ hiệu quả hơn.\n Hãy thử tạo một nhóm ngay bây giờ.",
                "id": "Membuat grup akan memungkinkan Anda menggunakan layanan lebih efektif.\n Cobalah membuat grup sekarang juga.",
                "th": "การสร้างกลุ่มจะช่วยให้คุณใช้บริการได้อย่างมีประสิทธิภาพมากขึ้น\n ลองสร้างกลุ่มตอนนี้เลย",
                "ja": "グループを作成すると、サービスをより効果的に利用できます。\n 今すぐグループを作成してみてください。",
                "es": "Crear un grupo te permitirá usar el servicio de manera más efectiva.\n Intenta crear un grupo ahora mismo.",
                "fr": "Créer un groupe vous permettra d'utiliser le service plus efficacement.\n Essayez de créer un groupe dès maintenant.",
                "hi": "एक समूह बनाने से आप सेवा का अधिक प्रभावी ढंग से उपयोग कर सकेंगे।\n अभी एक समूह बनाने का प्रयास करें।"
            }

            push_list = member_t.getSignIn24()
            for pt in push_list:
                sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
                sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
                sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)

                if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgdt_cnt == 0:
                    try:
                        push_title = txt_key_push_title[pt.mt_lang]
                        push_content = txt_key_push_content[pt.mt_lang]
                        push_txt = push_content
                        push_result = send_push(pt.mt_token_id, push_title, push_content)
                        push_log_add(pt.mt_idx, None, plt_condition, plt_memo, push_title, push_txt, push_result)
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(None, "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우", e, "멤버 없음")
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(None, "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우", e, "멤버 찾을 수 없음")
                            else:
                                push_err_log_add(None, "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우", e, member_info.mt_idx)
                        logger.error("[ps_11][" + member_info.mt_idx + "] - " + e)
            print("1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우")
    # 배터리 - 19시에 배터리체크 후 50% 이하
    def ps_12():
        from smap.models import member_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import get_group_member, send_push

        with app.app_context():
            plt_condition = "오후 7시 - 배터리체크"
            plt_memo = "19시에 배터리체크 후 50% 이하"
            push_list = smap_group_detail_t.get_member_list()
            
            txt_key_push_title = {
                "ko": "배터리 부족 알림 🪫",
                "en": "Low battery notification 🪫",
                "vi": "Thông báo pin yếu 🪫",
                "id": "Pemberitahuan baterai rendah 🪫",
                "th": "การแจ้งเตือนแบตเตอรี่ต่ำ 🪫",
                "ja": "バッテリー残量低下通知 🪫",
                "es": "Notificación de batería baja 🪫",
                "fr": "Notification de batterie faible 🪫",
                "hi": "बैटरी कम होने की सूचना 🪫"
            }

            txt_key_push_content_order = {
                "ko": "{mt_name}님의 핸드폰 배터리가 50% 미만이에요. \n충전 해주세요! 🔌",
                "en": "{mt_name}'s phone battery is below 50%. \nPlease charge it! 🔌",
                "vi": "Pin điện thoại của {mt_name} dưới 50%. \nHãy sạc pin! 🔌",
                "id": "Baterai ponsel {mt_name} di bawah 50%. \nSilakan isi dayanya! 🔌",
                "th": "แบตเตอรี่โทรศัพท์ของ {mt_name} ต่ำกว่า 50% \nโปรดชาร์จแบตเตอรี่! 🔌",
                "ja": "{mt_name}さんの携帯電池残量が50%を下回っています。\n充電してください! 🔌",
                "es": "La batería del teléfono de {mt_name} está por debajo del 50%. \n¡Cárgala! 🔌",
                "fr": "La batterie du téléphone de {mt_name} est inférieure à 50%. \nVeuillez la recharger! 🔌",
                "hi": "{mt_name} के फ़ोन की बैटरी 50% से कम है। \nकृपया इसे चार्ज करें! 🔌"
            }

            txt_key_push_content_leader = {
                "ko": "{mt_name}님의 핸드폰 배터리가 50% 미만이에요. \n충전 헤주세요! 🔌",
                "en": "{mt_name}'s phone battery is below 50%. \nPlease have them charge it! 🔌",
                "vi": "Pin điện thoại của {mt_name} dưới 50%. \nHãy yêu cầu họ sạc pin! 🔌",
                "id": "Baterai ponsel {mt_name} di bawah 50%. \nSilakan minta mereka mengisi dayanya! 🔌",
                "th": "แบตเตอรี่โทรศัพท์ของ {mt_name} ต่ำกว่า 50% \nโปรดให้เขาชาร์จแบตเตอรี่! 🔌",
                "ja": "{mt_name}さんの携帯電池残量が50%を下回っています。\n充電するよう伝えてください! 🔌",
                "es": "La batería del teléfono de {mt_name} está por debajo del 50%. \n¡Pídales que la carguen! 🔌",
                "fr": "La batterie du téléphone de {mt_name} est inférieure à 50%. \nVeuillez leur demander de la recharger! 🔌",
                "hi": "{mt_name} के फ़ोन की बैटरी 50% से कम है। \nकृपया उनसे इसे चार्ज करने को कहें! 🔌"
            }

            txt_key_push_content_member = {
                "ko": "현재 핸드폰 배터리가 50% 미만이에요. ⚡️\n충전 해주세요!  🔌",
                "en": "Your phone battery is currently below 50%. ⚡️\nPlease charge it! 🔌",
                "vi": "Hiện tại pin điện thoại của bạn dưới 50%. ⚡️\nHãy sạc pin! 🔌",
                "id": "Baterai ponsel Anda saat ini di bawah 50%. ⚡️\nSilakan isi dayanya! 🔌",
                "th": "ขณะนี้แบตเตอรี่โทรศัพท์ของคุณต่ำกว่า 50% ⚡️\nโปรดชาร์จแบตเตอรี่! 🔌",
                "ja": "現在の携帯電池残量が50%を下回っています。⚡️\n充電してください! 🔌",
                "es": "La batería de tu teléfono está actualmente por debajo del 50%. ⚡️\n¡Cárgala! 🔌",
                "fr": "La batterie de votre téléphone est actuellement inférieure à 50%. ⚡️\nVeuillez la recharger! 🔌",
                "hi": "आपके फ़ोन की बैटरी वर्तमान में 50% से कम है। ⚡️\nकृपया इसे चार्ज करें! 🔌"
            }
            for pt in push_list:
                # 해당 학생의 마지막로그 가져오기
                mlt_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                if mlt_info != None:
                    try:
                        if mlt_info.mlt_battery <= 50:
                            group_data = get_group_member(pt.sgt_idx, pt.mt_idx)

                            if group_data["order"] != {}:
                                # 오더 전송
                                group_data["order"]["push_title"] = txt_key_push_title[pt.mt_lang]
                                group_data["order"]["push_content"] = txt_key_push_content_order[pt.mt_lang].format(mt_name=group_data["member"]["mt_name"])
                                group_data["order"]["push_txt"] = group_data["order"]["push_content"]
                                group_data["order"]["send"] = "Y"
                            else:
                                group_data["order"]["send"] = "N"

                            if group_data["leader"] != {}:
                                # 리더전송
                                group_data["leader"]["push_title"] = txt_key_push_title[pt.mt_lang]
                                group_data["leader"]["push_content"] = txt_key_push_content_leader[pt.mt_lang].format(mt_name=group_data["member"]["mt_name"])
                                group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]
                                group_data["leader"]["send"] = "Y"
                            else:
                                group_data["leader"]["send"] = "N"

                            if group_data["member"] != {}:
                                # 학생전송
                                group_data["member"]["push_title"] = txt_key_push_title[pt.mt_lang]
                                group_data["member"]["push_content"] = txt_key_push_content_member[pt.mt_lang]
                                group_data["member"]["push_txt"] = group_data["member"]["push_content"]
                                group_data["member"]["send"] = "Y"
                            else:
                                group_data["member"]["send"] = "N"

                            for key, group in group_data.items():
                                if group != "":
                                    if group["send"] == "Y":
                                        push_result = send_push(group["mt_token_id"], group["push_title"], group["push_content"])
                                        push_log_add(group["mt_idx"], None, plt_condition, plt_memo, group["push_title"], group["push_txt"], push_result)
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(None, "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하", e, "멤버 없음")
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(None, "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하", e, "멤버 찾을 수 없음")
                            else:
                                push_err_log_add(None, "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하", e, member_info.mt_idx)
                        logger.error("[ps_12][" + member_info.mt_idx + "] - " + e)
            print("오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하")

    # 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우
    def ps_13():
        from smap.models import member_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import get_group_member, send_push

        with app.app_context():
            plt_condition = "1시간 - 권한"
            plt_memo = "그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우"
            
            txt_key_push_title = {
                "ko": "권한 설정 요청 🔑",
                "en": "Permission setting request 🔑",
                "vi": "Yêu cầu cài đặt quyền 🔑",
                "id": "Permintaan pengaturan izin 🔑",
                "th": "คำขอตั้งค่าสิทธิ์ 🔑",
                "ja": "権限設定リクエスト 🔑",
                "es": "Solicitud de configuración de permisos 🔑",
                "fr": "Demande de paramètre d'autorisation 🔑",
                "hi": "अनुमति सेटिंग अनुरोध 🔑"
            }

            txt_key_push_content = {
                "ko": "정확한 위치 정보 제공을 위해\n{mt_name}님의 핸드폰 권한 설정을 해주세요.",
                "en": "To provide accurate location information,\nplease set the permissions on {mt_name}'s phone.",
                "vi": "Để cung cấp thông tin vị trí chính xác,\nhãy đặt quyền trên điện thoại của {mt_name}.",
                "id": "Untuk memberikan informasi lokasi yang akurat,\nsilakan atur izin pada ponsel {mt_name}.",
                "th": "เพื่อให้ข้อมูลตำแหน่งที่ตั้งที่แม่นยำ\nโปรดตั้งค่าสิทธิ์บนโทรศัพท์ของ {mt_name}",
                "ja": "正確な位置情報を提供するために\n{mt_name}さんの携帯電話の権限設定をしてください。",
                "es": "Para proporcionar información de ubicación precisa,\nconfigure los permisos en el teléfono de {mt_name}.",
                "fr": "Pour fournir des informations de localisation précises,\nveuillez définir les autorisations sur le téléphone de {mt_name}.",
                "hi": "सटीक स्थान जानकारी प्रदान करने के लिए,\nकृपया {mt_name} के फ़ोन पर अनुमतियां सेट करें।"
            }

            push_list = smap_group_detail_t.joinGroup1()

            if push_list:  # push_list에 데이터가 1건 이상 존재하는지 확인
                for pt in push_list:
                    try:
                        group_data = get_group_member(pt.sgt_idx, pt.mt_idx)

                        if group_data["order"] != {}:
                            # 오더 전송
                            group_data["order"]["push_title"] = txt_key_push_title[pt.mt_lang]
                            group_data["order"]["push_content"] = txt_key_push_content[pt.mt_lang].format(mt_name=group_data["member"]["mt_name"])
                            group_data["order"]["push_txt"] = group_data["order"]["push_content"]
                            group_data["order"]["send"] = "Y"
                        else:
                            group_data["order"]["send"] = "N"

                        if group_data["leader"] != {}:
                            # 리더전송
                            group_data["leader"]["push_title"] = txt_key_push_title[pt.mt_lang]
                            group_data["leader"]["push_content"] = txt_key_push_content[pt.mt_lang].format(mt_name=group_data["member"]["mt_name"])
                            group_data["leader"]["push_txt"] = group_data["leader"]["push_content"]
                            group_data["leader"]["send"] = "Y"
                        else:
                            group_data["leader"]["send"] = "N"

                        for key, group in group_data.items():  # 수정된 부분: items() 메서드 사용
                            if group != "" and key != "member":
                                if group["send"] == "Y":
                                    push_result = send_push(group["mt_token_id"], group["push_title"], group["push_content"])
                                    push_log_add(group["mt_idx"], pt.sst_idx, plt_condition, plt_memo, group["push_title"], group["push_txt"], push_result)

                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(None, "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우", e, "멤버 없음")
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(None, "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우", e, "멤버 찾을 수 없음")
                            else:
                                push_err_log_add(None, "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우", e, member_info.mt_idx)

                        logger.error("[ps_13][" + member_info.mt_idx + "] - " + str(e))  # 수정된 부분: str(e) 사용
                print("1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우")

    def ps_14():
        import json

        from smap.models import smap_group_detail_t
        from smap.models import push_fcm_t
        from smap.models import member_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "1시간 - 예약 push 발송"
            plt_memo = "예약 push 발송"

            push_list = push_fcm_t.find_push_list()
            for pt in push_list:
                loop_push_update(pt.pft_idx, 1)
                try:
                    push_title = pt.pft_title
                    push_content = pt.pft_content
                    push_txt = pt.pft_content
                    push_url = None
                    if not pt.pft_url is None or pt.pft_url != "":
                        push_url = pt.pft_url

                    if pt.pft_send_type == 1:
                        # 전체 push
                        member_list = member_t.getTokenList()
                        for member in member_list:
                            if not member is None:
                                # if member.mt_idx == 80 or member.mt_idx == 98 or member.mt_idx == 79:
                                push_result = send_push(
                                    member.mt_token_id,
                                    push_title,
                                    push_content,
                                    push_url,
                                )
                                push_log_add(
                                    member.mt_idx,
                                    None,
                                    plt_condition,
                                    plt_memo,
                                    push_title,
                                    push_txt,
                                    push_result,
                                )
                    elif pt.pft_send_type == 2:
                        # 특정 사용자에게 전송
                        mt_list = json.loads(pt.pft_send_mt_idx)
                        for mt_idx in mt_list:
                            member = member_t.find_one_idx(mt_idx)
                            if not member is None:
                                push_result = send_push(
                                    member.mt_token_id,
                                    push_title,
                                    push_content,
                                    push_url,
                                )
                                push_log_add(
                                    member.mt_idx,
                                    None,
                                    plt_condition,
                                    plt_memo,
                                    push_title,
                                    push_txt,
                                    push_result,
                                )
                    elif pt.pft_send_type == 3:
                        # 특정 그룹에 전송
                        group_idx_list = json.loads(pt.pft_send_mt_idx)
                        for group_idx in group_idx_list:
                            group_list = smap_group_detail_t.get_group(group_idx)
                            for group_member in group_list:
                                member = member_t.find_one_idx(group_member.mt_idx)
                                if not member is None:
                                    push_result = send_push(
                                        member.mt_token_id,
                                        push_title,
                                        push_content,
                                        push_url,
                                    )
                                    push_log_add(
                                        member.mt_idx,
                                        None,
                                        plt_condition,
                                        plt_memo,
                                        push_title,
                                        push_txt,
                                        push_result,
                                    )

                    loop_push_update(pt.pft_idx, 2)

                except Exception as e:
                    push_err_log_add(None, "1시간 - 예약 push 발송", e)
                    logger.error("[ps_14][" + member_info.mt_idx + "] - " + e)
            print("1시간 - 예약 push 발송")

    # 10분마다 사용자위치 업데이트
    def ps_15():
        from smap.models import member_t, member_location_log_t
        from smap.apis.lib_func import get_latlong_to_add_naver
        import logging
        import datetime

        # 로그 설정
        # logging.basicConfig(filename='debug.log', level=logging.DEBUG, format='%(asctime)s:%(levelname)s:%(message)s')

        with app.app_context():
            plt_condition = "10분마다 모든 멤버"
            plt_memo = "위치 업데이트"

            now = dt.now()
            now = now.strftime("%Y-%m-%d")

            push_list = member_t.getTokenList()
            for pt in push_list:
                try:
                    # 최근 위치 가져오기
                    member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
                    if member_info is None:
                        # 해당 계정 마지막 로그 구하기
                        member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                        if member_info is None:
                            # 서울 명동으로 위치 지정
                            mlt_lat = "37.56668050000000"
                            mlt_long = "126.97841470000000"
                        else:
                            mlt_lat = member_info.mlt_lat
                            mlt_long = member_info.mlt_long
                    else:
                        mlt_lat = member_info.mlt_lat
                        mlt_long = member_info.mlt_long

                    # 사용자 위치로 주소 가져오기
                    coords = f"{mlt_long},{mlt_lat}"
                    user_add = get_latlong_to_add_naver(coords)

                    # 주소에서 시도, 구, 동 정보 추출
                    mt_sido = user_add["area1"]
                    mt_gu = user_add["area2"]
                    mt_dong = user_add["area3"]

                    # 멤버 정보 업데이트
                    member = member_t.find_one_idx(mt_idx=pt.mt_idx)
                    if member:
                        member.mt_lat = mlt_lat
                        member.mt_long = mlt_long
                        member.mt_sido = mt_sido
                        member.mt_gu = mt_gu
                        member.mt_dong = mt_dong
                        member.mt_udate = (
                            dt.now()
                        )  # 현재 시각으로 업데이트
                        db.session.commit()  # 변경 사항을 커밋
                    else:
                        logger.error(f"No member found with mt_idx {pt.mt_idx}")

                except Exception as e:
                    logger.error(f"Error updating member {pt.mt_idx}: {e}")

    # 매일 0시 내장소 진입 후 이탈로 업데이트 되지 않은 건 강제 업데이트
    def ps_16():
        from smap.models import smap_location_t
        from smap.apis.lib_func import get_latlong_to_add_naver
        import logging
        import datetime

        with app.app_context():
            plt_condition = "매일 00시"
            plt_memo = "모든 고객 내장소 초기화"
            push_list = smap_location_t.getOutMyplaysList()

            for pt in push_list:
                if not pt is None:
                    if pt.slt_enter_alarm == "Y":
                        try:
                            # 진입여부 수정
                            location_result = location_status_update(pt.slt_idx, "N")
                        except Exception as e:
                            logger.error("[ps_16][" + pt.mt_idx + "] - " + e)
                            admin_send_push("[ps_16][" + pt.mt_idx + "] - " + e)

    def ps_17():
        logger.info(f"ps_17 로그확인 push 실행")
        from smap.models import smap_group_detail_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            txt_key_messages = [
                {
                    "title": {
                        "ko": "오늘의 그룹원 동향 리포트 📊",
                        "en": "Today's Group Member Activity Report 📊",
                        "vi": "Báo cáo hoạt động của thành viên nhóm hôm nay 📊",
                        "id": "Laporan Aktivitas Anggota Grup Hari Ini 📊",
                        "th": "รายงานกิจกรรมของสมาชิกในกลุ่มวันนี้ 📊",
                        "ja": "本日のグループメンバーの活動レポート 📊",
                        "es": "Reporte de actividad de los miembros del grupo de hoy 📊",
                        "fr": "Rapport d'activité des membres du groupe d'aujourd'hui 📊",
                        "hi": "आज के समूह सदस्य गतिविधि रिपोर्ट 📊"
                    },
                    "content": {
                        "ko": "그룹원들의 하루 동선이 궁금하신가요?\n로그에서 모든 것을 확인하세요! 🚶‍♀️",
                        "en": "Curious about the group members' daily movements?\nCheck out the logs to see everything! 🚶‍♀️",
                        "vi": "Bạn có tò mò về hành trình hàng ngày của các thành viên nhóm không?\nKiểm tra nhật ký để xem tất cả! 🚶‍♀️",
                        "id": "Penasaran dengan pergerakan harian anggota grup?\nCek lognya untuk melihat semuanya! 🚶‍♀️",
                        "th": "สงสัยไหมว่าสมาชิกในกลุ่มเคลื่อนไหวไปที่ไหนบ้างในแต่ละวัน?\nตรวจสอบจากบันทึกเพื่อดูทุกอย่าง! 🚶‍♀️",
                        "ja": "グループメンバーの1日の行動が気になりますか?\nログを確認して全てを把握しましょう! 🚶‍♀️",
                        "es": "¿Tienes curiosidad por los movimientos diarios de los miembros del grupo?\n¡Revisa los registros para ver todo! 🚶‍♀️",
                        "fr": "Curieux des mouvements quotidiens des membres du groupe ?\nConsultez les journaux pour tout voir ! 🚶‍♀️",
                        "hi": "क्या आप समूह सदस्यों की दैनिक गतिविधियों के बारे में जानना चाहते हैं?\nसभी देखने के लिए लॉग देखें! 🚶‍♀️"
                    }
                },
                {
                    "title": {
                        "ko": "그룹원들의 일상 탐험 📝",
                        "en": "Exploring the Group Members' Daily Lives 📝",
                        "vi": "Khám phá cuộc sống hàng ngày của các thành viên nhóm 📝",
                        "id": "Menjelajahi Kehidupan Sehari-hari Anggota Grup 📝",
                        "th": "สำรวจชีวิตประจำวันของสมาชิกในกลุ่ม 📝",
                        "ja": "グループメンバーの日常を探る 📝",
                        "es": "Explorando la vida diaria de los miembros del grupo 📝",
                        "fr": "Explorer la vie quotidienne des membres du groupe 📝",
                        "hi": "समूह सदस्यों के दैनिक जीवन का अन्वेषण 📝"
                    },
                    "content": {
                        "ko": "그룹원들의 오늘 하루는 어땠을까요? \n로그에서 힌트를 찾아보세요!🕵️‍♂️",
                        "en": "How was the group members' day today?\nLook for clues in the logs!🕵️‍♂️",
                        "vi": "Ngày hôm nay của các thành viên nhóm thế nào?\nTìm manh mối trong nhật ký!🕵️‍♂️",
                        "id": "Bagaimana hari anggota grup hari ini?\nCari petunjuknya di log!🕵️‍♂️",
                        "th": "วันนี้สมาชิกในกลุ่มเป็นอย่างไรบ้าง?\nค้นหาเบาะแสจากบันทึกสิ!🕵️‍♂️",
                        "ja": "本日のグループメンバーの1日はどうでしたか?\nログからヒントを見つけてみましょう!🕵️‍♂️",
                        "es": "¿Cómo fue el día de los miembros del grupo hoy?\n¡Busca pistas en los registros!🕵️‍♂️",
                        "fr": "Comment s'est passée la journée des membres du groupe aujourd'hui ?\nRecherchez des indices dans les journaux !🕵️‍♂️",
                        "hi": "आज समूह सदस्यों का दिन कैसा रहा?\nलॉग में संकेत ढूंढें!🕵️‍♂️"
                    }
                },
                {
                    "title": {
                        "ko": "일상의 기록 📸",
                        "en": "Capturing Daily Life 📸",
                        "vi": "Ghi lại cuộc sống hàng ngày 📸",
                        "id": "Merekam Kehidupan Sehari-hari 📸",
                        "th": "บันทึกชีวิตประจำวัน 📸",
                        "ja": "日常の記録 📸",
                        "es": "Capturando la vida diaria 📸",
                        "fr": "Capturer la vie quotidienne 📸",
                        "hi": "दैनिक जीवन को कैप्चर करना 📸"
                    },
                    "content": {
                        "ko": "그룹원들의 하루가 로그에 담겼어요.\n로그를 통해 그들의 발자취를 따라가 보세요! 🌟",
                        "en": "The group members' day has been captured in the logs.\nFollow their footsteps through the logs! 🌟",
                        "vi": "Một ngày của các thành viên nhóm đã được ghi lại trong nhật ký.\nHãy theo dõi dấu chân của họ qua nhật ký! 🌟",
                        "id": "Hari anggota grup telah diabadikan dalam log.\nIkuti jejak mereka melalui log! 🌟",
                        "th": "วันของสมาชิกในกลุ่มได้ถูกบันทึกไว้ในบันทึกแล้ว\nติดตามรอยเท้าของพวกเขาผ่านบันทึก! 🌟",
                        "ja": "グループメンバーの1日がログに記録されています。\nログを通してその足跡を辿ってみましょう! 🌟",
                        "es": "El día de los miembros del grupo ha sido capturado en los registros.\n¡Sigue sus pasos a través de los registros! 🌟",
                        "fr": "La journée des membres du groupe a été capturée dans les journaux.\nSuivez leurs traces à travers les journaux ! 🌟",
                        "hi": "समूह सदस्यों के दिन को लॉग में कैप्चर किया गया है।\nलॉग के माध्यम से उनके फुटप्रिंट का पालन करें! 🌟"
                    }
                },
                {
                    "title": {
                        "ko": "그룹원들의 하루 타임라인 ⏱️",
                        "en": "Group Members' Daily Timeline ⏱️",
                        "vi": "Dòng thời gian hàng ngày của các thành viên nhóm ⏱️",
                        "id": "Linimasa Harian Anggota Grup ⏱️",
                        "th": "ไทม์ไลน์ประจำวันของสมาชิกในกลุ่ม ⏱️",
                        "ja": "グループメンバーの1日のタイムライン ⏱️",
                        "es": "Línea de tiempo diaria de los miembros del grupo ⏱️",
                        "fr": "Chronologie quotidienne des membres du groupe ⏱️",
                        "hi": "समूह सदस्यों की दैनिक टाइमलाइन ⏱️"
                    },
                    "content": {
                        "ko": "시간별로 그룹원들의 활동을 정리했어요.\n오늘 하루는 어떻게 흘러갔는지 로그에서 확인하세요! 🕰️",
                        "en": "We've organized the group members' activities by time.\nCheck the logs to see how their day unfolded! 🕰️",
                        "vi": "Chúng tôi đã tổ chức các hoạt động của các thành viên nhóm theo thời gian.\nKiểm tra nhật ký để xem ngày của họ diễn ra như thế nào! 🕰️",
                        "id": "Kami telah mengorganisir aktivitas anggota grup berdasarkan waktu.\nCek lognya untuk melihat bagaimana hari mereka berlalu! 🕰️",
                        "th": "เราได้จัดระเบียบกิจกรรมของสมาชิกในกลุ่มตามเวลาแล้ว\nตรวจสอบจากบันทึกเพื่อดูว่าวันของพวกเขาผ่านไปอย่างไร! 🕰️",
                        "ja": "グループメンバーの活動を時間ごとに整理しました。\nログを確認して、彼らの1日がどのように過ぎたかを見てみましょう! 🕰️",
                        "es": "Hemos organizado las actividades de los miembros del grupo por hora.\n¡Revisa los registros para ver cómo transcurrió su día! 🕰️",
                        "fr": "Nous avons organisé les activités des membres du groupe par heure.\nConsultez les journaux pour voir comment s'est déroulée leur journée ! 🕰️",
                        "hi": "हमने समय के आधार पर समूह सदस्यों की गतिविधियों को व्यवस्थित किया है।\nदेखने के लिए लॉग देखें कि उनका दिन कैसे बीता! 🕰️"
                    }
                },
            ]

            plt_condition = "로그확인 push 발송"
            plt_memo = "로그확인 push 발송"

            member_list = smap_group_detail_t.get_owner_leader_list()
            logger.info(member_list)
            selected_message = random.choice(txt_key_messages)
            logger.info(selected_message)

            for member in member_list:
                push_title = selected_message["title"][member.mt_lang]
                push_content = selected_message["content"][member.mt_lang]
                push_txt = push_content
                push_url = "https://app2.smap.site/log"
                try:
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_18():
        from smap.models import smap_group_detail_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            logger.info(f"ps_18 내장소 입력 독려 push 실행")

            txt_key_messages = [
                {
                    "title": {
                        "ko": "실시간 위치 알리미 🗺️",
                        "en": "Real-time Location Notification 🗺️",
                        "vi": "Thông báo vị trí thời gian thực 🗺️",
                        "id": "Pemberitahuan Lokasi Waktu Nyata 🗺️",
                        "th": "การแจ้งเตือนสถานที่ในเวลาจริง 🗺️",
                        "ja": "リアルタイムロケーション通知 🗺️",
                        "es": "Notificación de ubicación en tiempo real 🗺️",
                        "fr": "Notification d'emplacement en temps réel 🗺️",
                        "hi": "रियल-टाइम स्थान सूचना 🗺️"
                    },
                    "content": {
                        "ko": "'내 장소'에 관심 지역을 등록하세요!\n그룹원이 100m 반경에 들어오면 바로 알려드려요. 📍",
                        "en": "Register your areas of interest in 'My Places'!\nWe'll notify you right away if a group member enters within 100m. 📍",
                        "vi": "Đăng ký các khu vực quan tâm của bạn trong 'Địa điểm của tôi'!\nChúng tôi sẽ thông báo ngay lập tức nếu một thành viên nhóm đi vào trong vòng bán kính 100m. 📍",
                        "id": "Daftarkan area yang Anda minati di 'Tempat Saya'!\nKami akan memberi tahu Anda segera jika anggota grup masuk dalam radius 100m. 📍",
                        "th": "ลงทะเบียนพื้นที่ที่คุณสนใจใน 'สถานที่ของฉัน'!\nเราจะแจ้งให้คุณทราบทันทีหากสมาชิกในกลุ่มเข้ามาในรัศมี 100 ม. 📍",
                        "ja": "'マイプレイス'で関心のあるエリアを登録してください!\nグループメンバーが100m以内に入ると、すぐに通知します。 📍",
                        "es": "¡Registra tus áreas de interés en 'Mis Lugares'!\nTe notificaremos de inmediato si un miembro del grupo ingresa dentro de un radio de 100 m. 📍",
                        "fr": "Enregistrez vos zones d'intérêt dans 'Mes lieux' !\nNous vous informerons immédiatement si un membre du groupe entre dans un rayon de 100 m. 📍",
                        "hi": "'मेरे स्थान' में अपने हित के क्षेत्रों को पंजीकृत करें!\nहम आपको तुरंत सूचित करेंगे यदि कोई समूह सदस्य 100 मीटर के दायरे में आता है। 📍"
                    }
                },
                {
                    "title": {
                        "ko": "스마트한 그룹 관리의 시작 🏠",
                        "en": "Start Smart Group Management 🏠",
                        "vi": "Bắt đầu Quản lý Nhóm Thông minh 🏠",
                        "id": "Mulai Manajemen Grup Pintar 🏠",
                        "th": "เริ่มต้นการจัดการกลุ่มอัจฉริยะ 🏠",
                        "ja": "スマートグループ管理の始まり 🏠",
                        "es": "Comienza la Gestión Inteligente de Grupos 🏠",
                        "fr": "Commencez la gestion intelligente des groupes 🏠",
                        "hi": "स्मार्ट समूह प्रबंधन शुरू करें 🏠"
                    },
                    "content": {
                        "ko": "'내 장소' 기능으로 그룹원 동향을\n 실시간 알림으로 받아보세요! 🚶‍♀️",
                        "en": "Use the 'My Places' feature to receive real-time notifications\nabout group members' whereabouts! 🚶‍♀️",
                        "vi": "Sử dụng tính năng 'Địa điểm của tôi' để nhận thông báo\nthời gian thực về hành trình của các thành viên nhóm! 🚶‍♀️",
                        "id": "Gunakan fitur 'Tempat Saya' untuk menerima pemberitahuan\nwaktu nyata tentang keberadaan anggota grup! 🚶‍♀️",
                        "th": "ใช้คุณสมบัติ 'สถานที่ของฉัน' เพื่อรับการแจ้งเตือน\nแบบเรียลไทม์เกี่ยวกับที่อยู่ของสมาชิกในกลุ่ม! 🚶‍♀️",
                        "ja": "'マイプレイス'機能を使って、グループメンバーの動向を\nリアルタイムで通知を受け取ることができます! 🚶‍♀️",
                        "es": "¡Usa la función 'Mis Lugares' para recibir notificaciones en tiempo real\nsobre el paradero de los miembros del grupo! 🚶‍♀️",
                        "fr": "Utilisez la fonctionnalité 'Mes lieux' pour recevoir des notifications en temps réel\nsur les allées et venues des membres du groupe ! 🚶‍♀️",
                        "hi": "'मेरे स्थान' सुविधा का उपयोग करके समूह सदस्यों के\nबारे में रियल-टाइम अधिसूचनाएं प्राप्त करें! 🚶‍♀️"
                    }
                },
                {
                    "title": {
                        "ko": "그룹원 동향을 한눈에! 👀",
                        "en": "Group Members' Whereabouts at a Glance! 👀",
                        "vi": "Tình hình của thành viên nhóm bằng một cái nhìn! 👀",
                        "id": "Keberadaan Anggota Grup Sekilas! 👀",
                        "th": "สถานะของสมาชิกในกลุ่มด้วยสายตา! 👀",
                        "ja": "グループメンバーの動向を一目で! 👀",
                        "es": "¡Ubicación de los miembros del grupo de un vistazo! 👀",
                        "fr": "Aperçu des allées et venues des membres du groupe ! 👀",
                        "hi": "एक नजर में समूह सदस्यों की गतिविधि! 👀"
                    },
                    "content": {
                        "ko": "'내 장소'를 설정하고 스마트하게 관리하세요.\n100m 반경 내 그룹원 출입 시 알림을 받을 수 있어요. 🔔",
                        "en": "Set up 'My Places' and manage it smartly.\nYou can receive notifications when group members enter within 100m. 🔔",
                        "vi": "Thiết lập 'Địa điểm của tôi' và quản lý thông minh.\nBạn có thể nhận thông báo khi thành viên nhóm đi vào trong vòng bán kính 100m. 🔔",
                        "id": "Siapkan 'Tempat Saya' dan kelolalah dengan pintar.\nAnda dapat menerima pemberitahuan saat anggota grup masuk dalam radius 100m. 🔔",
                        "th": "ตั้งค่า 'สถานที่ของฉัน' และจัดการอย่างชาญฉลาด\nคุณสามารถรับการแจ้งเตือนเมื่อสมาชิกในกลุ่มเข้ามาในรัศมี 100 ม. 🔔",
                        "ja": "'マイプレイス'を設定してスマートに管理しましょう。\nグループメンバーが100m以内に入ると通知を受け取れます。 🔔",
                        "es": "Configura 'Mis Lugares' y adminístralo de manera inteligente.\nPuedes recibir notificaciones cuando los miembros del grupo ingresen dentro de un radio de 100 m. 🔔",
                        "fr": "Configurez 'Mes lieux' et gérez-le intelligemment.\nVous pouvez recevoir des notifications lorsque des membres du groupe entrent dans un rayon de 100 m. 🔔",
                        "hi": "'मेरे स्थान' को सेट करें और इसका स्मार्ट रूप से प्रबंधन करें।\nआप सूचनाएं प्राप्त कर सकते हैं जब समूह के सदस्य 100 मीटर के दायरे में आते हैं। 🔔"
                    }
                },
                {
                    "title": {
                        "ko": "위치 기반 알림으로 똑똑하게 🌟",
                        "en": "Smart Location-Based Notifications 🌟",
                        "vi": "Thông báo dựa trên vị trí thông minh 🌟",
                        "id": "Pemberitahuan Berbasis Lokasi Pintar 🌟",
                        "th": "การแจ้งเตือนตามสถานที่อัจฉริยะ 🌟",
                        "ja": "スマートな位置情報ベースの通知 🌟",
                        "es": "Notificaciones inteligentes basadas en la ubicación 🌟",
                        "fr": "Notifications intelligentes basées sur la localisation 🌟",
                        "hi": "स्मार्ट स्थान-आधारित अधिसूचनाएं 🌟"
                    },
                    "content": {
                        "ko": "중요한 장소를 '내 장소'로 등록해보세요.\n그룹원의 출입을 실시간으로 확인할 수 있어요! 🏃‍♂️💨",
                        "en": "Register important places as 'My Places'.\nYou can check group members' entries and exits in real-time! 🏃‍♂️💨",
                        "vi": "Đăng ký những địa điểm quan trọng làm 'Địa điểm của tôi'.\nBạn có thể kiểm tra lượt ra vào của thành viên nhóm theo thời gian thực! 🏃‍♂️💨",
                        "id": "Daftarkan tempat-tempat penting sebagai 'Tempat Saya'.\nAnda dapat memeriksa keluar masuk anggota grup secara real-time! 🏃‍♂️💨",
                        "th": "ลงทะเบียนสถานที่สำคัญเป็น 'สถานที่ของฉัน'\nคุณสามารถตรวจสอบการเข้าและออกของสมาชิกในกลุ่มแบบเรียลไทม์ได้! 🏃‍♂️💨",
                        "ja": "重要な場所を'マイプレイス'に登録してみてください。\nグループメンバーの出入りをリアルタイムで確認できます! 🏃‍♂️💨",
                        "es": "Registra lugares importantes como 'Mis Lugares'.\n¡Puedes verificar las entradas y salidas de los miembros del grupo en tiempo real! 🏃‍♂️💨",
                        "fr": "Enregistrez les lieux importants comme 'Mes lieux'.\nVous pouvez vérifier les entrées et sorties des membres du groupe en temps réel ! 🏃‍♂️💨",
                        "hi": "महत्वपूर्ण स्थानों को 'मेरे स्थान' के रूप में पंजीकृत करें।\nआप समूह के सदस्यों के प्रवेश और निकास की रियल-टाइम जांच कर सकते हैं! 🏃‍♂️💨"
                    }
                },
                {
                    "title": {
                        "ko": "스마트한 그룹원 관리 📱",
                        "en": "Smart Group Member Management 📱",
                        "vi": "Quản lý thành viên nhóm thông minh 📱",
                        "id": "Manajemen Anggota Grup Pintar 📱",
                        "th": "การจัดการสมาชิกในกลุ่มอย่างชาญฉลาด 📱",
                        "ja": "スマートなグループメンバー管理 📱",
                        "es": "Gestión inteligente de miembros del grupo 📱",
                        "fr": "Gestion intelligente des membres du groupe 📱",
                        "hi": "स्मार्ट समूह सदस्य प्रबंधन 📱"
                    },
                    "content": {
                        "ko": "'내 장소'에 중요 지점을 등록하세요.\n그룹원이 등록한 장소에 오면 바로 알려드립니다! 🌟",
                        "en": "Register important locations as 'My Places'.\nYou'll be notified right away when group members arrive at registered places! 🌟",
                        "vi": "Đăng ký những địa điểm quan trọng làm 'Địa điểm của tôi'.\nBạn sẽ được thông báo ngay lập tức khi thành viên nhóm đến những địa điểm đã đăng ký! 🌟",
                        "id": "Daftarkan lokasi penting sebagai 'Tempat Saya'.\nAnda akan segera diberitahu ketika anggota grup tiba di tempat yang terdaftar! 🌟",
                        "th": "ลงทะเบียนสถานที่สำคัญเป็น 'สถานที่ของฉัน'\nคุณจะได้รับการแจ้งเตือนทันทีเมื่อสมาชิกในกลุ่มมาถึงสถานที่ที่ลงทะเบียนไว้! 🌟",
                        "ja": "重要な場所を'マイプレイス'に登録してください。\nグループメンバーが登録された場所に到着したらすぐに通知されます! 🌟",
                        "es": "Registra lugares importantes como 'Mis Lugares'.\n¡Serás notificado de inmediato cuando los miembros del grupo lleguen a los lugares registrados! 🌟",
                        "fr": "Enregistrez les lieux importants comme 'Mes lieux'.\nVous serez immédiatement averti lorsque les membres du groupe arriveront aux lieux enregistrés ! 🌟",
                        "hi": "महत्वपूर्ण स्थानों को 'मेरे स्थान' के रूप में पंजीकृत करें।\nजब समूह के सदस्य पंजीकृत स्थानों पर पहुंचेंगे तो आपको तुरंत सूचित किया जाएगा! 🌟"
                    }
                },
            ]

            plt_condition = "내장소 입력 독려 push 발송"
            plt_memo = "내장소 입력 독려 push 발송"

            member_list = smap_group_detail_t.get_my_location_list()

            selected_message = random.choice(txt_key_messages)

            for member in member_list:
                try:
                    push_title = selected_message["title"][member.mt_lang]
                    push_content = selected_message["content"][member.mt_lang]
                    push_txt = push_content
                    push_url = "https://app2.smap.site/location"
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_19():
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            logger.info(f"ps_19 앱 한번 실행해줍쇼. push 실행")

            txt_key_messages = [
                {
                    "title": {
                        "ko": "중요한 순간을 놓치지 마세요! ⏰",
                        "en": "Don't miss important moments! ⏰",
                        "vi": "Đừng bỏ lỡ những khoảnh khắc quan trọng! ⏰",
                        "id": "Jangan lewatkan momen penting! ⏰",
                        "th": "อย่าพลาดช่วงเวลาสำคัญ! ⏰",
                        "ja": "大切な瞬間を見逃さないでください! ⏰",
                        "es": "¡No te pierdas momentos importantes! ⏰",
                        "fr": "Ne manquez pas les moments importants ! ⏰",
                        "hi": "महत्वपूर्ण क्षणों को मिस न करें! ⏰"
                    },
                    "content": {
                        "ko": "위치 접근을 '항상 허용'으로 설정하면 더 정확하게 기록할 수 있어요.",
                        "en": "Setting location access to 'Always Allow' will allow for more accurate recording.",
                        "vi": "Đặt quyền truy cập vị trí thành 'Luôn cho phép' sẽ giúp ghi lại chính xác hơn.",
                        "id": "Mengatur akses lokasi ke 'Selalu Izinkan' akan memungkinkan perekaman yang lebih akurat.",
                        "th": "การตั้งค่าการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา' จะทำให้บันทึกได้แม่นยำยิ่งขึ้น",
                        "ja": "位置情報アクセスを'常に許可'に設定すると、より正確に記録できます。",
                        "es": "Configurar el acceso a la ubicación en 'Permitir siempre' permitirá un registro más preciso.",
                        "fr": "Définir l'accès à la localisation sur 'Toujours autoriser' permettra un enregistrement plus précis.",
                        "hi": "स्थान एक्सेस को 'हमेशा अनुमति दें' पर सेट करने से अधिक सटीक रिकॉर्डिंग हो सकेगी।"
                    }
                },
                {
                    "title": {
                        "ko": "끊김 없는 연결을 경험해보세요! 🔗",
                        "en": "Experience seamless connectivity! 🔗",
                        "vi": "Trải nghiệm kết nối liền mạch! 🔗",
                        "id": "Rasakan konektivitas yang lancar! 🔗",
                        "th": "สัมผัสประสบการณ์การเชื่อมต่อที่ราบรื่น! 🔗",
                        "ja": "シームレスな接続を体験してください! 🔗",
                        "es": "¡Experimenta una conectividad ininterrumpida! 🔗",
                        "fr": "Faites l'expérience d'une connectivité transparente ! 🔗",
                        "hi": "निरंतर कनेक्टिविटी का अनुभव करें! 🔗"
                    },
                    "content": {
                        "ko": "위치 접근을 '항상 허용'으로 설정하면 앱이 더 원활하게 작동해요.",
                        "en": "Setting location access to 'Always Allow' will make the app run more smoothly.",
                        "vi": "Đặt quyền truy cập vị trí thành 'Luôn cho phép' sẽ giúp ứng dụng hoạt động trơn tru hơn.",
                        "id": "Mengatur akses lokasi ke 'Selalu Izinkan' akan membuat aplikasi berjalan lebih lancar.",
                        "th": "การตั้งค่าการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา' จะทำให้แอพทำงานได้ราบรื่นยิ่งขึ้น",
                        "ja": "位置情報アクセスを'常に許可'に設定すると、アプリがより滑らかに動作します。",
                        "es": "Configurar el acceso a la ubicación en 'Permitir siempre' hará que la aplicación funcione de manera más fluida.",
                        "fr": "Définir l'accès à la localisation sur 'Toujours autoriser' permettra à l'application de fonctionner plus en douceur.",
                        "hi": "स्थान एक्सेस को 'हमेशा अनुमति दें' पर सेट करने से ऐप अधिक सुचारू रूप से चलेगा।"
                    }
                },
                {
                    "title": {
                        "ko": "앗, 기록이 중단됐어요! 😥",
                        "en": "Oops, the recording has been interrupted! 😥",
                        "vi": "Úi, ghi chép đã bị gián đoạn! 😥",
                        "id": "Ups, rekaman telah terputus! 😥",
                        "th": "อ๊ะ การบันทึกถูกขัดจังหวะแล้ว! 😥",
                        "ja": "おっと、記録が中断されました! 😥",
                        "es": "¡Ups, la grabación se ha interrumpido! 😥",
                        "fr": "Oups, l'enregistrement a été interrompu ! 😥",
                        "hi": "उफ्फ, रिकॉर्डिंग बाधित हो गई है! 😥"
                    },
                    "content": {
                        "ko": "위치 접근을 '항상 허용'으로 바꾸면 기록이 끊기지 않아요!",
                        "en": "Changing location access to 'Always Allow' will prevent the recording from being interrupted!",
                        "vi": "Thay đổi quyền truy cập vị trí thành 'Luôn cho phép' sẽ ngăn không cho ghi chép bị gián đoạn!",
                        "id": "Mengubah akses lokasi ke 'Selalu Izinkan' akan mencegah rekaman terputus!",
                        "th": "การเปลี่ยนการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา' จะป้องกันไม่ให้การบันทึกถูกขัดจังหวะ!",
                        "ja": "位置情報アクセスを'常に許可'に変更すると、記録が中断されなくなります!",
                        "es": "¡Cambiar el acceso a la ubicación a 'Permitir siempre' evitará que la grabación se interrumpa!",
                        "fr": "Changer l'accès à la localisation sur 'Toujours autoriser' empêchera l'interruption de l'enregistrement !",
                        "hi": "स्थान एक्सेस को 'हमेशा अनुमति दें' पर बदलने से रिकॉर्डिंग बाधित नहीं होगी!"
                    }
                },
                {
                    "title": {
                        "ko": "정확한 알림을 받고 싶으신가요? 🔔",
                        "en": "Want to receive accurate notifications? 🔔",
                        "vi": "Bạn có muốn nhận thông báo chính xác không? 🔔",
                        "id": "Ingin menerima pemberitahuan yang akurat? 🔔",
                        "th": "ต้องการรับการแจ้งเตือนที่แม่นยำหรือไม่? 🔔",
                        "ja": "正確な通知を受け取りたいですか? 🔔",
                        "es": "¿Quieres recibir notificaciones precisas? 🔔",
                        "fr": "Voulez-vous recevoir des notifications précises ? 🔔",
                        "hi": "क्या आप सटीक अधिसूचनाएं प्राप्त करना चाहते हैं? 🔔"
                    },
                    "content": {
                        "ko": "위치 접근을 '항상 허용'으로 바꾸거나 앱을 자주 실행해주세요!",
                        "en": "Change location access to 'Always Allow' or launch the app frequently!",
                        "vi": "Hãy thay đổi quyền truy cập vị trí thành 'Luôn cho phép' hoặc mở ứng dụng thường xuyên hơn!",
                        "id": "Ubah akses lokasi ke 'Selalu Izinkan' atau sering luncurkan aplikasi!",
                        "th": "เปลี่ยนการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา' หรือเปิดแอพบ่อยๆ!",
                        "ja": "位置情報アクセスを'常に許可'に変更するか、アプリを頻繁に起動してください!",
                        "es": "¡Cambia el acceso a la ubicación a 'Permitir siempre' o inicia la aplicación con frecuencia!",
                        "fr": "Changez l'accès à la localisation sur 'Toujours autoriser' ou lancez l'application fréquemment !",
                        "hi": "स्थान एक्सेस को 'हमेशा अनुमति दें' पर बदलें या ऐप को बार-बार लॉन्च करें!"
                    }
                },
                {
                    "title": {
                        "ko": "알림이 오지 않나요? 🤔",
                        "en": "Not receiving notifications? 🤔",
                        "vi": "Không nhận được thông báo? 🤔",
                        "id": "Tidak menerima pemberitahuan? 🤔",
                        "th": "ไม่ได้รับการแจ้งเตือนหรือ? 🤔",
                        "ja": "通知が来ませんか? 🤔",
                        "es": "¿No estás recibiendo notificaciones? 🤔",
                        "fr": "Vous ne recevez pas de notifications ? 🤔",
                        "hi": "क्या अधिसूचनाएं प्राप्त नहीं हो रही हैं? 🤔"
                    },
                    "content": {
                        "ko": "위치 접근을 '항상 허용'으로 설정하거나 앱을 자주 실행해보세요.",
                        "en": "Set location access to 'Always Allow' or try launching the app frequently.",
                        "vi": "Hãy đặt quyền truy cập vị trí thành 'Luôn cho phép' hoặc thử mở ứng dụng thường xuyên hơn.",
                        "id": "Atur akses lokasi ke 'Selalu Izinkan' atau coba luncurkan aplikasi lebih sering.",
                        "th": "ตั้งค่าการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา' หรือลองเปิดแอพบ่อยๆ",
                        "ja": "位置情報アクセスを'常に許可'に設定するか、アプリを頻繁に起動してみてください。",
                        "es": "Configura el acceso a la ubicación en 'Permitir siempre' o intenta iniciar la aplicación con frecuencia.",
                        "fr": "Définissez l'accès à la localisation sur 'Toujours autoriser' ou essayez de lancer l'application fréquemment.",
                        "hi": "स्थान एक्सेस को 'हमेशा अनुमति दें' पर सेट करें या ऐप को बार-बार लॉन्च करने की कोशिश करें।"
                    }
                },
                {
                    "title": {
                        "ko": "위치 정보 업데이트! 🔄",
                        "en": "Location Information Update! 🔄",
                        "vi": "Cập nhật thông tin vị trí! 🔄",
                        "id": "Pembaruan Informasi Lokasi! 🔄",
                        "th": "อัปเดตข้อมูลสถานที่! 🔄",
                        "ja": "位置情報の更新! 🔄",
                        "es": "¡Actualización de información de ubicación! 🔄",
                        "fr": "Mise à jour des informations de localisation ! 🔄",
                        "hi": "स्थान जानकारी अपडेट! 🔄"
                    },
                    "content": {
                        "ko": "정확한 알림을 위해 위치 접근을 '항상 허용'으로 설정해주세요.",
                        "en": "To receive accurate notifications, set location access to 'Always Allow'.",
                        "vi": "Để nhận thông báo chính xác, hãy đặt quyền truy cập vị trí thành 'Luôn cho phép'.",
                        "id": "Untuk menerima pemberitahuan yang akurat, atur akses lokasi ke 'Selalu Izinkan'.",
                        "th": "เพื่อรับการแจ้งเตือนที่แม่นยำ ให้ตั้งค่าการเข้าถึงสถานที่เป็น 'อนุญาตตลอดเวลา'",
                        "ja": "正確な通知を受け取るには、位置情報アクセスを'常に許可'に設定してください。",
                        "es": "Para recibir notificaciones precisas, configure el acceso a la ubicación en 'Permitir siempre'.",
                        "fr": "Pour recevoir des notifications précises, définissez l'accès à la localisation sur 'Toujours autoriser'.",
                        "hi": "सटीक अधिसूचनाएं प्राप्त करने के लिए, स्थान एक्सेस को 'हमेशा अनुमति दें' पर सेट करें।"
                    }
                },
            ]

            plt_condition = "앱 한번 실행해줍쇼. push 발송"
            plt_memo = "앱 한번 실행해줍쇼. push 발송"

            member_list = member_location_log_t.find_members_with_outdated_location()

            selected_message = random.choice(txt_key_messages)

            for member in member_list:
                try:
                    push_title = selected_message["title"][member.mt_lang]
                    push_content = selected_message["content"][member.mt_lang]
                    push_txt = push_content
                    push_url = "https://app2.smap.site/log"
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_20():
        from smap.models import member_location_log_t, member_t
        from smap import db
        import logging

        with app.app_context():
            logger.info("ps_20 member_location_log_t와 member_t 동기화 실행")

            try:
                # 최근 1시간 이내에 위치 데이터가 있는 멤버 찾기
                one_hour_ago = dt.now() - datetime.timedelta(hours=1)
                active_members = member_location_log_t.query.filter(
                    member_location_log_t.mlt_wdate >= one_hour_ago
                ).order_by(member_location_log_t.mlt_idx.desc()).all()

                for member_log in active_members:
                    # 해당 멤버의 가장 최근 위치 정보 가져오기
                    latest_location = member_location_log_t.query.filter_by(mt_idx=member_log.mt_idx).order_by(member_location_log_t.mlt_idx.desc()).first()

                    if latest_location:
                        # Member_t 테이블에서 해당 멤버 찾기
                        member = member_t.find_one_idx(mt_idx=latest_location.mt_idx)

                        if member:
                            # 멤버 정보 업데이트
                            member.mt_lat = latest_location.mlt_lat
                            member.mt_long = latest_location.mlt_long
                            member.mt_udate = dt.now()  # Use the alias dt

                            db.session.commit()
                            logger.info(f"멤버 {member.mt_idx}의 위치 정보가 업데이트되었습니다.")
                        else:
                            logger.warning(f"멤버 {latest_location.mt_idx}를 찾을 수 없습니다.")
                    else:
                        logger.warning(f"멤버 {member_log.mt_idx}의 최신 위치 정보를 찾을 수 없습니다.")

                logger.info("ps_20 동기화가 완료되었습니다.")

            except Exception as e:
                logger.error(f"ps_20 동기화 중 오류 발생: {str(e)}")
                db.session.rollback()


    

    def log_error(error):
        logger.error(error)

    def admin_send_push(msg):
        from smap.models import member_t

        try:
            admin = member_t.find_one_idx(272)
            logger.info(f"admin_send_push - admin : {admin}")
            push_result = send_push(
                admin.mt_token_id, "Error Msg", msg, "https://app2.smap.site/log"
            )
        except Exception as e:
            log_error(f"Error sending push notification to admin: {e}")
            pass

    def split_list(lst, n):
        """리스트를 n개의 하위 리스트로 분할합니다."""
        k, m = divmod(len(lst), n)
        return [lst[i * k + min(i, m) : (i + 1) * k + min(i + 1, m)] for i in range(n)]

    def send_push_to_group(group, message, plt_condition, plt_memo, push_url):
        from smap.models import smap_group_detail_t

        """그룹에 푸시 알림을 보냅니다."""
        push_title = message["title"]
        push_content = message["content"]
        push_txt = push_content

        for member in group:
            try:
                push_result = send_push(
                    member.mt_token_id, push_title, push_content, push_url
                )
                push_log_add(
                    member.mt_idx,
                    None,
                    plt_condition,
                    plt_memo,
                    push_title,
                    push_txt,
                    push_result,
                )
            except Exception as e:
                log_error(
                    f"Error sending push notification to member {member.mt_idx}: {e}"
                )

    def schedule_push_notifications(func, hour, minute, job_id_prefix):
        """푸시 알림을 예약합니다."""
        with app.app_context():
            messages, plt_condition, plt_memo, push_url = func()

            if func.__name__ == "ps_17":
                member_list = smap_group_detail_t.get_owner_leader_list()
            elif func.__name__ == "ps_18":
                member_list = smap_group_detail_t.get_my_location_list()
            else:
                logger.error(f"Unknown function: {func.__name__}")
                return

            groups = split_list(list(member_list), 10)

            for i, group in enumerate(groups):
                scheduled_time = datetime.now().replace(
                    hour=int(hour), minute=int(minute)
                ) + timedelta(minutes=i * 10)
                message = random.choice(messages)
                schedule.add_job(
                    send_push_to_group,
                    "date",
                    run_date=scheduled_time,
                    args=[group, message, plt_condition, plt_memo, push_url],
                    id=f"{job_id_prefix}_{i}",
                )

    schedule = BackgroundScheduler(daemon=True, timezone="Asia/Seoul")
    schedule.add_job(ps_1, "interval", seconds=30, id="ps_1")
    schedule.add_job(ps_2, "interval", seconds=30, id="ps_2")
    schedule.add_job(ps_3, "interval", seconds=30, id="ps_3")
    schedule.add_job(ps_4, "interval", seconds=30, id="ps_4")
    schedule.add_job(ps_5, "interval", minutes=1, id="ps_5")
    schedule.add_job(ps_6, "cron", minute="*/5", id="ps_6")
    # schedule.add_job(ps_7, 'cron', hour="20", minute="00", id='ps_7')
    # schedule.add_job(ps_8, 'cron', hour="10", minute="00", id='ps_8')
    # 평일 (월요일부터 금요일) 오전 8시 10분에 실행
    schedule.add_job(
        ps_9, "cron", day_of_week="mon-fri", hour=8, minute=10, id="ps_9_weekdays"
    )
    # 주말 (토요일과 일요일) 오전 9시에 실행
    schedule.add_job(ps_9, "cron", day_of_week="sat,sun", hour=9, id="ps_9_weekends")
    logging.info("Scheduled job ps_9: 오전 7시 - 날씨 - 해당일 일기예보 발송")
    schedule.add_job(ps_10, "interval", hours=1, id="ps_10")
    schedule.add_job(ps_11, "interval", hours=1, id="ps_11")
    schedule.add_job(ps_12, "cron", hour="21", minute="00", id="ps_12")
    schedule.add_job(ps_13, "interval", hours=1, id="ps_13")
    schedule.add_job(ps_14, "cron", hour="*/1", id="ps_14")
    schedule.add_job(
        ps_15, "cron", minute="*/20", hour="8-19", id="ps_15"
    )  # Run every 20 minutes from 8 AM to 5:59 PM
    schedule.add_job(ps_16, "cron", hour="0", minute="0", id="ps_16")
    # 작업 예약 - 매 정각마다, 오전 8시부터 오후 6시까지만 실행
    schedule.add_job(ps_17, "cron", hour="18", minute="00", id="ps_17_18")  # 로그
    schedule.add_job(ps_18, "cron", hour="14", minute="00", id="ps_18_14")  # 내장소
    schedule.add_job(ps_19, "cron", hour="19", minute="30", id="ps_18_11")  # 앱실행
    schedule.add_job(ps_20, "interval", seconds=30, id="ps_20") # 위치 동기화

    # Start the scheduler
    schedule.start()

    """Request Json Error"""

    def on_json_loading_failed_return_dict(e):
        return {}

    """REQUEST HOOK"""

    @app.before_request
    def before_request():
        session.permanent = True
        app.permanent_session_lifetime = timedelta(hours=24)

        request.on_json_loading_failed = on_json_loading_failed_return_dict
        g.db = db.session
        g.config = config

    @app.teardown_request
    def teardown_request(exception):
        if hasattr(g, "db"):
            g.db.close()

    @app.errorhandler(404)
    def page_404(error):
        return render_template("/404.html"), 404

    @app.errorhandler(502)
    def page_502(error):
        return render_template("/502.html"), 502

    @app.route("/popup")
    def popup():
        logger.info(f"popup redirect")
        return render_template("popup.html")  # 또는 필요한 로직 실행

    return app
