import json
from flask import Flask, jsonify, session, g
from flask_restx import Namespace, Resource, fields, reqparse, inputs

from smap.apis.lib_func import get_group_member
from smap.apis.weather import Weather

ns = Namespace(
    'defs_test',
    description='클래스 테스트'
)

parser = reqparse.RequestParser()

@ns.route('/')
class wt_text(Resource):
    @ns.expect(parser)
    def get(self):
        #서울 명동으로 위치 지정
        mlt_lat = '35.24434580038307'
        mlt_long = '129.09006880929678'
        
        #단기예보
        categorys = ['TMN', 'TMX', 'POP']
        user_weather = Weather()  
        response1 = user_weather.requestForecast(mlt_lat, mlt_long, 6, '', 0)
        today_weather1 = user_weather.parseWeather(response1, categorys)
        print(today_weather1)
        
        return today_weather1
    
@ns.route('/member_test')
class member_test(Resource):
    @ns.expect(parser)
    def get(self):
        ts_group_data = get_group_member(96, 149);
        return_dict = {}
        if ts_group_data['member'] != '' or not ts_group_data['member'] is None:
            return_dict['member'] = ts_group_data['member']
        if ts_group_data['order'] != '' or not ts_group_data['order'] is None:
            return_dict['order'] = ts_group_data['order']
        if ts_group_data['leader'] != '' or not ts_group_data['leader'] is None:
            return_dict['leader'] = ts_group_data['leader']
        
        return return_dict