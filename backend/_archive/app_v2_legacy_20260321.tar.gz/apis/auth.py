from flask import jsonify
from flask_restx import Namespace, Resource, reqparse
from smap.models import member_t
from typing import Dict, Any

ns = Namespace(
    'auth',
    description='기기토큰으로 인증처리'
)

parser = reqparse.RequestParser()
parser.add_argument('mt_token_id', required=True, help='앱토큰 아이디')

SUCCESS = "true"
FAILURE = "false"

def create_response(success: str, title: str, message: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
    return {
        "success": success,
        "title": title,
        "message": message,
        "data": data
    }

@ns.route('/')
class auth(Resource):
    @ns.expect(parser)
    def post(self) -> Dict[str, Any]:
        try:
            args = parser.parse_args()
            mt_token_id = args['mt_token_id']

            row_mt = member_t.find_one_token(mt_token_id)

            if row_mt:
                data_json = {'mt_idx': row_mt.mt_idx}
                return jsonify(create_response(SUCCESS, "인증성공", "인증에 성공했습니다.", data_json))
            else:
                return jsonify(create_response(FAILURE, "인증실패", "신규앱토큰 아이디입니다."))
        except Exception as e:
            return jsonify(create_response(FAILURE, "오류 발생", str(e)))