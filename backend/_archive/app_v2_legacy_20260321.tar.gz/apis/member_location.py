from flask import Flask, jsonify, session, g
from flask_restx import Namespace, Resource, fields, reqparse, inputs
from smap.models import member_location_log_t
import datetime

ns = Namespace(
    'member_location',
    description = '위치정보 등록(단건)'
)

parser = reqparse.RequestParser()
parser.add_argument('mt_idx', required=True, help='회원idx')
parser.add_argument('mlt_lat', required=True, help='위도')
parser.add_argument('mlt_long', required=True, help='경도')
parser.add_argument('mlt_speed', required=False, help='속도(숫자만)')
parser.add_argument('mlt_battery', required=False, help='배터리(%)')
parser.add_argument('mlt_fine_location', required=False, help='위치정확도 Y,N')
parser.add_argument('mlt_location_chk', required=False, help='위치정보허용여부 Y,N')
parser.add_argument('mt_health_work', required=False, help='걸음수(숫자만)')

@ns.route('/')
class member_location(Resource):
    @ns.expect(parser)

    def post(self):
        now = datetime.datetime.now()

        args = parser.parse_args()

        mt_idx = args['mt_idx']
        mlt_lat = args['mlt_lat']
        mlt_long = args['mlt_long']
        mlt_speed = args['mlt_speed']
        mlt_battery = args['mlt_battery']
        mlt_fine_location = args['mlt_fine_location']
        mlt_location_chk = args['mlt_location_chk']
        mt_health_work = args['mt_health_work']

        if float(mlt_lat) > 0.0 or float(mlt_long) > 0.0:
            rtn_data = {"success": "false", "title": "위치정보 등록 실패", "message": "위도 또는 경도 값이 올바르지 않습니다.", "data": None}
        else:
            location_input = member_location_log_t.Member_location_log_t(
                mt_idx = mt_idx,
                mlt_lat = mlt_lat,
                mlt_long = mlt_long,
                mlt_speed = mlt_speed,
                mlt_battery = mlt_battery,
                mlt_fine_location = mlt_fine_location,
                mlt_location_chk = mlt_location_chk,
                mt_health_work = mt_health_work,
                mlt_wdate = now.strftime('%Y-%m-%d %H:%M:%S'),
            )
            g.db.add(location_input)
            g.db.commit()

            rtn_data = {"success": "true", "title": "위치정보 등록 성공", "message": "위치정보 등록에 성공했습니다.", "data": None}

        return jsonify(rtn_data)

