import sys
import time
import json
import requests
import datetime
from smap.apis.weather import Weather
from flask import Flask, jsonify, session, g
from flask_restx import Namespace, Resource, fields, reqparse, inputs
from smap.apis.lib_func import kmTom, send_push, get_group_member, schedule_status_update
from smap.apis.lib_func import location_status_update, schedule_push_status_update, get_latlong_to_add_naver
from smap.apis.lib_func import get_weather_emoji

from smap.models import smap_schedule_t, member_location_log_t, smap_group_detail_t, member_t
from smap.models import smap_location_t, smap_group_t, push_fcm_t

ns = Namespace(
    'push_test',
    description = 'push 모델 테스트'
)

parser = reqparse.RequestParser()

#30초 - 장소알림 - 일정에 입력한 장소의 50미터 반경에 들어왔을때 테스트 api 로그저장x
@ns.route('/01_50_in')
class push_text_50In(Resource):
    @ns.expect(parser)
    def post(self):
        #일정이 있는 모든 스케쥴 리스트
        push_list = smap_schedule_t.get_now_schedule_in_members()
        for pt in push_list:
            puth_type = 1 #1개인 2그룹
            mt_idx = None
            
            if(pt.sgt_idx is None and pt.sgdt_idx == 0):
                puth_type = 1
                mt_idx = str(pt.mt_idx)
            else: 
                puth_type = 2
                sgt_idx = str(pt.sgt_idx)
                #그룹에서 해당 회원의 mt_idx가져오기
                group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                if not group_member is None:
                    mt_idx = str(group_member.mt_idx)
            
            if not mt_idx is None:
                #해당 회원의 마지막 위치값과 장소의 위치값 비교
                member_location = member_location_log_t.getDistance(str(pt.sst_location_lat), str(pt.sst_location_long), mt_idx)
                if not member_location is None:
                    distance = kmTom(member_location.distance)
                    if(50.0 >= distance):
                        try:
                            #본인이 작성한 일정
                            if puth_type == 1:
                                #본인의 정보 가져오기
                                member = member_t.find_one_idx(mt_idx)
                                mt_name = member.mt_name
                                if not member.mt_nickname is None and member.mt_nickname != '':
                                    mt_name = member.mt_nickname
                                push_title = str(mt_name)+'님! \''+str(pt.sst_title)+'\'장소에 곧 도착하실 것 같아요.'
                                push_content = ''
                                send_push(member.mt_token_id, push_title, push_content)
                            else:
                                group_data = get_group_member(sgt_idx, mt_idx)
                                # if group_data['order'] != '':
                                #     push_title = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소에 거의 도착했습니다.'
                                #     push_content = ''
                                #     # send_push(group_data['order']['mt_token_id'], push_title, push_content)
                                # if group_data['leader'] != '':
                                #     push_title = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소에 거의 도착했습니다.'
                                #     push_content = ''
                                #     # send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                                # if group_data['member'] != '':
                                #     push_title = group_data['member']['mt_name']+'님! 예정된 장소에 거의 도착했습니다.'
                                #     push_content = group_data['order']['mt_name']+'/'+group_data['leader']['mt_name']+'님께 알렸어요.'
                                #     # send_push(group_data['member']['mt_token_id'], push_title, push_content)
                                    
                                if group_data['order'] != '':
                                    #오더 전송
                                    group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 \''+str(pt.sst_title)+'\' 장소에 거의 도착했어요.'
                                    group_data['order']['push_content'] = ''
                                        
                                if group_data['leader'] != '':
                                    #리더 전송
                                    group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 \''+str(pt.sst_title)+'\' 장소에 거의 도착했어요.'
                                    group_data['leader']['push_content'] = ''
                                    
                                if group_data['member'] != '':
                                    #그룹원 전송
                                    group_data['member']['push_title'] = group_data['member']['mt_name']+'님! \''+str(pt.sst_title)+'\'장소에 곧 도착하실 것 같아요.'
                                    if group_data['member']['group_ment'] != '':
                                        group_data['member']['push_content'] = group_data['member']['group_ment']+'님에게도 알려드렸습니다.'
                                    else:
                                        group_data['member']['push_content'] = ''
                                        
                                for key, group in group_data.items():
                                    if group != '' and key != 'member':
                                        send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                                        # print(group, file=sys.stderr)
                                    
                                # 진입 여부 수정
                                schedule_result = schedule_status_update(pt.sst_idx, 'Y')
                        except Exception as e:
                            print(e)

#30초 - 장소알림 - 일정에 입력한 장소의 50미터 반경에 나왔을때 테스트 api 로그저장x
@ns.route('/02_50_out')                                
class push_text_50Out(Resource):
    @ns.expect(parser)
    def post(self):
        #일정이 있는 모든 스케쥴 리스트
        push_list = smap_schedule_t.get_now_schedule_out_members()
        for pt in push_list:
            puth_type = 1 #1개인 2그룹
            mt_idx = ''
            if(pt.sgt_idx is None and pt.sgdt_idx == 0):
                puth_type = 1
                mt_idx = str(pt.mt_idx)
            else: 
                puth_type = 2
                sgt_idx = str(pt.sgt_idx)
                #그룹에서 해당 회원의 mt_idx가져오기
                group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                mt_idx = str(group_member.mt_idx)
            
            if not mt_idx is None:
                #해당 회원의 마지막 위치값과 장소의 위치값 비교
                member_location = member_location_log_t.getDistance(str(pt.sst_location_lat), str(pt.sst_location_long), mt_idx)
                if not member_location is None:
                    distance = kmTom(member_location.distance)
                    if(50.0 <= distance):
                        try:
                            #본인이 작성한 일정
                            if puth_type == 1:
                                #본인의 정보 가져오기
                                member = member_t.find_one_idx(mt_idx)
                                push_title = str(mt_name)+'님! \''+str(pt.sst_title)+'\'장소에서 출발하신 것 확인했습니다.'
                                push_content = ''
                                send_push(member.mt_token_id, push_title, push_content)
                            else:
                                group_data = get_group_member(sgt_idx, mt_idx)
                                # if group_data['order'] != '':
                                #     push_title = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소를 방금 떠났어요.'
                                #     push_content = '오더'
                                #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
                                # if group_data['leader'] != '':
                                #     push_title = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소를 방금 떠났어요.'
                                #     push_content = '리더'
                                #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                                # if group_data['member'] != '':
                                #     push_title = group_data['member']['mt_name']+'님! 예정된 장소에서 조금 이동하신 것 같아요.'
                                #     push_content = group_data['order']['mt_name']+'/'+group_data['leader']['mt_name']+'님에게도 이 사실을 전달했습니다'
                                #     send_push(group_data['member']['mt_token_id'], push_title, push_content)
                                    
                                if group_data['order'] != '':
                                    group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소를 방금 떠났어요.'
                                    group_data['order']['push_content'] = ''
                                
                                if group_data['leader'] != '':
                                    group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 예정된 장소를 방금 떠났어요.'
                                    group_data['leader']['push_content'] = ''
                                
                                if group_data['member'] != '':
                                    group_data['member']['push_title'] = group_data['member']['mt_name']+'님! 예정된 장소에서 조금 이동하신 것 같아요.'
                                    if group_data['member']['group_ment'] != '':
                                        group_data['member']['push_content'] = group_data['member']['group_ment']+'님에게도 이 사실을 전달했습니다'
                                    else:
                                        group_data['member']['push_content'] = ''
                                    
                                for key, group in group_data.items():
                                    send_push(group['mt_token_id'], group['push_title'], group['push_content']) 
                            
                            #진입 여부 수정
                            schedule_result = schedule_status_update(pt.sst_idx , 'N')
                        except Exception as e:
                            print(e)
                                
#30초 - 장소알림 - 일정에 입력한 장소의 50미터 반경에 들어왔을때 테스트 api 로그저장x
@ns.route('/03_50_ms_in')
class push_text_ms_50In(Resource):
    @ns.expect(parser)                                
    def post(self):
        #삭제되지 않은 내장소 리스트 가져오기
        push_list = smap_location_t.getInMyplaysList()
        for pt in push_list:
            if not pt is None:
                if pt.slt_enter_alarm.value == 'Y':
                    #해당 회원의 마지막 위치값과 장소의 위치값 비교
                    member_location = member_location_log_t.getDistance(str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx))
                    if not member_location is None:
                        distance = kmTom(member_location.distance)
                        if(50.0 >= distance):
                            group_detail = smap_group_detail_t.get_one_idx(pt.sgdt_idx)
                            #장소 정보 가져오기
                            location_detail = smap_location_t.get_one_idx(pt.slt_idx)
                            if not group_detail is None:
                                group_data = get_group_member(group_detail.sgt_idx, pt.mt_idx)
                                # if group_data['order'] != '':
                                #     push_title = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 정한 장소에 방금 도착했어요'
                                #     push_content = ''
                                #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
                                # if group_data['leader'] != '':
                                #     push_title = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 정한 장소에 방금 도착했어요'
                                #     push_content = ''
                                #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                                if group_data['order'] != '':
                                    group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 약속한 장소(\''+str(location_detail.slt_title)+'\')에 도착했습니다!'
                                    group_data['order']['push_content'] = ''
                                                
                                if group_data['leader'] != '':
                                    group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 약속한 장소(\''+str(location_detail.slt_title)+'\')에 도착했습니다!'
                                    group_data['leader']['push_content'] = ''
                                
                                for key, group in group_data.items():
                                    if group != '' and key != 'member':
                                        send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                                
                                #진입여부 수정
                                location_result = location_status_update(pt.slt_idx, 'Y')

#30초 - 장소알림 - 일정에 입력한 장소의 50미터 반경에 벗어났을때 테스트 api 로그저장x
@ns.route('/04_50_ms_out')
class push_text_ms_50Out(Resource):
    @ns.expect(parser)
    def post(self):
        #삭제되지 않은 내장소 리스트 가져오기
        push_list = smap_location_t.getOutMyplaysList()
        for pt in push_list:
            if not pt is None:
                if pt.slt_enter_alarm.value == 'Y':
                    #해당 회원의 마지막 위치값과 장소의 위치값 비교
                    member_location = member_location_log_t.getDistance(str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx))
                    if not member_location is None:
                        distance = kmTom(member_location.distance)
                        if(50.0 <= distance):              
                            group_detail = smap_group_detail_t.get_one_idx(pt.sgdt_idx)
                            #장소 정보 가져오기
                            location_detail = smap_location_t.get_one_idx(pt.slt_idx)
                            if not group_detail is None:
                                group_data = get_group_member(group_detail.sgt_idx, pt.mt_idx)
                                # if group_data['order'] != '':
                                #     push_title = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 정한 장소에 방금 떠났어요!'
                                #     push_content = ''
                                #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
                                # if group_data['leader'] != '':
                                #     push_title = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 정한 장소에 방금 떠났어요!'
                                #     push_content = ''
                                #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                                if group_data['order'] != '':
                                    group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 약속한 장소(\''+str(location_detail.slt_title)+'\')에서 출발했습니다!'
                                    group_data['order']['push_content'] = ''
                                
                                if group_data['leader'] != '':
                                    group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님이 우리가 약속한 장소(\''+str(location_detail.slt_title)+'\')에서 출발했습니다!'
                                    group_data['leader']['push_content'] = ''
                                    
                                for key, group in group_data.items():
                                    if group != '' and key != 'member':
                                        send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                            #진입여부 수정
                            print(pt.slt_idx)
                            location_result = location_status_update(pt.slt_idx, 'N')

#1분 - 일정알림 - 일정에 입력한 알림주기에 알림
@ns.route('/05_schedule_push')
class schedule_push(Resource):
    @ns.expect(parser)
    def post(self):
        sst_pick_type_arr = {
            'minute': '분',
            'hour': '시간',
            'day': '일'
        }
        
        push_list = smap_schedule_t.get_now_schedule_push()
        for pt in push_list:
            puth_type = 1 #1개인 2그룹
            mt_idx = None
            
            if(pt.sgt_idx is None and pt.sgdt_idx == 0):
                puth_type = 1
                mt_idx = str(pt.mt_idx)
            else: 
                puth_type = 2
                sgt_idx = str(pt.sgt_idx)
                #그룹에서 해당 회원의 mt_idx가져오기
                group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                if not group_member is None:
                    mt_idx = str(group_member.mt_idx)
            if not mt_idx is None:                
                if puth_type == 1:
                    #본인의 정보 가져오기
                    member = member_t.find_one_idx(mt_idx)
                    mt_name = member.mt_name
                    if not member.mt_nickname is None and member.mt_nickname != '':
                        mt_name = member.mt_nickname
                    push_title = str(mt_name)+'님! \''+str(pt.sst_title)+'\' 일정 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                    push_content = ''
                    send_push(member.mt_token_id, push_title, push_content)
                    schedule_push_status_update(pt.sst_idx, 'Y')
                else:
                    group_data = get_group_member(sgt_idx, mt_idx)
                    # if group_data['order'] != '':
                    #     group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님의 \''+pt.sst_title+'\' 일정 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                    #     group_data['order']['push_content'] = ''
                    #     # send_push(group_data['order']['mt_token_id'], push_title, push_content)
                        
                    # if group_data['leader'] != '':
                    #     push_title = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님의 '+pt.sst_title+' 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                    #     push_content = ''
                    #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                    # if group_data['member'] != '':
                    #     push_title = group_data['member']['mt_name']+'님! '+pt.sst_title+' 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                    #     push_content = ''
                    #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                    # schedule_push_status_update(pt.sst_idx, 'Y')
                    if group_data['order'] != '':
                        #오더 전송
                        group_data['order']['push_title'] = group_data['order']['mt_name']+'님! '+group_data['member']['mt_name']+'님의 \''+str(pt.sst_title)+'\' 일정 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                        group_data['order']['push_content'] = ''
                    
                    if group_data['leader'] != '':
                        #리더 전송
                        group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님! '+group_data['member']['mt_name']+'님의 \''+str(pt.sst_title)+'\' 일정 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                        group_data['leader']['push_content'] = ''
                        
                    if group_data['member'] != '':
                        group_data['member']['push_title'] = group_data['member']['mt_name']+'님! \''+str(pt.sst_title)+'\' 일정 시작 '+str(pt.sst_pick_result)+sst_pick_type_arr[pt.sst_pick_type]+'전입니다.'
                        group_data['member']['push_content'] = ''
                        
                    for key, group in group_data.items():
                        if group != '':
                            send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                    schedule_push_status_update(pt.sst_idx, 'Y')
                    
#5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없는 경우
@ns.route('/06_schedule_move_push')
class schedule_move_push(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = smap_schedule_t.start_befor30()
        for pt in push_list:
            member_location = member_location_log_t.getDistance(str(pt.sst_location_lat), str(pt.sst_location_long), str(pt.mt_idx))
            if not member_location is None:
                distance = kmTom(member_location.distance)
                if 500.0 < distance:
                    group_data = get_group_member(pt.sgt_idx, pt.mt_idx)
                    # if group_data['order'] != '':
                    #     push_title = group_data['order']['mt_name']+'님!'+group_data['member']['mt_name']+'님이 다음 '+pt.sst_title+'을 위해서 이동을 시작해야할 시간이에요.'
                    #     push_content = ''
                    #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
                    
                    # if group_data['leader'] != '':
                    #     push_title = group_data['leader']['mt_name']+'님!'+group_data['member']['mt_name']+'님이 다음 '+pt.sst_title+'을 위해서 이동을 시작해야할 시간이에요.'
                    #     push_content = ''
                    #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                        
                    # if group_data['member'] != '':
                    #     push_title = group_data['member']['mt_name']+'님이 다음 '+pt.sst_title+'을 위해서 이동을 시작해야해요.'
                    #     push_content = ''
                    #     send_push(group_data['member']['mt_token_id'], push_title, push_content)
                    
                    if group_data['order'] != '':
                        #오더 전송
                        group_data['order']['push_title'] = group_data['order']['mt_name']+'님!'+group_data['member']['mt_name']+'님이 다음 \''+str(pt.sst_title)+'\'을 위해서 이동을 시작해야할 시간이에요.'
                        group_data['order']['push_content'] = ''
                    
                    if group_data['leader'] != '':
                        #리더 전송
                        group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님!'+group_data['member']['mt_name']+'님이 다음 \''+str(pt.sst_title)+'\'을 위해서 이동을 시작해야할 시간이에요.'
                        group_data['leader']['push_content'] = ''
                    
                    if group_data['member'] != '':
                        #그룹원 전송
                        group_data['member']['push_title'] = group_data['member']['mt_name']+'님이 다음 \''+str(pt.sst_title)+'\'을 위해서 이동을 시작해야해요.'
                        group_data['member']['push_content'] = ''

                    for key, group in group_data.items():
                        if group != '':
                            return_push = send_push(group['mt_token_id'], group['push_title'], group['push_content'])                    
        
#구독 - 가입 후 11일 경과
@ns.route('/07_signup_d11')
class signup_d11(Resource):
    @ns.expect(parser)
    def post(self):
        after_3_day = datetime.datetime.now()+datetime.timedelta(days=3)
        after_3_day_s = after_3_day.strftime('%m월%d일')
        push_list = member_t.getNotJoinGroup11()
        for pt in push_list:
            if pt.sgdt_owner_chk == 'Y':
                mt_name = pt.mt_name
                if not pt.mt_nickname is None and pt.mt_nickname != '':
                    mt_name = pt.mt_nickname
                    
                push_title = str(mt_name)+'님, 안녕하세요!'
                push_content = '3일 후인 '+after_3_day_s+'부터 알림 서비스가 중단되고, 일부 광고가 표시될 예정입니다. 하지만 걱정하지마세요. 여전히 기본 서비스는 이용할 수 있습니다.'
                send_push(pt.mt_token_id, push_title, push_content)
                
#구독 - 가입 후 13일 경과
@ns.route('/08_signup_d13')
class signup_d13(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = member_t.getNotJoinGroup13()
        for pt in push_list:
            if pt.sgdt_owner_chk == 'Y':
                mt_name = pt.mt_name
                if not pt.mt_nickname is None and pt.mt_nickname != '':
                    mt_name = pt.mt_nickname
                    
                push_title = str(mt_name)+'님, 안녕하세요!'
                push_content = '내일부터 알림 서비스는 제공되지 않고, 일부 광고가 표시될 예정입니다. 기본 서비스는 여전히 이용하실 수 있답니다. 알림 서비스를 계속 이용하고 싶으신 분이나, 광고 없는 편안한 환경을 원하시는 분들께는 유료버전을 추천드립니다.'
                send_push(pt.mt_token_id, push_title, push_content)
                
#날씨 - 해당일 일기예보 발송
@ns.route('/09_user_now_weather')
class user_now_weather(Resource):
    @ns.expect(parser)
    def post(self):
        now= datetime.datetime.now()
        now = now.strftime('%Y-%m-%d')
        push_list = member_t.getTokenList()
        print('now:'+now, file=sys.stderr)
        for pt in push_list:
            # if (pt.mt_weather_date is None or now != pt.mt_weather_date.strftime('%Y-%m-%d')) or (pt.mt_weather_pop is None or pt.mt_weather_tmn is None or pt.mt_weather_tmx is None):
                # print('mt_weather_date:'+pt.mt_weather_date.strftime('%Y-%m-%d'), file=sys.stderr)
                #최근 위치 가져오기
                member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
                if member_info is None:
                    #해당 계정 마지막 로그 구하기
                    member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                    if member_info is None:
                        #서울 명동으로 위치 지정
                        mlt_lat = '37.56668050000000'
                        mlt_long = '126.97841470000000'
                    else:
                        mlt_lat = member_info.mlt_lat
                        mlt_long = member_info.mlt_long
                else: 
                    mlt_lat = member_info.mlt_lat
                    mlt_long = member_info.mlt_long

                #단기예보
                categorys = ['TMN', 'TMX', 'POP']
                user_weather = Weather()  
                response1 = user_weather.requestForecast(mlt_lat, mlt_long, 6, '', 0)
                today_weather1 = user_weather.parseWeather(response1, categorys)
                coords = str(mlt_long)+','+str(mlt_lat)
                
                #사용자 위치 주소가져오기
                user_add = get_latlong_to_add_naver(coords)
                        
                push_title = '(SMAP) 날씨 정보 ☔'
                push_content = user_add['area1']+' '+user_add['area2']+'/'+user_add['area3'] + '\n강수확률 : '+today_weather1['POP']+'\n최저 : '+today_weather1['TMN']+'\n최고 : '+today_weather1['TMX']
                if pt.mt_idx == 256 or pt.mt_idx == 98 or pt.mt_idx == 80:
                    print('mt_idx:'+str(pt.mt_idx), file=sys.stderr)
                    send_push(pt.mt_token_id, push_title, push_content)
            # else:
            #     push_title = now_weekday+' '+pt.mt_sido+' '+pt.mt_gu+'/'+pt.mt_dong
            #     push_content = '강수량 - '+str(pt.mt_weather_pop)+'% 최저 - '+str(pt.mt_weather_tmn)+'℃ 최고 - '+str(pt.mt_weather_tmx)+'℃'
            #     send_push(pt.mt_token_id, push_title, push_content)

#사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우
@ns.route('/10_user_signin_3')
class user_signin_3(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = member_t.getSignIn3()
        for pt in push_list:
            sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
            sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
            sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)
            
            if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgt_cnt == 0:
                push_title = '안녕하세요! 서비스를 더 잘 이용하시려면 그룹을 생성해보세요.'
                push_content = '그룹을 통해 그룹원의 위치를 파악하고, 일정을 공유할 수 있습니다.'
                send_push(pt.mt_token_id, push_title, push_content)
        
#사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우
@ns.route('/11_user_signin_24')
class user_signin_24(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = member_t.getSignIn24()
        for pt in push_list:
            sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
            sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
            sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)
            
            if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgt_cnt == 0:
                push_title = '안녕하세요! 아직 그룹을 생성하지 않으셨네요.'
                push_content = '그룹을 만들어보시면 서비스를 더욱 효과적으로 이용할실 수 있습니다. 지금 바로 그룹을 만들어보세요.'
                send_push(pt.mt_token_id, push_title, push_content)
        
#배터리 - 19시에 배터리체크 후 50% 이하
@ns.route('/12_user_bt_50')
class user_bt_50(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = smap_group_detail_t.get_member_list()
        for pt in push_list:
            #해당 학생의 마지막로그 가져오기
            mlt_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
            if not mlt_info is None:
                if mlt_info.mlt_battery <= 50:
                    group_data = get_group_member(pt.sgt_idx, pt.mt_idx)
                    # if group_data['order'] != '':
                    #     #오더 전송
                    #     push_title = group_data['order']['mt_name']+'님, 안녕하세요!'+group_data['member']['mt_name']+'님의 핸드폰 배터리가 50%미만으로 확인되었습니다.'
                    #     push_content = '중요한 알림을 놓치지 않도록 '+group_data['member']['mt_name']+'님께 충전을 권유해주세요.'
                    #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
                    # if group_data['leader'] != '':
                    #     #리더 전송
                    #     push_title = group_data['leader']['mt_name']+'님, 안녕하세요!'+group_data['member']['mt_name']+'님의 핸드폰 배터리가 50%미만으로 확인되었습니다.'
                    #     push_content = '중요한 알림을 놓치지 않도록 '+group_data['member']['mt_name']+'님께 충전을 권유해주세요.'
                    #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
                    # if group_data['member'] != '':
                    #     #학생 전송
                    #     push_title = group_data['member']['mt_name']+'님 안녕하세요. 현재 핸드폰 배터리가 50%미만으로 확인되네요.'
                    #     push_content = '서비스를 원활하게 이용하시려면 충전을 해주세요.'
                    #     send_push(group_data['member']['mt_token_id'], push_title, push_content)
                    if group_data['order'] != '':
                        #오더 전송
                        group_data['order']['push_title'] = group_data['order']['mt_name']+'님, 안녕하세요!'+group_data['member']['mt_name']+'님의 핸드폰 배터리가 50%미만으로 확인되었습니다.'
                        group_data['order']['push_content'] = '중요한 알림을 놓치지 않도록 '+group_data['member']['mt_name']+'님께 충전을 권유해주세요.'
                    
                    if group_data['leader'] != '':
                        #리더 전송
                        group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님, 안녕하세요!'+group_data['member']['mt_name']+'님의 핸드폰 배터리가 50%미만으로 확인되었습니다.'
                        group_data['leader']['push_content'] = '중요한 알림을 놓치지 않도록 '+group_data['member']['mt_name']+'님께 충전을 권유해주세요.'
                    
                    if group_data['member'] != '':
                        #그룹원 전송
                        group_data['member']['push_title'] = group_data['member']['mt_name']+'님 안녕하세요. 현재 핸드폰 배터리가 50%미만으로 확인되네요.'
                        group_data['member']['push_content'] = '서비스를 원활하게 이용하시려면 충전을 해주세요.'
                    
                    for key, group in group_data.items():
                        if group != '':
                            send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                            
#사용자 권한 확인
@ns.route('/13_group_member_chk')
class group_member_chk(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = smap_group_detail_t.joinGroup1()
        for pt in push_list:
            group_data = get_group_member(pt.sgt_idx, pt.mt_idx)
            # if group_data['order'] != '' :
            #     #오더발송
            #     push_title = group_data['order']['mt_name']+'님, 안녕하세요!'
            #     push_content = '현재'+group_data['member']['mt_name']+'님의 핸드폰에서 필요한 권한 설정이 확인되지 않았습니다.'
            #     send_push(group_data['order']['mt_token_id'], push_title, push_content)
            
            # if group_data['leader'] != '':
            #     #리더발송
            #     push_title = group_data['leader']['mt_name']+'님, 안녕하세요!'
            #     push_content = '현재'+group_data['member']['mt_name']+'님의 핸드폰에서 필요한 권한 설정이 확인되지 않았습니다.'
            #     send_push(group_data['leader']['mt_token_id'], push_title, push_content)
            if group_data['order'] != '' :
                #오더발송
                group_data['order']['push_title'] = group_data['order']['mt_name']+'님, 안녕하세요!'
                group_data['order']['push_content'] = '현재'+group_data['member']['mt_name']+'님의 핸드폰에서 필요한 권한 설정이 확인되지 않았습니다.'
            
            if group_data['leader'] != '':
                #리더발송
                group_data['leader']['push_title'] = group_data['leader']['mt_name']+'님, 안녕하세요!'
                group_data['leader']['push_content'] = '현재'+group_data['member']['mt_name']+'님의 핸드폰에서 필요한 권한 설정이 확인되지 않았습니다.'
                
            for key, group in group_data:
                if group != '' and key != 'member':
                    send_push(group['mt_token_id'], group['push_title'], group['push_content'])

#사용자 권한 확인
@ns.route('/14_push')
class push_send(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = push_fcm_t.find_push_list()
        for pt in push_list:
            push_title = pt.pft_title
            push_content = pt.pft_content
            push_url = None
            if not pt.pft_url is None or pt.pft_url != '':
                push_url = pt.pft_url
            if pt.pft_send_type == 1:
                #토큰이 있는 모든 멤버 가져오기
                member_list = member_t.getTokenList()
                for member in member_list:
                    if member.mt_idx == 80 or member.mt_idx == 98 or member.mt_idx == 256:
                        result_push = send_push(member.mt_token_id, push_title, push_content, push_url)
            elif pt.pft_send_type == 2:
                mt_list = json.loads(pt.pft_send_mt_idx)
                for mt_idx in mt_list:
                    member = member_t.find_one_idx(mt_idx)
                    if not member is None:
                        result_push = send_push(member.mt_token_id, push_title, push_content, push_url)
            elif pt.pft_send_type == 3:
                group_idx_list = json.loads(pt.pft_send_mt_idx)
                for group_idx in group_idx_list:
                    group_list = smap_group_detail_t.get_group(group_idx)
                    for group_member in group_list:
                        member = member_t.find_one_idx(group_member.mt_idx)
                        if not member is None:
                            result_push = send_push(member.mt_token_id, push_title, push_content, push_url)


#테스트
@ns.route('/test')
class test(Resource):
    @ns.expect(parser)
    def post(self):
        push_list = member_t.getTokenList()
        now = datetime.datetime.now()
        for pt in push_list:
            #최근 위치 가져오기
            member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
            if member_info is None:
                #해당 계정 마지막 로그 구하기
                member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                if member_info is None:
                    #서울 명동으로 위치 지정
                    mlt_lat = '37.56668050000000'
                    mlt_long = '126.97841470000000'
                else:
                    mlt_lat = member_info.mlt_lat
                    mlt_long = member_info.mlt_long
            else: 
                mlt_lat = member_info.mlt_lat
                mlt_long = member_info.mlt_long

            print('mt_id:'+str(pt.mt_id), file=sys.stderr)
            print('mlt_lat:'+str(mlt_lat), file=sys.stderr)
            print('mlt_long:'+str(mlt_long), file=sys.stderr)
            
            #단기예보
            categorys1 = ['TMN', 'TMX', 'POP']
            user_weather = Weather()
            response1 = user_weather.requestForecast(mlt_lat, mlt_long, 6, '', 0)
            today_weather1 = user_weather.parseWeather(response1, categorys1)
                            
            #초단기예보
            categorys2 = ['SKY', 'PTY']
            response2 = user_weather.requestForecast(mlt_lat, mlt_long, 0, '', 0)
            today_weather2 = user_weather.parseWeather(response2, categorys2)
            emoji = get_weather_emoji(today_weather2)
            
            #사용자 위치로 주소 가져오기
            coords = str(mlt_long)+','+str(mlt_lat)
            user_add = get_latlong_to_add_naver(coords)
            
            push_title = '[SMAP] 날씨 정보 '+str(emoji)#str(emoji)
            push_content = user_add['area1']+' '+user_add['area2']+'/'+user_add['area3']+'\n강수확률 : '+today_weather1['POP']+'\n최저기온 : '+today_weather1['TMN']+'\n최고기온 : '+today_weather1['TMX']
            
            print(push_title, file=sys.stderr)
            print(push_content, file=sys.stderr)
            if pt.mt_id == '01029565435':
                print('-'*50, file=sys.stderr)
            else:
                print('*'*50, file=sys.stderr)
            
            if pt.mt_id == '01033334444':
                send_push(pt.mt_token_id, push_title, push_content)
        # push_arr = [79, 98, 80]
        # for i in range(0, 30):
        #     print(i, file=sys.stderr)
        #     try:
        #         for idx in push_arr:
        #             pt = member_t.find_one_idx(idx)
        #             member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
        #             if member_info is None:
        #                 #해당 계정 마지막 로그 구하기
        #                 member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
        #                 if member_info is None:
        #                     #서울 명동으로 위치 지정
        #                     mlt_lat = '37.56668050000000'
        #                     mlt_long = '126.97841470000000'
        #                 else:
        #                     mlt_lat = member_info.mlt_lat
        #                     mlt_long = member_info.mlt_long
        #             else: 
        #                 mlt_lat = member_info.mlt_lat
        #                 mlt_long = member_info.mlt_long

        #             #단기예보
        #             categorys1 = ['TMN', 'TMX', 'POP']
        #             categorys2 = ['SKY', 'PTY']
        #             user_weather = Weather()
        #             try:
        #                 response1 = user_weather.requestForecast(mlt_lat, mlt_long, 6, '', 0)
        #                 today_weather1 = user_weather.parseWeather(response1, categorys1)
        #                 print(today_weather1, file=sys.stderr)
        #             except Exception as e:
        #                 response1 = user_weather.requestForecast(mlt_lat, mlt_long, 6, '', 0)
        #                 today_weather1 = user_weather.parseWeather(response1, categorys1)
                    
        #             try:
        #                 response2 = user_weather.requestForecast(mlt_lat, mlt_long, 0, '', 0)
        #                 today_weather2 = user_weather.parseWeather(response2, categorys2)
        #                 print(today_weather2, file=sys.stderr)
        #             except Exception as e:
        #                 response2 = user_weather.requestForecast(mlt_lat, mlt_long, 0, '', 0)
        #                 today_weather2 = user_weather.parseWeather(response2, categorys2)
                    
        #             emoji = get_weather_emoji(today_weather2)
        #             coords = str(mlt_long)+','+str(mlt_lat)
                        
                    #사용자 위치 주소가져오기
                    # user_add = get_latlong_to_add_naver(coords)
                                
                    # push_title = '(SMAP) 날씨 정보 '+str(i)+' '+str(emoji)
                    # push_content = user_add['area1']+' '+user_add['area2']+'/'+user_add['area3'] + '\n강수확률 : '+today_weather1['POP']+'\n최저 : '+today_weather1['TMN']+'\n최고 : '+today_weather1['TMX']
                    # print('mt_idx:'+str(pt.mt_idx), file=sys.stderr)
                    # print('-'*20)
                    # if pt.mt_idx == 80:
                    #     send_push(pt.mt_token_id, push_title, push_content)
            # except Exception as e:
            #     print(e, file=sys.stderr)