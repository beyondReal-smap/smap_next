from flask import Flask, jsonify, session, g
from requests.adapters import HTTPAdapter, Retry
from typing import Final
from smap.configs import Config
import requests
import datetime
import time
import math
import logging

logger = logging.getLogger(__name__)

XLIMIT:Final = 149
YLIMIT:Final = 253

PI:Final = math.asin(1.0) * 2.0
DEGRAD:Final = PI / 180.0
RADDEG:Final = 180.0 / PI

class Weather:
    map = {}
    def __init__(self):
        self.map['Re'] = 6371.00877 #지도반경
        self.map['grid'] = 5.0 #격자간격(km)
        self.map['slat1'] = 30.0 #표준위도1
        self.map['slat2'] = 60.0 #표준위도2
        self.map['olon'] = 126.0 #기준점 경도
        self.map['olat'] = 38.0 #기준점 위도
        self.map['xo'] = 210/self.map['grid'] #기준점 X좌표
        self.map['yo'] = 675/self.map['grid'] #기준점 Y좌표
        self.map['first'] = 0
        
    def requestForecast(self, lat, lon, type, reg_id, times=0, lang="ko"):
        response = None  # 초기화
        try:
            now = datetime.datetime.now().strftime('%Y%m%d')
            if times == 0:
                times = time.time()
            
            if type == 6:
                baseDate = now
                baseTime = "0200"
            elif type == 7:
                baseDate = now
                baseTime = "0600"
            else:
                baseDate, baseTime = Weather.getBaseDateTimeForecast4(times)
            
            # Weather.getXY(self, lat, lon)
            nx, ny = Weather.getXY(self, lat, lon)
            
            request = Weather.buildRequest(baseDate, baseTime, nx, ny, type, reg_id)
            response = Weather.getResponseForecast(request, type, lang, lat, lon)
        except Exception as e:
            logger.error(f"날씨 예보 요청 중 오류 발생: {e}")
        return response
    
    def buildRequest(baseDate, baseTime, nx, ny, type, reg_id):
        if type == 2 or type == 3:
            request = {
                "serviceKey": Config.SERVICE_KEY,
                "numOfRows": 100,
                "pageNo": 1,
                "dataType": "JSON",
                "regId": reg_id,
                "tmFc": baseDate+baseTime
            }
        else:
            request = {
                "serviceKey": Config.SERVICE_KEY,
                "numOfRows": 1000,
                "pageNo": 1,
                "dataType": "JSON",
                "base_date": baseDate,
                "base_time": baseTime, 
                "nx": nx, 
                "ny": ny
            }
        return request
    
    def getResponseForecast(request, type, lang, lat, lon):
        retries = Retry(total=5,
                backoff_factor=0.1,
                status_forcelist=[ 500, 502, 503, 504 ])
        s = requests.Session()
        s.mount("http://", HTTPAdapter(max_retries=5))
        s.mount("https://", HTTPAdapter(max_retries=5))
        
        payload = request
        if lang == "ko":
            if type == 6 or type == '6' :
                url = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst'
            elif type == 7 or type == '7':
                url = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtFcst'
            else:
                url = 'http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtFcst'
            res = s.get(url=url, params=payload, timeout=600)
            data = res.json()
            return data
        else:
            url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={Config.OPENWEATHERMAP_API_KEY}&units=metric&lang={lang}"
            response = requests.get(url)
            logger.info(f"ps_27 날씨 - 오픈웨더맵 요청 성공 : {response.json()}")
            return response.json()

    
    def parseWeather(self, response, categorys, lang="ko"):
        data = {}
        try:
            if lang == "ko":
                now = datetime.datetime.now().strftime('%Y%m%d')
                time = datetime.datetime.now().strftime('%H00')
                if not response is None and not response['response']['body']['items']['item'] is None :
                    list = response['response']['body']['items']['item']
                    if not list is None and len(list) > 0:
                        for row in list:
                            for category in categorys:
                                if category == row['category']:
                                    if row['fcstDate'] == now:
                                        if category == 'TMX':
                                            data[category] = str(row['fcstValue'])+"℃"
                                        elif category == 'TMN':
                                            data[category] = str(row['fcstValue'])+"℃"
                                        elif category == 'POP':
                                            if row['fcstTime'] == time:
                                                data[category] = str(row['fcstValue'])+"%"
                                        elif category == 'SKY':
                                            data[category] = Weather.getSKYCode(str(row['fcstValue']))
                                        elif category == 'PTY':
                                            data[category] = Weather.getPTYCode(str(row['fcstValue']))
                if 'TMX' in  categorys:
                    if data['TMX'] == '':
                        data['TMX'] = '-'
                
                if 'TMN' in  categorys:
                    if data['TMN'] == '':
                        data['TMN'] = '-'

                if 'POP' in  categorys:             
                    if data['POP'] == '':
                        data['POP'] = '-'
                
                if 'SKY' in  categorys:
                    if data['SKY'] == '':
                        data['SKY'] = '-'
                
                if 'PTY' in  categorys:
                    if data['PTY'] == '':
                        data['PTY'] = '0'
            else:
                logger.info(f"ps_27 날씨 - 오픈웨더맵 요청 성공 : {response}")
                logger.info(f"ps_27 날씨 - 오픈웨더맵 응답 데이터 : {response['main']}")
                logger.info(f"ps_27 날씨 - 오픈웨더맵 응답 데이터 : {response['weather']}")
                if 'main' in response:
                    data['TMN'] = f"{response['main']['temp_min']:.1f}℃"
                    data['TMX'] = f"{response['main']['temp_max']:.1f}℃"
                    data['POP'] = f"{response['main']['humidity']:.1f}%"
                if 'weather' in response and len(response['weather']) > 0:
                    owm_id = response['weather'][0]['id']
                    if owm_id == 800:
                        data['SKY'] = '1'  # 맑음
                    elif 801 <= owm_id <= 804:
                        data['SKY'] = '3'  # 구름 많음
                    elif 200 <= owm_id <= 781:
                        data['SKY'] = '4'  # 흐림
                    else:
                        data['SKY'] = '-' 

                    if 502 <= owm_id <= 511:
                        data['PTY'] = '1'  # 비
                    elif 611 <= owm_id <= 613:
                        data['PTY'] = '2'  # 진눈깨비
                    elif 600 <= owm_id <= 612:
                        data['PTY'] = '3'  # 눈
                    elif 520 <= owm_id <= 531:
                        data['PTY'] = '4'  # 소나기
                    elif 500 <= owm_id <= 501:
                        data['PTY'] = '6'  # 빗방울/눈날림
                    elif 615 <= owm_id <= 616:
                        data['PTY'] = '7'  # 눈날림
                    else:
                        data['PTY'] = '0'  # 없음
            
            return data                            
        except Exception as e:
            print(e)
            return {
                'TMX': '-',
                'TMN': '-',
                'POP': '-'
            }
    
    def getXY(self, lat, lon):
        x = 0
        y = 0
        x, y = Weather.map_conv(self, lon, lat, x, y, 0)
        return [x, y]

    def map_conv(self, lon, lat, x, y, code):
        lon1 = lat1 = x1 = y1 = 0.0
        
        if code == 0:
            lon1 = lon
            lat1 = lat
            x1, y1 = Weather.lamcproj(self, lon1, lat1, x1, y1, code)
            x = int(x1 + 1.5)
            y = int(y1 + 1.5)
            
            return [x, y]
        elif code == 1:
            x1 = x - 1
            y1 = y - 1
            lat1, lon1 = Weather.lamcproj(self, lon1, lat1, x1, y1, code)
            lon = lon1
            lat = lat1
            return [lon, lat]
            
    def lamcproj(self, lon, lat, x, y, code):
        re = self.map['Re']/self.map['grid']
        slat1 = self.map['slat1'] * DEGRAD
        slat2 = self.map['slat2'] * DEGRAD
        olon = self.map['olon'] * DEGRAD
        olat = self.map['olat'] * DEGRAD
        
        sn = math.tan(PI * 0.25 + slat2 * 0.5)/math.tan(PI * 0.25 + slat1 * 0.5)
        sn = math.log(math.cos(slat1)/math.cos(slat2)/math.log(sn))
        sf = math.tan(PI + 0.25 + slat1 * 0.5)
        sf = math.pow(sf, sn) * math.cos(slat1) / sn
        ro = math.tan(PI * 0.25 + olat * 0.5)
        ro = re * sf / math.pow(ro, sn)
        
        if code == 0:
            ra = math.tan(PI * 0.25 + float(lat) * DEGRAD * 0.5)
            ra = re * sf / math.pow(ra, sn)
            theta = float(lon) * DEGRAD - olon
            if theta > PI:
                theta = theta - 2.0 * PI
            if theta < -(PI):
                theta = theta + 2.0 * PI
            theta = theta * sn
            x = float(ra * math.sin(theta))+self.map['xo']
            y = float(ro - ra * math.cos(theta))+self.map['yo']
            
            return [x, y]
        else:
            xn = x - self.map['xo']
            yn = ro - y + self.map['yo']
            ra = math.sqrt(xn * xn + yn * yn)
            if sn < 0.0:
                ra = -ra
            alat = math.pow((re*sf/ra), (1.0/sn))
            alat = 2.0 * math.atan(alat) - PI * 0.5
            if abs(xn) <= 0.0:
                theta = 0.0
            else:
                if abs(yn) <= 0.0:
                    theta = PI * 0.5
                    if xn < 0.0:
                        theta = -theta
                    else:
                        theta = math.atan2(xn, xy)
            
            alon = theta/sn*olon
            lat = Weather.round_down(float(alat * RADDEG), 7)
            lon = Weather.round_down(float(alon * RADDEG), 7)
            
            return [lat, lon]
            
        
    def round_down(number, precision=2):
        fig = int(str(1).zfill(precision))
        return math.floor((number * fig)/fig)
    
    def getBaseDateTimeForecast4(times = 0):
        if times == 0:
            times = time.time()
        
        baseTime = "2300"
        baseDate = time.strftime('%Y%m%d', time.localtime(times))
        tm = time.strftime('%H%m', time.localtime(times))
        
        if tm < "0050":
            baseTime = "2330"
        elif tm < "0150":
            baseTime = "0030"
        elif tm < "0250":
            baseTime = "0130"
        elif tm < "0350":
            baseTime = "0230"
        elif tm < "0450":
            baseTime = "0330"
        elif tm < "0550":
            baseTime = "0430"
        elif tm < "0650":
            baseTime = "0530"
        elif tm < "0750":
            baseTime = "0630"
        elif tm < "850":
            baseTime = "0730"
        elif tm < "950":
            baseTime = "0830"
        elif tm < "1050":
            baseTime = "0930"
        elif tm < "1150":
            baseTime = "1030"
        elif tm < "1250":
            baseTime = "1130"
        elif tm < "1350":
            baseTime = "1230"
        elif tm < "1450":
            baseTime = "1330"
        elif tm < "1550":
            baseTime = "1430"
        elif tm < "1650":
            baseTime = "1530"
        elif tm < "1750":
            baseTime = "1630"
        elif tm < "1850":
            baseTime = "1730"
        elif tm < "1950":
            baseTime = "1830"
        elif tm < "2050":
            baseTime = "1930"
        elif tm < "2150":
            baseTime = "2030"
        elif tm < "2250":
            baseTime = "2130"
        elif tm < "2350":
            baseTime = "2230"
        
        return [baseDate, baseTime]
    
    def getSKYCode(code):
        result = ""
        
        if code == '1':
            result = "맑음"
        elif code == '3':
            result = "구름많음"
        elif code == '4':
            result = "흐림"
        else:
            result = "-"
        
        return code

    def getPTYCode(code='0'):
        result = ""
        
        if code == '0':
            result = "-"
        elif code == '1':
            result = "비"
        elif code == '2':
            result = "진눈개비"
        elif code == '3':
            result = "눈"
        elif code == '4':
            result = "소나기"
        elif code == '5':
            result = "소나기"
        elif code == '6':
            result = "빗방울/눈날림"
        elif code == '7':
            result = "눈날림"
        else:
            result = "-"

        return code