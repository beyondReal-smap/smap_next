from flask import Flask, jsonify, session, g
import logging
import datetime
import requests
import json
import os
import sys
import firebase_admin
from firebase_admin import credentials, messaging
from smap.configs import Config
from smap.models import smap_group_detail_t, member_t, smap_schedule_t, smap_location_t

# 로거 설정
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


def kmTom(km):
    return km * 1000


def send_push(token, p_title, p_content, push_url=None):
    if not token:
        return {"result": False, "msg": "토큰 없음"}

    cred_path = Config.FCM_JSON_PATH
    cred = credentials.Certificate(cred_path)

    try:
        firebase_admin.get_app()
    except ValueError:
        firebase_admin.initialize_app(cred)

    message = create_message(token, p_title, p_content, push_url)

    try:
        messaging.send(message)
        return {"result": True}
    except Exception as e:
        return {"result": False, "msg": str(e)}


def create_message(token, p_title, p_content, push_url):
    message_data = {
        "title": p_title,
        "body": p_content,
    }
    if push_url:
        message_data["event_url"] = push_url

    return messaging.Message(
        data=message_data,
        notification=messaging.Notification(title=p_title, body=p_content),
        android=messaging.AndroidConfig(
            priority="high", notification=messaging.AndroidNotification(sound="default")
        ),
        apns=messaging.APNSConfig(
            payload=messaging.APNSPayload(aps=messaging.Aps(sound="default"))
        ),
        token=token,
    )


def send_push_group(tokens, p_titles, p_contents):
    return "test"

def get_group_member2(sgt_idx, mt_idx):
    try:
        return_dict = {
            "member": {},
            "owner": get_owner_info2(sgt_idx),
            "leader": get_leader_info2(sgt_idx),
        }

        return_dict["member"] = get_member_info2(mt_idx, return_dict)

        # logger.debug(
        #     f"ps_21 내장소 방문(get_group_member2) - return_dict: {return_dict}"
        # )

        return return_dict
    except Exception as e:
        logger.error(f"ps_21 내장소 방문(get_group_member2) - error: {e}")
        return {"member": {}, "owner": {}, "leader": {}}


def get_owner_info2(sgt_idx):
    group_owner = smap_group_detail_t.get_one_owner2(sgt_idx)
    if group_owner and isinstance(group_owner, dict):
        owner = member_t.find_one_idx(group_owner.get('mt_idx'))
        if owner:
            return format_member_info(owner, "오너")
    # logger.debug(f"get_owner_info2 - group_owner: {group_owner}")
    return {}


def get_leader_info2(sgt_idx):
    group_leader = smap_group_detail_t.get_one_leader2(sgt_idx)
    if group_leader and isinstance(group_leader, dict):
        leader = member_t.find_one_idx(group_leader.get('mt_idx'))
        if leader:
            return format_member_info(leader, "리더")
    # logger.debug(f"get_leader_info2 - group_leader: {group_leader}")
    return {}


def get_group_member(sgt_idx, mt_idx):
    return_dict = {"member": {}, "order": {}, "leader": {}}

    return_dict["order"] = get_order_info(sgt_idx)
    return_dict["leader"] = get_leader_info(sgt_idx)
    return_dict["member"] = get_member_info(mt_idx, return_dict)

    return return_dict


def get_order_info(sgt_idx):
    group_order = smap_group_detail_t.get_one_order(sgt_idx)
    if group_order:
        order = member_t.find_one_idx(group_order.mt_idx)
        return format_member_info(order, "오너")
    return {}


def get_leader_info(sgt_idx):
    leader_order = smap_group_detail_t.get_one_leader(sgt_idx)
    if leader_order:
        leader = member_t.find_one_idx(leader_order.mt_idx)
        return format_member_info(leader, "리더")
    return {}


def get_member_info(mt_idx, return_dict):
    member = member_t.find_one_idx(mt_idx)
    if member:
        member_info = format_member_info(member, "멤버")
        member_info["group_ment"] = create_group_ment(member, return_dict)
        return member_info
    return {}

def get_member_info2(mt_idx, return_dict):
    member = member_t.find_one_idx(mt_idx)
    if member:
        member_info = format_member_info(member, "멤버")
        member_info["group_ment"] = create_group_ment2(member, return_dict)
        return member_info
    return {}

def format_member_info(member, default_name):
    mt_name = default_name
    if member.mt_name:
        mt_name = member.mt_nickname or member.mt_name
    return {
        "mt_token_id": member.mt_token_id,
        "mt_idx": member.mt_idx,
        "mt_name": mt_name,
        "mt_lang": member.mt_lang,
    }


def create_group_ment(member, return_dict):
    group_ment = []
    if return_dict["order"] and return_dict["order"]["mt_idx"] != member.mt_idx:
        group_ment.append(return_dict["order"]["mt_name"])
    if (
        return_dict["leader"]
        and return_dict["leader"]["mt_idx"] != member.mt_idx
        and return_dict["order"]["mt_idx"] != member.mt_idx
    ):
        group_ment.append(return_dict["leader"]["mt_name"])
    return "/".join(group_ment)

def create_group_ment2(member, return_dict):
    group_ment = []
    if return_dict["owner"] and return_dict["owner"]["mt_idx"] != member.mt_idx:
        group_ment.append(return_dict["owner"]["mt_name"])
    if (
        return_dict["leader"]
        and return_dict["leader"]["mt_idx"] != member.mt_idx
        and return_dict["owner"]["mt_idx"] != member.mt_idx
    ):
        group_ment.append(return_dict["leader"]["mt_name"])
    return "/".join(group_ment)

def get_latlong_to_add_naver(coords):
    url = "https://naveropenapi.apigw.ntruss.com/map-reversegeocode/v2/gc"
    headers = {
        "X-NCP-APIGW-API-KEY-ID": Config.NCPCLIENTID,
        "X-NCP-APIGW-API-KEY": Config.NCPCLIENTSECRET,
    }
    payload = {
        "coords": coords,
        "sourcecrs": "epsg:4326",
        "output": "json",
        "orders": "admcode",
    }

    try:
        res = requests.get(url=url, params=payload, headers=headers, timeout=120)
        data = res.json()

        if data["status"]["code"] == 0:
            region = data["results"][0]["region"]
            return {
                "area1": region["area1"]["name"],
                "area2": region["area2"]["name"],
                "area3": region["area3"]["name"],
            }
    except Exception:
        pass

    return {"area1": "서울특별시", "area2": "중구", "area3": "명동"}

def get_address_from_google_maps(coords):
    url = "https://maps.googleapis.com/maps/api/geocode/json"
    params = {
        "latlng": coords,
        "key": Config.GOOGLE_MAPS_API_KEY,
    }

    try:
        res = requests.get(url, params=params, timeout=120)
        data = res.json()

        if data["status"] == "OK":
            return {
                "formatted_address": data["results"][0]["formatted_address"],
                "area1": next((component["long_name"] for component in data["results"][0]["address_components"] if "administrative_area_level_1" in component["types"]), ""),  # 시도
                "area2": next((component["long_name"] for component in data["results"][0]["address_components"] if "administrative_area_level_2" in component["types"]), ""),  # 구
                "area3": next((component["long_name"] for component in data["results"][0]["address_components"] if "locality" in component["types"] or "sublocality_level_1" in component["types"]), "")  # 동
            }
    except Exception:
        pass

    return {"formatted_address": "주소를 찾을 수 없습니다.", "components": {}}


def get_weather_emoji(data):
    sky_emoji = {"1": "☀️", "3": "⛅", "4": "☁️"}
    pty_emoji = {
        "0": "☀️",
        "1": "🌧️",
        "2": "🌨️",
        "3": "❄️",
        "4": "🌧️",
        "5": "🌧️",
        "6": "🌨️",
        "7": "🌨️",
    }

    if data["SKY"] in ["1", "3", "4"]:
        return sky_emoji.get(data["SKY"], "☀️")
    return pty_emoji.get(data["PTY"], "☀️")


def get_weather_sky(sky):
    sky_emoji = {
        "1": "⛅",
        "2": "☁️",
        "3": "☁️",
        "4": "🌧️",
        "5": "🌧️",
        "6": "🌨️",
        "7": "⚡",
        "8": "☀️",
    }
    return sky_emoji.get(sky, "☀️")


# push_test에서만 사용되는 함수들
def schedule_status_update(sst_idx, sst_in_chk):
    try:
        schedule = smap_schedule_t.get_one_idx(sst_idx)
        schedule.sst_in_chk = sst_in_chk
        g.db.commit()
        return True
    except Exception as e:
        print(e)
        return False


def schedule_push_status_update(sst_idx, sst_schedule_chk):
    try:
        schedule = smap_schedule_t.get_one_idx(sst_idx)
        schedule.sst_schedule_chk = sst_schedule_chk
        g.db.commit()
        return True
    except Exception as e:
        print(e)
        return False


def location_status_update(slt_idx, slt_enter_chk):
    try:
        location = smap_location_t.get_one_idx(slt_idx)
        location.slt_enter_chk = slt_enter_chk
        g.db.commit()
        return True
    except Exception as e:
        print(e)
        return False
