from flask import Flask, jsonify, session, g
from flask_restx import Namespace, Resource, fields, reqparse, inputs
from smap.models import member_location_log_t
import datetime
import json

ns = Namespace(
    'member_location_json',
    description = '위치정보 등록(JSON)'
)

parser = reqparse.RequestParser()
parser.add_argument('mt_idx', required=True, help='회원idx')
parser.add_argument('mlt_battery', required=False, help='배터리(%)')
parser.add_argument('mlt_fine_location', required=False, help='위치정확도 Y,N')
parser.add_argument('mlt_location_chk', required=False, help='위치정보허용여부 Y,N')
parser.add_argument('mt_health_work', required=False, help='걸음수(숫자만)')
parser.add_argument('mt_gps_data', required=True, help='위도, 경도, 속도, 정확도, 시간 json')

@ns.route('/')
class member_location_json(Resource):
    @ns.expect(parser)

    def post(self):
        now = datetime.datetime.now()

        args = parser.parse_args()

        mt_idx = args['mt_idx']
        mlt_battery = args['mlt_battery']
        mlt_fine_location = args['mlt_fine_location']
        mlt_location_chk = args['mlt_location_chk']
        mt_health_work = args['mt_health_work']
        mt_gps_data = json.loads(args['mt_gps_data'])

        for i in mt_gps_data['mlt_gps_data']:
            mlt_lat = i['mlt_lat']
            mlt_long = i['mlt_long']
            mlt_speed = i['mlt_speed']
            mlt_accuacy = i['mlt_accuacy']
            mlt_gps_time = i['mlt_gps_time']

            if float(mlt_lat) > 0.0 and float(mlt_long) > 0.0:
                location_input = member_location_log_t.Member_location_log_t(
                    mt_idx = mt_idx,
                    mlt_lat = mlt_lat,
                    mlt_long = mlt_long,
                    mlt_speed = mlt_speed,
                    mlt_battery = mlt_battery,
                    mlt_fine_location = mlt_fine_location,
                    mlt_location_chk = mlt_location_chk,
                    mt_health_work = mt_health_work,
                    mlt_accuacy = mlt_accuacy,
                    mlt_gps_time = mlt_gps_time,
                    mlt_wdate = now.strftime('%Y-%m-%d %H:%M:%S'),
                )
                g.db.add(location_input)
                g.db.commit()

        rtn_data = {"success": "true", "title": "위치정보 등록 성공", "message": "위치정보 등록에 성공했습니다.", "data": None}

        return jsonify(rtn_data)

