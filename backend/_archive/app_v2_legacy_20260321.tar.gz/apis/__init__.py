from flask import Blueprint
from flask_restx import Api

from smap.apis.auth import ns as auth
from smap.apis.member_location import ns as member_location
from smap.apis.member_location_json import ns as member_location_json
from smap.apis.fcm_sendone import ns as fcm_sendone
from smap.apis.push_test import ns as push_test
from smap.apis.defs_test import ns as defs_test

blueprint = Blueprint('api', __name__, url_prefix='/api')

api = Api(
    blueprint,
    title='SMAP PYTHON APIS',
    version='1.0',
    doc=False
)

api.add_namespace(auth)
api.add_namespace(member_location)
api.add_namespace(member_location_json)
api.add_namespace(fcm_sendone)
api.add_namespace(push_test)
api.add_namespace(defs_test)
