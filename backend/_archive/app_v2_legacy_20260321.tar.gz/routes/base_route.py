from flask import Blueprint, request, render_template, redirect, session, g
import json
import datetime
from smap.configs import Config
now = datetime.datetime.now()

Name = 'SMAP'
bp = Blueprint(Name, __name__)

@bp.route('/', methods=['get'])
def index():
    return render_template('index.html')

