import datetime
from smap import db
from flask import Flask
from sqlalchemy import text, not_

app = Flask(__name__)


class Member_t(db.Model):
    mt_idx = db.Column(db.Integer, primary_key=True)
    mt_level = db.Column(db.Integer, nullable=True)
    mt_status = db.Column(db.Integer, nullable=True)
    mt_id = db.Column(db.String(200), primary_key=True)
    mt_token_id = db.Column(db.String(255), nullable=True)
    mt_name = db.Column(db.String(50), nullable=True)
    mt_nickname = db.Column(db.String(50), nullable=True)
    mt_wdate = db.Column(db.DateTime, nullable=True)
    mt_lat = db.Column(db.Numeric(16, 14), nullable=True)
    mt_long = db.Column(db.Numeric(17, 14), nullable=True)
    mt_sido = db.Column(db.String(20), nullable=True)
    mt_gu = db.Column(db.String(20), nullable=True)
    mt_dong = db.Column(db.String(20), nullable=True)
    mt_weather_pop = db.Column(db.Integer, nullable=True)
    mt_weather_tmn = db.Column(db.Integer, nullable=True)
    mt_weather_tmx = db.Column(db.Integer, nullable=True)
    mt_weather_sky = db.Column(db.Integer, nullable=True)
    mt_weather_date = db.Column(db.DateTime, nullable=True)
    mt_udate = db.Column(db.DateTime, nullable=True)
    mt_lang = db.Column(db.String(2), nullable=True)
    mt_email = db.Column(db.String(200), nullable=True)

def find_one_email(mt_email):
    return Member_t.query.filter_by(mt_email=mt_email).first()

def find_one_idx(mt_idx):
    return Member_t.query.filter_by(mt_idx=mt_idx).first()


def find_one_mt_id(mt_id):
    return Member_t.query.filter_by(mt_id=mt_id).first()


def find_one_token(mt_token_id):
    return Member_t.query.filter_by(mt_token_id=mt_token_id).first()


def getNotJoinGroup11():
    before_11 = datetime.datetime.now() + datetime.timedelta(days=-11)
    before_11_sday = before_11.strftime("%Y-%m-%d 00:00:00")
    before_11_eday = before_11.strftime("%Y-%m-%d 23:59:59")

    sql_txt = "select a1.*, a2.sgdt_owner_chk from member_t a1 "
    sql_txt += " left join smap_group_detail_t a2 on a1.mt_idx = a2.mt_idx"
    sql_txt += (
        " where (a1.mt_level = 2 and a1.mt_wdate between '"
        + before_11_sday
        + "' and '"
        + before_11_eday
        + "')"
    )
    sql_txt += " and (a2.sgdt_owner_chk = 'Y' and a2.sgdt_discharge = 'N' and a2.sgdt_exit = 'N' and a2.sgdt_show = 'Y')"
    sql_txt += " group by a1.mt_idx"
    sql = text(sql_txt)
    sql_list = db.session.execute(sql)
    return sql_list


def getNotJoinGroup3():
    before_3 = datetime.datetime.now() + datetime.timedelta(days=-3)
    before_3_sday = before_3.strftime("%Y-%m-%d 00:00:00")
    before_3_eday = before_3.strftime("%Y-%m-%d 23:59:59")

    sql_txt = "select a1.*, a2.sgdt_owner_chk from member_t a1 "
    sql_txt += " left join smap_group_detail_t a2 on a1.mt_idx = a2.mt_idx"
    sql_txt += (
        " where (a1.mt_level = 2 and a1.mt_wdate between '"
        + before_3_sday
        + "' and '"
        + before_3_eday
        + "')"
    )
    sql_txt += " and (a2.sgdt_owner_chk = 'Y' and a2.sgdt_discharge = 'N' and a2.sgdt_exit = 'N' and a2.sgdt_show = 'Y')"
    sql_txt += " group by a1.mt_idx"
    sql = text(sql_txt)
    sql_list = db.session.execute(sql)
    return sql_list


def getTokenList():
    return Member_t.query.filter(
        Member_t.mt_level > 1,
        not_(Member_t.mt_token_id == None),
        not_(Member_t.mt_token_id == ""),
        Member_t.mt_status == 1,
    ).all()


def getSignIn3():
    before3h_start = datetime.datetime.now() + datetime.timedelta(hours=-3)
    before3h_end = before3h_start + datetime.timedelta(hours=1)
    now_stime = before3h_start.strftime("%Y-%m-%d %H:$M:%S")
    now_etime = before3h_end.strftime("%Y-%m-%d %H:$M:%S")
    return Member_t.query.filter(
        Member_t.mt_wdate.between(now_stime, now_etime),
        not_(Member_t.mt_token_id == None),
        not_(Member_t.mt_token_id == ""),
    ).all()


def getSignIn24():
    before24h_start = datetime.datetime.now() + datetime.timedelta(hours=-24)
    before24h_end = before24h_start + datetime.timedelta(hours=1)
    now_stime = before24h_start.strftime("%Y-%m-%d %H:$M:%S")
    now_etime = before24h_end.strftime("%Y-%m-%d %H:$M:%S")
    return Member_t.query.filter(
        Member_t.mt_wdate.between(now_stime, now_etime),
        not_(Member_t.mt_token_id == None),
        not_(Member_t.mt_token_id == ""),
    ).all()
