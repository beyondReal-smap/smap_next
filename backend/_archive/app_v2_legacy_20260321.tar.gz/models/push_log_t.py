from smap import db
from sqlalchemy import text
from .enums import plt_read_chk_enum, plt_show_enum

class Push_log_t(db.Model):
    plt_idx = db.Column(db.Integer, primary_key=True)
    plt_type = db.Column(db.Integer, nullable=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    sst_idx = db.Column(db.Integer, nullable=True)
    plt_condition = db.Column(db.String(50), nullable=True)
    plt_memo = db.Column(db.String(50), nullable=True)
    plt_title = db.Column(db.String(50), nullable=True)
    plt_content = db.Column(db.String(200), nullable=True)
    plt_sdate = db.Column(db.DateTime, nullable=True)
    plt_status = db.Column(db.Integer, nullable=True)
    plt_read_chk = db.Column(db.Enum(plt_read_chk_enum), nullable=True)
    plt_show = db.Column(db.Enum(plt_show_enum), nullable=True)
    push_json = db.Column(db.String(255), nullable=True)
    plt_wdate = db.Column(db.DateTime, nullable=True)
    plt_rdate = db.Column(db.DateTime, nullable=True)
    