import datetime
import logging
from smap import db
from sqlalchemy import text, not_
from smap.models import member_t
from .enums import sgdt_owner_chk_enum, sgdt_leader_chk_enum, sgdt_discharge_enum
from .enums import (
    sgdt_group_chk_enum,
    sgdt_exit_enum,
    sgdt_show_enum,
    sgdt_push_chk_enum,
)

# 로거 설정
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class smap_group_detail_t(db.Model):
    sgdt_idx = db.Column(db.Integer, primary_key=True)
    sgt_idx = db.Column(db.Integer, nullable=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    sgdt_owner_chk = db.Column(db.Enum(sgdt_owner_chk_enum), nullable=True)
    sgdt_leader_chk = db.Column(db.Enum(sgdt_leader_chk_enum), nullable=True)
    sgdt_discharge = db.Column(db.Enum(sgdt_discharge_enum), nullable=True)
    sgdt_group_chk = db.Column(db.Enum(sgdt_group_chk_enum), nullable=True)
    sgdt_exit = db.Column(db.Enum(sgdt_exit_enum), nullable=True)
    sgdt_show = db.Column(db.Enum(sgdt_show_enum), nullable=True)
    sgdt_push_chk = db.Column(db.Enum(sgdt_push_chk_enum), nullable=True)
    sgdt_wdate = db.Column(db.DateTime, nullable=True)
    sgdt_udate = db.Column(db.DateTime, nullable=True)
    sgdt_ddate = db.Column(db.DateTime, nullable=True)
    sgdt_xdate = db.Column(db.DateTime, nullable=True)
    sgdt_adate = db.Column(db.DateTime, nullable=True)


def get_one_idx(sgdt_idx):
    return smap_group_detail_t.query.filter_by(sgdt_idx=sgdt_idx).first()


def get_one_member(sgdt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgdt_idx == sgdt_idx,
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).first()


def get_one_order(sgt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgt_idx == sgt_idx,
        smap_group_detail_t.sgdt_owner_chk == "Y",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).first()


def get_one_owner2(sgt_idx):
    try:
        logger.debug(f"get_one_owner2 시작 - sgt_idx: {sgt_idx}")
        owner = (
            db.session.query(smap_group_detail_t, member_t.Member_t)
            .join(
                member_t.Member_t,
                smap_group_detail_t.mt_idx == member_t.Member_t.mt_idx,
            )
            .filter(
                smap_group_detail_t.sgt_idx == sgt_idx,
                smap_group_detail_t.sgdt_owner_chk == "Y",
                smap_group_detail_t.sgdt_discharge == "N",
                smap_group_detail_t.sgdt_exit == "N",
                smap_group_detail_t.sgdt_show == "Y",
            )
            .first()
        )

        if owner:
            logger.debug(f"get_one_owner2 - 오너 찾음: {owner}")
            logger.debug(
                f"get_one_owner2 - owner.smap_group_detail_t: {owner.smap_group_detail_t}"
            )
            # 필요한 정보를 추출하여 반환
            return {
                "sgdt_idx": owner.smap_group_detail_t.sgdt_idx,
                "sgt_idx": owner.smap_group_detail_t.sgt_idx,
                "mt_idx": owner.smap_group_detail_t.mt_idx,
                "sgdt_owner_chk": owner.smap_group_detail_t.sgdt_owner_chk,
                "sgdt_leader_chk": owner.smap_group_detail_t.sgdt_leader_chk,
                "sgdt_discharge": owner.smap_group_detail_t.sgdt_discharge,
                "sgdt_group_chk": owner.smap_group_detail_t.sgdt_group_chk,
                "sgdt_exit": owner.smap_group_detail_t.sgdt_exit,
                "sgdt_show": owner.smap_group_detail_t.sgdt_show,
                "sgdt_push_chk": owner.smap_group_detail_t.sgdt_push_chk,
                "mt_lang": owner.Member_t.mt_lang,
            }
        else:
            logger.debug(f"get_one_owner2 - 오너 없음 - sgt_idx: {sgt_idx}")
            return None

    except Exception as e:
        logger.error(f"get_one_owner2 - 오류 발생: {e}")
        return None


def get_one_leader2(sgt_idx):
    try:
        logger.debug(f"get_one_leader2 시작 - sgt_idx: {sgt_idx}")
        leader = (
            db.session.query(smap_group_detail_t, member_t.Member_t)
            .join(
                member_t.Member_t,
                smap_group_detail_t.mt_idx == member_t.Member_t.mt_idx,
            )
            .filter(
                smap_group_detail_t.sgt_idx == sgt_idx,
                smap_group_detail_t.sgdt_leader_chk == "Y",
                smap_group_detail_t.sgdt_discharge == "N",
                smap_group_detail_t.sgdt_exit == "N",
                smap_group_detail_t.sgdt_show == "Y",
            )
            .first()
        )

        if leader:
            logger.debug(f"get_one_leader2 - 리더 찾음: {leader}")
            # 필요한 정보를 추출하여 반환
            return {
                "sgdt_idx": leader.smap_group_detail_t.sgdt_idx,
                "sgt_idx": leader.smap_group_detail_t.sgt_idx,
                "mt_idx": leader.smap_group_detail_t.mt_idx,
                "sgdt_owner_chk": leader.smap_group_detail_t.sgdt_owner_chk,
                "sgdt_leader_chk": leader.smap_group_detail_t.sgdt_leader_chk,
                "sgdt_discharge": leader.smap_group_detail_t.sgdt_discharge,
                "sgdt_group_chk": leader.smap_group_detail_t.sgdt_group_chk,
                "sgdt_exit": leader.smap_group_detail_t.sgdt_exit,
                "sgdt_show": leader.smap_group_detail_t.sgdt_show,
                "sgdt_push_chk": leader.smap_group_detail_t.sgdt_push_chk,
                "mt_lang": leader.Member_t.mt_lang,
            }
        else:
            logger.debug(f"get_one_leader2 - 리더 없음 - sgt_idx: {sgt_idx}")
            return None

    except Exception as e:
        logger.error(f"get_one_leader2 - 오류 발생: {e}")
        return None


def get_one_leader(sgt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgt_idx == sgt_idx,
        smap_group_detail_t.sgdt_leader_chk == "Y",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).first()


def get_mt_idx(mt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.mt_idx == mt_idx,
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).all()


def get_member_list():
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgdt_owner_chk == "N",
        smap_group_detail_t.sgdt_leader_chk == "N",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).all()

def get_member_list2(sgt_idx):
    try:
        logger.debug(f"get_member_list2 시작 - sgt_idx: {sgt_idx}")
        member_list = (
            db.session.query(smap_group_detail_t, member_t.Member_t)
            .join(
                member_t.Member_t,
                smap_group_detail_t.mt_idx == member_t.Member_t.mt_idx,
            )
            .filter(
                smap_group_detail_t.sgt_idx == sgt_idx,
                smap_group_detail_t.sgdt_owner_chk == "N",
                smap_group_detail_t.sgdt_leader_chk == "N",
                smap_group_detail_t.sgdt_discharge == "N",
                smap_group_detail_t.sgdt_exit == "N",
                smap_group_detail_t.sgdt_show == "Y",
            )
            .first()
        )

        if member_list:
            logger.debug(f"get_member_list2 - 멤버 찾음: {member_list}")
            logger.debug(
                f"get_member_list2 - member_list.smap_group_detail_t: {member_list.smap_group_detail_t}"
            )
            # 필요한 정보를 추출하여 반환
            return {
                "sgdt_idx": member_list.smap_group_detail_t.sgdt_idx,
                "sgt_idx": member_list.smap_group_detail_t.sgt_idx,
                "mt_idx": member_list.smap_group_detail_t.mt_idx,
                "sgdt_owner_chk": member_list.smap_group_detail_t.sgdt_owner_chk,
                "sgdt_leader_chk": member_list.smap_group_detail_t.sgdt_leader_chk,
                "sgdt_discharge": member_list.smap_group_detail_t.sgdt_discharge,
                "sgdt_group_chk": member_list.smap_group_detail_t.sgdt_group_chk,
                "sgdt_exit": member_list.smap_group_detail_t.sgdt_exit,
                "sgdt_show": member_list.smap_group_detail_t.sgdt_show,
                "sgdt_push_chk": member_list.smap_group_detail_t.sgdt_push_chk,
                "mt_lang": member_list.Member_t.mt_lang,
            }
        else:
            logger.debug(f"get_member_list2 - 멤버 없음 - sgt_idx: {sgt_idx}")
            return None

    except Exception as e:
        logger.error(f"get_member_list2 - 오류 발생: {e}")
        return None


def get_gd_leader_count(mt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.mt_idx == mt_idx,
        smap_group_detail_t.sgdt_owner_chk == "N",
        smap_group_detail_t.sgdt_leader_chk == "Y",
        smap_group_detail_t.sgdt_show == "Y",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
    ).count()


def get_gd_count(mt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.mt_idx == mt_idx,
        smap_group_detail_t.sgdt_owner_chk == "N",
        smap_group_detail_t.sgdt_leader_chk == "N",
        smap_group_detail_t.sgdt_show == "Y",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
    ).count()


def joinGroup1():
    before1h = datetime.datetime.now() + datetime.timedelta(hours=-1)
    now_stime = before1h.strftime("%Y-%m-%d %H:00:00")
    now_etime = datetime.datetime.now().strftime("%Y-%m-%d %H:59:59")
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgdt_group_chk == "D",
        smap_group_detail_t.sgdt_wdate.between(now_stime, now_etime),
        smap_group_detail_t.sgdt_owner_chk == "N",
        smap_group_detail_t.sgdt_leader_chk == "N",
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    )


def get_group(sgt_idx):
    return smap_group_detail_t.query.filter(
        smap_group_detail_t.sgt_idx == sgt_idx,
        smap_group_detail_t.sgdt_discharge == "N",
        smap_group_detail_t.sgdt_exit == "N",
        smap_group_detail_t.sgdt_show == "Y",
    ).all()


# def get_owner_leader_list():
#     return smap_group_detail_t.query.filter(
#         smap_group_detail_t.sgdt_show == 'Y',
#         smap_group_detail_t.mt_idx == '272',
#         (smap_group_detail_t.sgdt_owner_chk == 'Y') | (smap_group_detail_t.sgdt_leader_chk == 'Y')
#     ).all()


def get_owner_leader_list():
    sql_txt = """
    SELECT mt.* 
    FROM smap_group_detail_t sgdt 
        ,member_t mt 
    WHERE 1=1 
    AND (   sgdt.sgdt_show = 'Y'
    AND    (sgdt.sgdt_owner_chk = 'Y' or sgdt.sgdt_leader_chk = 'Y') 
    AND    sgdt.mt_idx = mt.mt_idx
        )
    UNION 
    SELECT *
    FROM member_t mt2 
    where mt_idx = 1186
    """

    # sql_txt = """
    # SELECT *
    # FROM member_t mt2
    # where mt_idx = 272
    # """
    sql = text(sql_txt)
    sql_list = db.session.execute(sql)
    return sql_list


def get_my_location_list():
    sql_txt = """
    SELECT mt.*
        FROM member_t mt
        INNER JOIN (
            SELECT sgdt.mt_idx
            FROM smap_group_detail_t sgdt
            LEFT OUTER JOIN smap_location_t slt ON sgdt.mt_idx = slt.insert_mt_idx
            WHERE sgdt.sgdt_show = 'Y'
            AND (sgdt.sgdt_owner_chk = 'Y' OR sgdt.sgdt_leader_chk = 'Y')
            AND slt.mt_idx IS NULL
            UNION
            SELECT 1186 AS mt_idx
        ) nl ON mt.mt_idx = nl.mt_idx
    """
    # sql_txt = """
    # SELECT mt.*
    #     FROM member_t mt
    #     INNER JOIN (
    #         SELECT 272 AS mt_idx
    #     ) nl ON mt.mt_idx = nl.mt_idx
    # """

    sql = text(sql_txt)
    result = db.session.execute(sql)
    return result
