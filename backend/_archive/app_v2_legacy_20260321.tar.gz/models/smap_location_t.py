import logging
from smap import db
from sqlalchemy import text
from datetime import datetime
from .enums import slt_show_enum, slt_enter_alarm_enum, slt_enter_chk_enum

# 로거 설정
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)


class smap_location_t(db.Model):
    slt_idx = db.Column(db.Integer, primary_key=True)
    insert_mt_idx = db.Column(db.Integer, nullable=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    sgdt_idx = db.Column(db.Integer, nullable=True)
    slt_title = db.Column(db.String(50), nullable=True)
    slt_add = db.Column(db.String(100), nullable=True)
    slt_lat = db.Column(db.Numeric(16, 14), nullable=True)
    slt_long = db.Column(db.Numeric(17, 14), nullable=True)
    slt_show = db.Column(db.Enum(slt_show_enum), nullable=True)
    slt_enter_alarm = db.Column(db.Enum(slt_enter_alarm_enum), nullable=True)
    slt_enter_chk = db.Column(db.Enum(slt_enter_chk_enum), nullable=True)
    slt_wdate = db.Column(db.DateTime, nullable=True)
    slt_udate = db.Column(db.DateTime, nullable=True)
    slt_ddate = db.Column(db.DateTime, nullable=True)


def get_one_idx(slt_idx):
    return smap_location_t.query.filter_by(slt_idx=slt_idx).first()


def getInMyplaysList():
    sql = text(
        """
        SELECT slt.slt_idx, slt.insert_mt_idx, slt.mt_idx, slt.sgdt_idx, slt.slt_title, slt.slt_add, 
               slt.slt_lat, slt.slt_long, slt.slt_show, 
               CASE slt.slt_enter_alarm WHEN 'Y' THEN 'Y' ELSE 'N' END AS slt_enter_alarm,
               CASE slt.slt_enter_chk WHEN 'Y' THEN 'Y' ELSE 'N' END AS slt_enter_chk,
               slt.slt_wdate, slt.slt_udate, slt.slt_ddate, mt.mt_lang
        FROM smap_location_t slt
            ,member_t mt
        WHERE slt.slt_show = 'Y'
          AND slt.slt_enter_chk = 'N'
          AND slt.mt_idx = mt.mt_idx
    """
    )
    try:
        sql_list = db.session.execute(sql)
        sql_arr = sql_list.fetchall()
    except Exception as e:
        logger.error(f"Error executing SQL: {e}")
        return None

    # logger.debug(f"SQL Query: {sql}")
    # logger.debug(f"SQL Result: {sql_list}")
    # logger.debug(f"Fetched rows: {len(sql_arr)}")

    # 로그로 sql_arr 출력
    # if not sql_arr:
    #     logger.debug("smap_location_t - getInMyplaysList - sql_arr is empty")
    #     return None

    # for row in sql_arr:
    #     logger.debug(f"Row type: {type(row)}, Row content: {row}")

    return sql_arr


def getOutMyplaysList():
    sql = text(
        """
        SELECT slt_idx, insert_mt_idx, mt_idx, sgdt_idx, slt_title, slt_add, 
               slt_lat, slt_long, slt_show, 
               CASE slt_enter_alarm WHEN 'Y' THEN 'Y' ELSE 'N' END AS slt_enter_alarm,
               CASE slt_enter_chk WHEN 'Y' THEN 'Y' ELSE 'N' END AS slt_enter_chk,
               slt_wdate, slt_udate, slt_ddate
        FROM smap_location_t
        WHERE slt_show = 'Y'
          AND slt_enter_chk = 'Y'
          AND DATE(slt_udate) = CURDATE()
    """
    )
    sql_list = db.session.execute(sql)
    sql_arr = sql_list.fetchall()

    # 로그로 sql_arr 출력
    # if not sql_arr:
    #     logger.debug("smap_location_t - getOutMyplaysList - sql_arr is empty")
    #     return None

    # for row in sql_arr:
    #     logger.debug(row)

    return sql_arr
