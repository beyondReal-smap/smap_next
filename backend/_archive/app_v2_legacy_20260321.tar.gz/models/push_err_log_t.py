import datetime
from smap import db

class push_err_log_t(db.Model):
    pelt_idx = db.Column(db.Integer, primary_key=True)
    mt_id = db.Column(db.String(200), nullable=True)
    plt_idx = db.Column(db.Integer, nullable=True)
    pelt_err_title = db.Column(db.String(100), nullable=True)
    pelt_err_msg = db.Column(db.Text, nullable=True)
    pelt_wdate = db.Column(db.DateTime, nullable=True)