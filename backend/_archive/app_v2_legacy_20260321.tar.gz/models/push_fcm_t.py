import datetime
from smap import db
from sqlalchemy import text
from .enums import pft_show_enum

class Push_fcm_t(db.Model):
    pft_idx = db.Column(db.Integer, primary_key=True)
    pft_code = db.Column(db.String(20), nullable=True)
    pft_title = db.Column(db.String(100), nullable=True)
    pft_content = db.Column(db.String(200), nullable=True)
    pft_send_type = db.Column(db.Integer, nullable=True)
    pft_send_mt_idx = db.Column(db.Integer, nullable=True)
    pft_rdate = db.Column(db.DateTime, nullable=True)
    pft_url = db.Column(db.String(255), nullable=True)
    pft_status = db.Column(db.Integer, nullable=True)
    pft_show = db.Column(db.Enum(pft_show_enum), nullable=True)
    pft_sdate = db.Column(db.DateTime, nullable=True)
    pft_edate = db.Column(db.DateTime, nullable=True)
    pft_wdate = db.Column(db.DateTime, nullable=True)

def find_idx_one(pft_idx):
    return Push_fcm_t.query.filter_by(pft_idx=pft_idx).first()

def find_push_list():
    now = datetime.datetime.now()
    pft_rdate = now.strftime('%Y-%m-%d %H:00:00')
    return Push_fcm_t.query.filter(Push_fcm_t.pft_rdate == pft_rdate, Push_fcm_t.pft_show == 'Y', Push_fcm_t.pft_status == 1)