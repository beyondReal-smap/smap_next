from smap import db
from .enums import sgt_show_enum

class smap_group_t(db.Model):
    sgt_idx = db.Column(db.Integer, primary_key=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    sgt_title = db.Column(db.String(50), nullable=True)
    sgt_code = db.Column(db.String(10), nullable=True)
    sgt_show = db.Column(db.Enum(sgt_show_enum), nullable=True)
    sgt_wdate = db.Column(db.DateTime, nullable=True)
    sgt_udate = db.Column(db.DateTime, nullable=True)
    
def get_group_count(mt_idx):
    return smap_group_t.query.filter(smap_group_t.mt_idx == mt_idx, smap_group_t.sgt_show == 'Y').count()