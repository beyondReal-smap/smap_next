import sys
import datetime
from smap import db
from sqlalchemy import text, between
from .enums import mlt_fine_location_enum
from .enums import mlt_location_chk_enum
import logging
import os
from datetime import datetime, timedelta

# 로그 폴더 경로 설정
log_directory = "/data/wwwroot/api2.smap.site/smap2/smap/logs"
log_file_path = os.path.join(log_directory, "app.log")

# 로그 폴더가 존재하지 않으면 생성
if not os.path.exists(log_directory):
    os.makedirs(log_directory)

# 로거 설정 (전역 범위)
logger = logging.getLogger(__name__)
logger.setLevel(logging.ERROR)

# 콘솔 핸들러 설정
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setLevel(logging.DEBUG)
console_formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
console_handler.setFormatter(console_formatter)
logger.addHandler(console_handler)

# 파일 핸들러 설정
file_handler = logging.FileHandler(log_file_path)  # 로그를 저장할 파일 경로 설정
file_handler.setLevel(logging.ERROR)
file_formatter = logging.Formatter(
    "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
file_handler.setFormatter(file_formatter)
logger.addHandler(file_handler)


class Member_location_log_t(db.Model):
    mlt_idx = db.Column(db.Integer, primary_key=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    mlt_lat = db.Column(db.Numeric(16, 14), nullable=True)
    mlt_long = db.Column(db.Numeric(17, 14), nullable=True)
    mlt_speed = db.Column(db.Float, nullable=True)
    mlt_battery = db.Column(db.Integer, nullable=True)
    mlt_fine_location = db.Column(db.Enum(mlt_fine_location_enum), nullable=True)
    mlt_location_chk = db.Column(db.Enum(mlt_location_chk_enum), nullable=True)
    mt_health_work = db.Column(db.Integer, nullable=True)
    mlt_wdate = db.Column(db.DateTime, nullable=True)
    mlt_accuacy = db.Column(db.Float, nullable=True)
    mlt_gps_time = db.Column(db.DateTime, nullable=True)


def find_one_idx(mlt_idx):
    return Member_location_log_t.query.filter_by(mlt_idx=mlt_idx).first()


def find_one_mt_idx(mt_idx):
    now = datetime.now()
    return (
        Member_location_log_t.query.filter(Member_location_log_t.mt_idx == mt_idx)
        .order_by(Member_location_log_t.mlt_idx.desc())
        .first()
    )


def find_one_mt_idx_now(mt_idx):
    now = datetime.now()
    start = now.strftime("%Y-%m-%d 00:00:00")
    end = now.strftime("%Y-%m-%d 23:59:59")
    return (
        Member_location_log_t.query.filter(
            Member_location_log_t.mt_idx == mt_idx,
            between(Member_location_log_t.mlt_gps_time, start, end),
        )
        .order_by(Member_location_log_t.mlt_idx.desc())
        .first()
    )


def getDistance(slt_lat, slt_long, mt_idx):
    # 파라미터 타입 변환
    try:
        slt_lat = float(slt_lat)
        slt_long = float(slt_long)
        mt_idx = int(mt_idx)
    except ValueError as e:
        logger.error(f"Invalid parameter type: {e}")
        return None

    logger.info(f"member_location_log_t - mt_idx: {mt_idx}")
    # 안전한 파라미터 바인딩
    sql = text(
        """
        SELECT 
            (6371 * ACOS(
                COS(RADIANS(mlt_lat)) 
                * COS(RADIANS(:slt_lat)) 
                * COS(RADIANS(:slt_long) - RADIANS(mlt_long)) 
                + SIN(RADIANS(mlt_lat)) 
                * SIN(RADIANS(:slt_lat))
            )) AS distance,
            mlt_speed,
            mt_health_work,
            mlt_gps_time
        FROM member_location_log_t
        WHERE mt_idx = :mt_idx
        ORDER BY mlt_gps_time DESC 
        LIMIT 1
    """
    )

    params = {"slt_lat": slt_lat, "slt_long": slt_long, "mt_idx": mt_idx}

    try:
        sql_list = db.session.execute(sql, params)
        sql_arr = sql_list.fetchall()
        logger.info(f"member_location_log_t - sql_arr: {sql_arr}")
        # 로그로 sql_arr 출력
        if not sql_arr:
            logger.debug(f"No data found for mt_idx: {mt_idx}")
            return None

        for row in sql_arr:
            logger.debug(f"mt_idx : {mt_idx} / row : {row}")

        return sql_arr[0]

    except Exception as e:
        logger.error(f"Error executing query: {e}")
        return None


def getDistanceTest(slt_lat, slt_long, mlt_lat, mlt_long):
    sql = text(
        "SELECT (6371*ACOS(COS(RADIANS("
        + mlt_lat
        + ")) * COS(RADIANS("
        + slt_lat
        + ")) * COS(RADIANS("
        + slt_long
        + ") - RADIANS("
        + mlt_long
        + ")) + SIN(RADIANS("
        + mlt_lat
        + ")) * SIN(RADIANS("
        + slt_lat
        + ")))) AS distance"
    )
    sql_list = db.session.execute(sql)
    sql_arr = sql_list.fetchall()

    if sql_arr == []:
        return None
    elif sql_arr[0] == "":
        return None
    else:
        return sql_arr[0]


def find_last2_mt_idx(mt_idx):
    return (
        Member_location_log_t.query.filter(Member_location_log_t.mt_idx == mt_idx)
        .order_by(Member_location_log_t.mlt_gps_time.desc())
        .offset(1)
        .first()
    )


def find_members_with_outdated_location():
    sql = text(
        """
        SELECT mt.*
        FROM member_t mt
        WHERE mt_adate BETWEEN DATE_ADD(CURDATE(), INTERVAL -14 DAY) AND DATE_ADD(CURDATE(), INTERVAL -3 DAY)
        AND mt_retire_chk is null
        UNION ALL
        SELECT mt.*
        FROM member_t mt
        WHERE mt_idx = 1186
    """
    )

    try:
        result = db.session.execute(sql)
        outdated_members = result.fetchall()

        logger.info(f"Found {len(outdated_members)} members with outdated location")

        for member in outdated_members:
            logger.debug(
                f"Outdated member - mt_idx: {member.mt_idx}, mt_name: {member.mt_name}"
            )

        return outdated_members

    except Exception as e:
        logger.error(
            f"Error executing query to find members with outdated location: {e}"
        )
        return None
