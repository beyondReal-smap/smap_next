import sys
import datetime
from datetime import timedelta  # 추가된 부분
from smap import db
from sqlalchemy import text
from .enums import sst_all_day_chk_enum, sst_show_enum
from .enums import sst_schedule_alarm_chk_enum, sst_in_chk_enum, sst_schedule_chk_enum

class smap_schedule_t(db.Model):
    sst_idx = db.Column(db.Integer, primary_key=True)
    sst_pidx = db.Column(db.Integer, nullable=True)
    mt_idx = db.Column(db.Integer, nullable=True)
    sst_title = db.Column(db.String(100), nullable=True)
    sst_sdate = db.Column(db.DateTime, nullable=True)
    sst_edate = db.Column(db.DateTime, nullable=True)
    sst_sedate = db.Column(db.String(100), nullable=True)
    sst_all_day = db.Column(db.Enum(sst_all_day_chk_enum), nullable=True)
    sst_repeat_json = db.Column(db.String(200), nullable=True)
    sst_repeat_json_v = db.Column(db.String(200), nullable=True)
    sgt_idx = db.Column(db.Integer, nullable=True)
    sgdt_idx = db.Column(db.Integer, nullable=True)
    sgdt_idx_t = db.Column(db.String(100), nullable=True)
    sst_alram = db.Column(db.Integer, nullable=True)
    sst_alram_t = db.Column(db.String(100), nullable=True)
    sst_adate = db.Column(db.DateTime, nullable=True)
    slt_idx = db.Column(db.Integer, nullable=True)
    slt_idx_t = db.Column(db.String(100), nullable=True)
    sst_location_title = db.Column(db.String(50), nullable=True)
    sst_location_add = db.Column(db.String(100), nullable=True)
    sst_location_lat = db.Column(db.Numeric(16,14), nullable=True)
    sst_location_long = db.Column(db.Numeric(17,14), nullable=True)
    sst_supplies = db.Column(db.String(200), nullable=True)
    sst_memo = db.Column(db.Text, nullable=True)
    sst_show = db.Column(db.Enum(sst_show_enum), nullable=True)
    sst_location_alarm = db.Column(db.Integer, nullable=True)
    sst_schedule_alarm_chk = db.Column(db.Enum(sst_schedule_alarm_chk_enum), nullable=True)
    sst_pick_type = db.Column(db.String(20), nullable=True)
    sst_pick_result = db.Column(db.Integer, nullable=True)
    sst_schedule_alarm = db.Column(db.DateTime, nullable=True)
    sst_update_chk = db.Column(db.String(10), nullable=True)
    sst_wdate = db.Column(db.DateTime, nullable=True)
    sst_udate = db.Column(db.DateTime, nullable=True)
    sst_ddate = db.Column(db.DateTime, nullable=True)
    sst_in_chk = db.Column(db.Enum(sst_in_chk_enum), nullable=True)
    sst_schedule_chk = db.Column(db.Enum(sst_schedule_chk_enum), nullable=True)
    sst_entry_cnt = db.Column(db.Integer, nullable=True)
    sst_exit_cnt = db.Column(db.Integer, nullable=True)

def get_one_idx(sst_idx):
    return smap_schedule_t.query.filter_by(sst_idx=sst_idx).first()

def get_now_schedule_in_members():
    sql = text("""
        SELECT sst.*, mt.mt_lang as mt_lang
          FROM smap_schedule_t sst
          LEFT JOIN member_t mt ON sst.mt_idx = mt.mt_idx
        WHERE NOW() BETWEEN 
            LEAST(
                DATE_SUB(sst.sst_sdate, INTERVAL 30 MINUTE),
                IFNULL(sst.sst_adate, sst.sst_sdate)
            ) AND sst.sst_edate 
        AND (sst.sst_location_alarm = 1 OR sst.sst_location_alarm = 4) 
        AND sst.sst_in_chk = 'N' 
        AND sst.sst_entry_cnt = 0 
        AND sst.sst_show = 'Y'
    """)
    return db.session.execute(sql)

def get_now_schedule_out_members():
    sql = text("""
        SELECT sst.*, mt.mt_lang as mt_lang
          FROM smap_schedule_t sst
          LEFT JOIN member_t mt ON sst.mt_idx = mt.mt_idx
        WHERE NOW() BETWEEN sst.sst_sdate AND sst.sst_edate 
        AND (sst.sst_location_alarm = 2 OR sst.sst_location_alarm = 4) 
        AND sst.sst_in_chk = 'Y' 
        AND sst.sst_exit_cnt = 0 
        AND sst.sst_show = 'Y'
    """)
    return db.session.execute(sql)

def get_now_schedule_push():
    now = datetime.datetime.now()
    today1 = now.replace(second=0, microsecond=0)
    today2 = today1 + timedelta(minutes=1) - timedelta(seconds=1)

    sql = text("""
        SELECT * FROM smap_schedule_t 
        WHERE sst_schedule_alarm BETWEEN :start_time AND :end_time
          AND sst_schedule_alarm_chk = 'Y'
          AND sst_schedule_chk = 'N'
          AND sst_show = 'Y'
    """)

    params = {
        'start_time': today1,
        'end_time': today2
    }

    sql_list = db.session.execute(sql, params)
    return sql_list

def start_befor30():
    before30 = datetime.datetime.now()+datetime.timedelta(minutes=30)
    before30 = before30.strftime('%Y-%m-%d %H:%M:00')
    return smap_schedule_t.query.filter(smap_schedule_t.sst_sdate == before30, smap_schedule_t.sst_show == 'Y').all()