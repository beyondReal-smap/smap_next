import enum
from sqlalchemy import Enum

class mlt_fine_location_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class mlt_location_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sst_all_day_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sst_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sst_schedule_alarm_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sgdt_owner_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sgdt_leader_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sgdt_discharge_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sgdt_group_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    D = 'D'
    
class sgdt_exit_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sgdt_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sgdt_push_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sst_in_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class sst_schedule_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'    
    
class plt_read_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class plt_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class slt_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class slt_enter_alarm_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class slt_enter_chk_enum(enum.Enum):
    Y = 'Y'
    N = 'N'
    
class sgt_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'

class pft_show_enum(enum.Enum):
    Y = 'Y'
    N = 'N'