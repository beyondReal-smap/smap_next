from flask import Flask, g, render_template, request, session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
import datetime
from apscheduler.schedulers.background import BackgroundScheduler
import time
import json
import sys
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime as dt, timedelta
import os
import random

db = SQLAlchemy()
migrate = Migrate()

# 현재 스크립트 파일의 디렉토리 경로를 가져옵니다.
current_dir = os.path.dirname(os.path.abspath(__file__))

# 로그 디렉토리 설정 (현재 디렉토리에 'logs' 폴더 생성)
log_dir = os.path.join(current_dir, "logs")
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# 로거 설정
logger = logging.getLogger("smap")
logger.setLevel(logging.DEBUG)

# 로그 파일 핸들러 설정
log_file = os.path.join(log_dir, "smap.log")
file_handler = RotatingFileHandler(log_file, maxBytes=10000000, backupCount=5)
file_handler.setLevel(logging.DEBUG)

# 로그 포맷 설정
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)

# 로거에 핸들러 추가
logger.addHandler(file_handler)


def create_app(config=None):
    # print("run SMAP : create_app()")
    logger.info("Application started")
    app = Flask(__name__)

    """Flask Configs"""
    from .configs import DevelopmentConfig, ProductionConfig

    if not config:
        if app.config["DEBUG"]:
            config = DevelopmentConfig()
        else:
            config = ProductionConfig()
    print("run with:", config)
    app.config.from_object(config)

    """SOCKETIO INIT"""
    # io.init_app(app, cors_allowed_origins="*")

    """CSRF INIT"""
    # csrf.init_app(app)

    """DB INIT"""
    db.init_app(app)
    if (app.config["SQLALCHEMY_DATABASE_URI"]).startswith("sqllite"):
        migrate.init_app(app, db, render_as_batch=True)
    else:
        migrate.init_app(app, db)

    """Routes INIT"""
    from smap.routes import base_route

    app.register_blueprint(base_route.bp)

    """Restx INIT"""
    from smap.apis import blueprint as api

    app.register_blueprint(api)

    """APScheduler INIT"""

    # 스케쥴 count 변경 함수
    def schedule_count_update(update_type, sst_idx, count):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                if count is None:
                    update_count = 1
                else:
                    update_count = int(count) + 1
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                if update_type == 1:
                    # 진입카운트 증가
                    schedule.sst_entry_cnt = update_count
                    db.session.commit()
                elif update_type == 2:
                    # 이탈카운트 증가
                    schedule.sst_exit_cnt = update_count
                    db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    # 스케쥴 위치값 변경 함수
    def schedule_status_update(sst_idx, sst_in_chk):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                schedule.sst_in_chk = sst_in_chk
                db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    def schedule_status_push_update(sst_idx, sst_schedule_chk):
        from smap.models import smap_schedule_t

        with app.app_context():
            try:
                schedule = smap_schedule_t.get_one_idx(sst_idx)
                schedule.sst_schedule_chk = sst_schedule_chk
                db.session.commit()
                return True
            except Exception as e:
                logger.error(e)
                return False

    def location_status_update(slt_idx, slt_enter_chk):
        from smap.models import smap_location_t

        with app.app_context():
            try:
                location = smap_location_t.get_one_idx(slt_idx)
                if location:
                    location.slt_enter_chk = slt_enter_chk
                    location.slt_udate = dt.now()  # Use the alias dt
                    db.session.commit()
                    return True
                else:
                    print(f"Location with slt_idx {slt_idx} not found.")
                    return False
            except Exception as e:
                logger.error(e)
                return False

    # ------------------ 스케줄러 함수 ------------------
    # push err log 저장
    def push_err_log_add(plt_idx, pelt_err_title, pelt_err_msg, mt_id=None):
        from smap.models import push_err_log_t

        with app.app_context():
            try:
                now = datetime.datetime.now()
                push_err_data = push_err_log_t.push_err_log_t(
                    mt_id=mt_id,
                    plt_idx=plt_idx,
                    pelt_err_title=pelt_err_title,
                    pelt_err_msg=pelt_err_msg,
                    pelt_wdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                )
                db.session.add(push_err_data)
                db.session.commit()
            except Exception as e:
                print("오류 저장 중 에러" + e)
        return 0

    # push log 저장 함수
    def push_log_add(
        mt_idx,
        sst_idx,
        plt_condition,
        plt_memo,
        plt_title,
        plt_content,
        push_result,
        push_json="",
    ):
        from smap.models import push_log_t
        from smap.models import member_t

        with app.app_context():
            try:
                now = datetime.datetime.now()
                plt_status = 1
                if push_result["result"] == True:
                    plt_status = 2
                elif push_result["result"] == False:
                    plt_status = 4

                push_json_txt = ""
                if push_json != "":
                    push_json_txt = json.dumps(push_json)

                push_log_data = push_log_t.Push_log_t(
                    plt_type=2,
                    mt_idx=mt_idx,
                    sst_idx=sst_idx,
                    plt_condition=plt_condition,
                    plt_memo=plt_memo,
                    plt_title=plt_title,
                    plt_content=plt_content,
                    plt_sdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                    plt_status=plt_status,
                    plt_read_chk="N",
                    plt_show="Y",
                    plt_wdate=now.strftime("%Y-%m-%d %H:%M:%S"),
                    push_json=push_json_txt,
                )
                db.session.add(push_log_data)
                db.session.commit()

                if push_result["result"] == False:
                    if mt_idx is None or mt_idx == "":
                        push_err_log_add(
                            push_log_data.plt_idx,
                            "push_log_add 오류",
                            push_result["msg"],
                            "멤버 없음",
                        )
                    else:
                        member_info = member_t.find_one_idx(mt_idx)
                        if not member_info is None:
                            push_err_log_add(
                                push_log_data.plt_idx,
                                "push_log_add 오류",
                                push_result["msg"],
                                member_info.mt_idx,
                            )
                        else:
                            push_err_log_add(
                                push_log_data.plt_idx,
                                "push_log_add 오류",
                                push_result["msg"],
                                "멤버 찾을 수 없음",
                            )
            except Exception as e:
                if mt_idx is None or mt_idx == "":
                    push_err_log_add(None, "push_log_add 오류", e)
                else:
                    member_info = member_t.find_one_idx(mt_idx)
                    if not member_info is None:
                        push_err_log_add(
                            None, "push_log_add 오류", e, member_info.mt_idx
                        )
                    else:
                        push_err_log_add(
                            None, "push_log_add 오류", e, "멤버 찾을 수 없음"
                        )
                logger.error(e)

    # 예약 push 상태와 일시 변경
    def loop_push_update(pft_idx, u_type):
        from smap.models import push_fcm_t

        with app.app_context():
            now = datetime.datetime.now()
            fcm_info = push_fcm_t.find_idx_one(pft_idx)

            if not fcm_info is None:
                if u_type == 1:
                    # 발송 시작
                    fcm_info.pft_status = 2
                    fcm_info.pft_sdate = now
                else:
                    # 발송 종료
                    fcm_info.pft_status = 3
                    fcm_info.pft_edate = now
                db.session.commit()
                return True
            else:
                return False

    def set_push_message(recipient, member_name, title, arrival_messages):
        selected_message = random.choice(arrival_messages)

        if recipient == "member":
            name_prefix = ""
            good_news = ""
            current_location = "현재 위치: "
            welcome = "즐거운 시간 되세요! 👋"
        else:
            name_prefix = f"{member_name}님이 "
            good_news = f"좋은 소식! {member_name}님이 "
            current_location = f"{member_name}님의 현재 위치: "
            welcome = "환영해주세요! 👋"

        push_title = selected_message["push_title"]
        push_content = selected_message["push_content"].format(
            name_prefix=name_prefix,
            title=title,
            good_news=good_news,
            current_location=current_location,
            welcome=welcome,
        )

        return push_title, push_content

    # 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때
    def ps_1():
        logger.info(f"ps_1 일정장소 시작")
        from smap.models import member_t
        from smap.models import push_log_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member

        messages = [
            {
                "push_title": "일정장소 도착알림 📍",
                "push_content": "{name_prefix}'{title}' 장소에 도착했어요! 🎉",
            }
            # {
            #     "push_title": "목적지 도착 소식 🏁",
            #     "push_content": "{name_prefix}'{title}'에 무사히 도착했습니다. 👍"
            # },
            # {
            #     "push_title": "일정 체크인 알림 🌟",
            #     "push_content": "{name_prefix}'{title}' 일정 장소에 체크인했어요!"
            # },
            # {
            #     "push_title": "위치 업데이트 📢",
            #     "push_content": "{name_prefix}'{title}' 위치에 도착했습니다. 🚶‍♂️"
            # },
            # {
            #     "push_title": "일정 장소 도착 확인 🎯",
            #     "push_content": "{name_prefix}'{title}'에 도착하셨어요. ✅"
            # },
            # {
            #     "push_title": "목표 지점 도달 🚩",
            #     "push_content": "{name_prefix}'{title}' 목표 지점에 도달했습니다! 🙌"
            # },
            # {
            #     "push_title": "위치 확인 완료 📌",
            #     "push_content": "{current_location}'{title}' 도착 확인됐어요! 👀"
            # }
        ]

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "일정에 입력한 장소의 100미터 반경에 들어왔을때"

            # 일정이 있는 100M 진입 전인 스케쥴 리스트
            push_list = smap_schedule_t.get_now_schedule_in_members()
            for pt in push_list:
                mt_idx = None
                sst_idx = pt.sst_idx

                if pt.sgt_idx is not None and pt.sgdt_idx != 0:
                    sgt_idx = str(pt.sgt_idx)

                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if group_member is not None:
                        mt_idx = str(group_member.mt_idx)

                if mt_idx is not None:
                    # 본인이 작성한 push 문시
                    if int(pt.mt_idx) != int(mt_idx):
                        try:
                            # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                            member_location = member_location_log_t.getDistance(
                                str(pt.sst_location_lat),
                                str(pt.sst_location_long),
                                mt_idx,
                            )
                            if member_location is not None:
                                distance = kmTom(member_location.distance)
                                formatted_distance = "{:,.1f}".format(distance)
                                push_json = {
                                    "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                    "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                    "distance": formatted_distance,
                                }
                                if 100.0 >= distance:
                                    logger.info(f"ps_1 일정장소 도착 - {pt.mt_idx}")
                                    if int(pt.sst_entry_cnt) == 0:
                                        group_data = get_group_member(sgt_idx, mt_idx)

                                        for recipient in ["order", "leader", "member"]:
                                            if group_data[recipient] != {}:
                                                if recipient in ["order", "leader"]:
                                                    if (
                                                        group_data[recipient]["mt_idx"]
                                                        != group_data["member"][
                                                            "mt_idx"
                                                        ]
                                                    ):
                                                        push_title, push_content = (
                                                            set_push_message(
                                                                recipient,
                                                                group_data["member"][
                                                                    "mt_name"
                                                                ],
                                                                pt.sst_title,
                                                                messages,
                                                            )
                                                        )
                                                        group_data[recipient][
                                                            "push_title"
                                                        ] = push_title
                                                        group_data[recipient][
                                                            "push_content"
                                                        ] = push_content
                                                        group_data[recipient][
                                                            "push_txt"
                                                        ] = push_content
                                                        group_data[recipient][
                                                            "send"
                                                        ] = "Y"
                                                    else:
                                                        group_data[recipient][
                                                            "send"
                                                        ] = "N"
                                                else:  # member
                                                    push_title, push_content = (
                                                        set_push_message(
                                                            recipient,
                                                            group_data["member"][
                                                                "mt_name"
                                                            ],
                                                            pt.sst_title,
                                                            messages,
                                                        )
                                                    )
                                                    group_data[recipient][
                                                        "push_title"
                                                    ] = push_title
                                                    group_data[recipient][
                                                        "push_content"
                                                    ] = push_content
                                                    group_data[recipient][
                                                        "push_txt"
                                                    ] = push_content
                                                    group_data[recipient]["send"] = "Y"
                                            else:
                                                group_data[recipient]["send"] = "N"

                                        # order가 member와 같을 때 leader에게 메시지를 보내지 않도록 처리
                                        if (
                                            group_data["order"] != {}
                                            and group_data["order"]["mt_idx"]
                                            == group_data["member"]["mt_idx"]
                                        ):
                                            group_data["leader"]["send"] = "N"

                                        for key, group in group_data.items():
                                            if group != "":
                                                if group["send"] == "Y":
                                                    push_result = send_push(
                                                        group["mt_token_id"],
                                                        group["push_title"],
                                                        group["push_content"],
                                                    )
                                                    push_log_add(
                                                        group["mt_idx"],
                                                        pt.sst_idx,
                                                        plt_condition,
                                                        plt_memo,
                                                        group["push_title"],
                                                        group["push_txt"],
                                                        push_result,
                                                        push_json,
                                                    )

                                        # 진입 여부 상태 수정
                                        schedule_result = schedule_status_update(
                                            sst_idx, "Y"
                                        )
                                        # 진입 발송 증가
                                        schedule_count_update(
                                            1, pt.sst_idx, pt.sst_entry_cnt
                                        )
                                    # if int(pt.sst_entry_cnt) == 0:
                                    #     #그룹 정보 가져오기
                                    #     group_data = get_group_member(sgt_idx, mt_idx)

                                    #     if group_data['order'] != {}:
                                    #         if group_data['order']['mt_idx'] != group_data['member']['mt_idx']:
                                    #             #오더 전송
                                    #             group_data['order']['push_title'] = '일정장소 도착알림 🏁'
                                    #             group_data['order']['push_content'] = group_data['member']['mt_name'] + '님이 \'' + str(pt.sst_title) + '\' 일정장소에 도착했어요.'
                                    #             group_data['order']['push_txt'] = group_data['order']['push_content']
                                    #             group_data['order']['send'] = 'Y'
                                    #         else:
                                    #             group_data['order']['send'] = 'N'
                                    #     else:
                                    #         group_data['order']['send'] = 'N'

                                    #     if group_data['leader'] != {}:
                                    #         if group_data['order']['mt_idx'] == group_data['member']['mt_idx']:
                                    #             group_data['leader']['send'] = 'N'
                                    #         else:
                                    #             if group_data['leader']['mt_idx'] != group_data['member']['mt_idx']:
                                    #                 #리더 전송
                                    #                 group_data['leader']['push_title'] = '일정장소 도착알림 🏁'
                                    #                 group_data['leader']['push_content'] = group_data['member']['mt_name'] + '님이 \'' + str(pt.sst_title) + '\' 일정장소에 도착했어요.'
                                    #                 group_data['leader']['push_txt'] = group_data['leader']['push_content']
                                    #                 group_data['leader']['send'] = 'Y'
                                    #             else:
                                    #                 group_data['leader']['send'] = 'N'
                                    #     else:
                                    #         group_data['leader']['send'] = 'N'

                                    #     if group_data['member'] != {}:
                                    #         #그룹원 전송
                                    #         group_data['member']['push_title'] = '일정장소 도착알림 🏁'
                                    #         group_data['member']['push_content'] = '\'' + str(pt.sst_title) + '\' 일정장소에 도착했어요.'
                                    #         group_data['member']['push_txt'] = group_data['member']['push_content']
                                    #         group_data['member']['send'] = 'N'
                                    #     else:
                                    #         group_data['member']['send'] = 'N'

                                    #     for key, group in group_data.items():
                                    #         if group != '':
                                    #             #테스트
                                    #             # if group['mt_idx'] == 79 or group['mt_idx'] == 98 or group['mt_idx'] == 80:
                                    #             if group['send'] == 'Y':
                                    #                 push_result = send_push(group['mt_token_id'], group['push_title'], group['push_content'])
                                    #                 push_log_add(group['mt_idx'], pt.sst_idx, plt_condition, plt_memo, group['push_title'], group['push_txt'], push_result, push_json)

                                    #                 #진입 여부 상태 수정
                                    #                 schedule_result = schedule_status_update(sst_idx, 'Y')
                                    #                 #진입 발송 증가
                                    #                 schedule_count_update(1, pt.sst_idx, pt.sst_entry_cnt)
                        except Exception as e:
                            if mt_idx is None or mt_idx == "":
                                push_err_log_add(
                                    None,
                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                    e,
                                    "멤버없음",
                                )
                            else:
                                member_info = member_t.find_one_idx(mt_idx)
                                if member_info is None:
                                    push_err_log_add(
                                        None,
                                        "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                        e,
                                        "멤버 찾을 수 없음",
                                    )
                                else:
                                    push_err_log_add(
                                        None,
                                        "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때 오류",
                                        e,
                                        member_info.mt_idx,
                                    )
                            logger.error("[ps_1][" + member_info.mt_idx + "] - " + e)

                    else:
                        # 진입 여부 상태 수정
                        schedule_result = schedule_status_update(sst_idx, "Y")
                        # 진입 발송 증가
                        schedule_count_update(1, pt.sst_idx, pt.sst_entry_cnt)
            print("30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 들어왔을때")

    # 장소알림 - 일정에 입력한 장소의 100미터 반경에서 이탈했을때
    def ps_2():
        logger.info(f"ps_2 일정장소 출발 시작")
        import logging
        from smap.models import member_t
        from smap.models import push_log_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        # Configure logging
        logging.basicConfig(
            filename="error.log",
            level=logging.DEBUG,
            format="%(asctime)s - %(levelname)s - %(message)s",
        )

        # Define the messages list for departure
        messages = [
            {
                "push_title": "일정장소 출발알림 👋",
                "push_content": "{name_prefix}'{title}' 장소에서 출발했어요!",
            }
            # {
            #     "push_title": "목적지 출발 소식 👋",
            #     "push_content": "{name_prefix}'{title}'에서 이동을 시작했습니다."
            # },
            # {
            #     "push_title": "일정 체크아웃 알림 👋",
            #     "push_content": "{name_prefix}'{title}' 일정 장소에서 체크아웃했어요!"
            # },
            # {
            #     "push_title": "위치 업데이트 📍",
            #     "push_content": "{name_prefix}'{title}' 위치에서 벗어났습니다."
            # },
            # {
            #     "push_title": "일정 장소 출발 확인 🚀",
            #     "push_content": "{name_prefix}'{title}'에서 출발하셨어요."
            # },
            # {
            #     "push_title": "위치 변경 알림 🔔",
            #     "push_content": "{name_prefix}'{title}'에서 이동을 시작했어요."
            # }
        ]

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "일정에 입력한 장소의 100미터 반경에서 이탈했을때"

            # 일정이 있는 50M 진입 후인 스케쥴 리스트
            push_list = smap_schedule_t.get_now_schedule_out_members()

            # Log the contents of push_list
            logging.debug("Push list contents: %s", push_list)

            for pt in push_list:
                logging.debug("pt list contents: %s", pt)
                mt_idx = None
                sst_idx = pt.sst_idx

                if not pt.sgt_idx is None and pt.sgdt_idx != 0:
                    sgt_idx = str(pt.sgt_idx)

                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if not group_member is None:
                        mt_idx = str(group_member.mt_idx)

                if not mt_idx is None:
                    if int(pt.mt_idx) != int(mt_idx):
                        # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                        member_location = member_location_log_t.getDistance(
                            str(pt.sst_location_lat), str(pt.sst_location_long), mt_idx
                        )
                        if not member_location is None:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)
                            push_json = {
                                "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                "distance": formatted_distance,
                            }
                            if 100.0 <= distance:
                                logger.info(f"ps_2 일정장소 출발 - {pt.mt_idx}")
                                try:
                                    logging.debug(
                                        f"pt.sst_exit_cnt : {pt.sst_exit_cnt} pt.sst_in_chk : {pt.sst_in_chk}"
                                    )
                                    if (
                                        int(pt.sst_exit_cnt) == 0
                                        and pt.sst_in_chk == "Y"
                                    ):
                                        # 그룹 정보 가져오기
                                        group_data = get_group_member(sgt_idx, mt_idx)

                                        if group_data["order"] != {}:
                                            # 오더전송
                                            if (
                                                group_data["order"]["mt_idx"]
                                                != group_data["member"]["mt_idx"]
                                            ):
                                                # Randomly select a message
                                                random_message = random.choice(messages)
                                                group_data["order"]["push_title"] = (
                                                    random_message["push_title"]
                                                )
                                                group_data["order"][
                                                    "push_content"
                                                ] = random_message[
                                                    "push_content"
                                                ].format(
                                                    name_prefix=group_data["member"][
                                                        "mt_name"
                                                    ]
                                                    + "님이 ",
                                                    title=str(pt.sst_title),
                                                )
                                                group_data["order"]["push_txt"] = (
                                                    group_data["order"]["push_content"]
                                                )
                                                group_data["order"]["send"] = "Y"
                                            else:
                                                group_data["order"]["send"] = "N"
                                        else:
                                            group_data["order"]["send"] = "N"

                                        if group_data["leader"] != {}:
                                            # 리더전송
                                            if (
                                                group_data["order"]["mt_idx"]
                                                == group_data["member"]["mt_idx"]
                                            ):
                                                group_data["leader"]["send"] = "N"
                                            else:
                                                if (
                                                    group_data["leader"]["mt_idx"]
                                                    != group_data["member"]["mt_idx"]
                                                ):
                                                    # Randomly select a message
                                                    random_message = random.choice(
                                                        messages
                                                    )
                                                    group_data["leader"][
                                                        "push_title"
                                                    ] = random_message["push_title"]
                                                    group_data["leader"][
                                                        "push_content"
                                                    ] = random_message[
                                                        "push_content"
                                                    ].format(
                                                        name_prefix=group_data[
                                                            "member"
                                                        ]["mt_name"]
                                                        + "님이 ",
                                                        title=str(pt.sst_title),
                                                    )
                                                    group_data["leader"]["push_txt"] = (
                                                        group_data["leader"][
                                                            "push_content"
                                                        ]
                                                    )
                                                    group_data["leader"]["send"] = "Y"
                                                else:
                                                    group_data["leader"]["send"] = "N"
                                        else:
                                            group_data["leader"]["send"] = "N"

                                        if group_data["member"] != {}:
                                            # 그룹원 전송
                                            # Randomly select a message
                                            random_message = random.choice(messages)
                                            group_data["member"]["push_title"] = (
                                                random_message["push_title"]
                                            )
                                            group_data["member"][
                                                "push_content"
                                            ] = random_message["push_content"].format(
                                                name_prefix="", title=str(pt.sst_title)
                                            )
                                            group_data["member"]["push_txt"] = (
                                                group_data["member"]["push_content"]
                                            )
                                            group_data["member"]["send"] = "N"
                                        else:
                                            group_data["member"]["send"] = "N"

                                        for key, group in group_data.items():
                                            # #테스트
                                            # if group['mt_idx'] == 79 or group['mt_idx'] == 98 or group['mt_idx'] == 80:
                                            if group["send"] == "Y":
                                                push_result = send_push(
                                                    group["mt_token_id"],
                                                    group["push_title"],
                                                    group["push_content"],
                                                )
                                                push_log_add(
                                                    group["mt_idx"],
                                                    pt.sst_idx,
                                                    plt_condition,
                                                    plt_memo,
                                                    group["push_title"],
                                                    group["push_txt"],
                                                    push_result,
                                                    push_json,
                                                )

                                                logging.debug(
                                                    f"pt.sst_idx : {pt.sst_idx} "
                                                )
                                                # 진입 여부 상태 수정
                                                schedule_result = (
                                                    schedule_status_update(
                                                        pt.sst_idx, "N"
                                                    )
                                                )
                                                # 진입 카운트 증가
                                                schedule_count_update(
                                                    2, pt.sst_idx, pt.sst_exit_cnt
                                                )
                                    else:
                                        # 진입 여부 상태 수정
                                        schedule_result = schedule_status_update(
                                            pt.sst_idx, "N"
                                        )
                                        # 진입 카운트 증가
                                        schedule_count_update(
                                            2, pt.sst_idx, pt.sst_exit_cnt
                                        )
                                except Exception as e:
                                    try:
                                        if mt_idx is None or mt_idx == "":
                                            push_err_log_add(
                                                None,
                                                "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                e,
                                                "멤버 없음",
                                            )
                                        else:
                                            member_info = member_t.find_one_idx(mt_idx)
                                            if member_info is None:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                    e,
                                                    "멤버 찾을 수 없음",
                                                )
                                            else:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에 이탈했을때 오류",
                                                    e,
                                                    member_info.mt_idx,
                                                )
                                        logger.error(
                                            "[ps_2]["
                                            + member_info.mt_idx
                                            + "] - "
                                            + str(e)
                                        )
                                        logging.error(
                                            "[ps_2] - Member ID: %s - Error: %s",
                                            (
                                                member_info.mt_idx
                                                if member_info
                                                else "Unknown"
                                            ),
                                            str(e),
                                        )
                                    except Exception as e:
                                        logging.error("Failed to log error: %s", str(e))

                    else:
                        # 진입 여부 상태 수정
                        schedule_result = schedule_status_update(pt.sst_idx, "N")
                        # 진입 카운트 증가
                        schedule_count_update(2, pt.sst_idx, pt.sst_exit_cnt)
            print("30초 - 장소알림 - 일정에 입력한 장소의 100미터 반경에서 이탈했을때")

    # 장소알림 - 내장소에 입력한 장소의 100미터 반경에 들어왔을때
    def ps_3():
        logger.info(f"ps_3 내장소 진입 시작")

        from smap.models import member_t
        from smap.models import smap_location_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import kmTom, send_push, get_group_member

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            push_list = smap_location_t.getInMyplaysList()
            logger.info(f"ps_3 push_list - {len(push_list)}")

            for pt in push_list:
                try:  # 각 push_list 항목 처리를 try-except 블록으로 감쌈
                    # logger.info(f"ps_3 내장소 방문 - {pt.mt_idx} / {pt.slt_lat} / {pt.slt_long}")
                    # logger.info(f'ps_3 pt value: {pt}')

                    if pt is not None:
                        # logger.info(f'ps_3 pt is not None: {pt} / pt.insert_mt_idx : {pt.insert_mt_idx} / pt.mt_idx : {pt.mt_idx} / pt.slt_enter_alarm : {pt.slt_enter_alarm.value}')
                        # 본인이 등록한 내장소 push 무시
                        # if pt.insert_mt_idx != pt.mt_idx:
                        # logger.info(f"ps_3 내장소 방문 - slt_enter_alarm : {pt.slt_enter_alarm}")
                        if pt.slt_enter_alarm == "Y":
                            # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                            logger.info(
                                f"ps_3 내장소 방문 - slt_lat : {pt.slt_lat} / slt_long : {pt.slt_long} / mt_idx : {pt.mt_idx}"
                            )
                            member_location = member_location_log_t.getDistance(
                                str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx)
                            )

                            logger.info(
                                f"ps_3 내장소 방문 거리 - {kmTom(member_location.distance)}"
                            )

                            if member_location is not None:
                                distance = kmTom(member_location.distance)
                                formatted_distance = "{:,.1f}".format(distance)
                                push_json = {
                                    "lat": "{:.7f}".format(float(pt.slt_lat)),
                                    "lng": "{:.7f}".format(float(pt.slt_long)),
                                    "distance": str(formatted_distance),
                                }
                                # 마지막 위치 시간과 현재 시간의 차이 계산
                                last_location_time = member_location.mlt_gps_time
                                current_time = datetime.datetime.now()
                                time_difference = current_time - last_location_time
                                logger.info(
                                    f"ps_3 내장소 방문 - time_difference : {time_difference}"
                                )
                                logger.info(
                                    f"ps_3 내장소 방문 - distance : {distance} / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work}"
                                )

                                if 100.0 >= distance:
                                    try:
                                        # 속도가 1이상이거나 이전보다 걸음수가 오른 경우
                                        b_member_lotacion = (
                                            member_location_log_t.find_last2_mt_idx(
                                                pt.mt_idx
                                            )
                                        )
                                        if not b_member_lotacion is None:
                                            if (
                                                member_location.mlt_speed > float(1)
                                            ) or (
                                                member_location.mt_health_work
                                                > b_member_lotacion.mt_health_work
                                            ):
                                                group_detail = (
                                                    smap_group_detail_t.get_one_idx(
                                                        pt.sgdt_idx
                                                    )
                                                )
                                                # 장소 정보 가져오기
                                                location_detail = (
                                                    smap_location_t.get_one_idx(
                                                        pt.slt_idx
                                                    )
                                                )

                                                if not group_detail is None:
                                                    group_data = get_group_member(
                                                        group_detail.sgt_idx, pt.mt_idx
                                                    )
                                                    if group_data["order"] != {}:
                                                        group_data["order"][
                                                            "push_title"
                                                        ] = "내장소 방문알림 🚩"
                                                        group_data["order"][
                                                            "push_content"
                                                        ] = (
                                                            group_data["member"][
                                                                "mt_name"
                                                            ]
                                                            + "님이 내장소 '"
                                                            + str(
                                                                location_detail.slt_title
                                                            )
                                                            + "'에 방문했어요!"
                                                        )
                                                        group_data["order"][
                                                            "push_txt"
                                                        ] = group_data["order"][
                                                            "push_content"
                                                        ]

                                                        # 오너가 등록한 경우 오너에서 push send
                                                        if (
                                                            pt.insert_mt_idx
                                                            == group_data["order"][
                                                                "mt_idx"
                                                            ]
                                                        ):
                                                            group_data["order"][
                                                                "send"
                                                            ] = "Y"
                                                        else:
                                                            group_data["order"][
                                                                "send"
                                                            ] = "N"
                                                    else:
                                                        group_data["order"][
                                                            "send"
                                                        ] = "N"

                                                    if group_data["leader"] != {}:
                                                        group_data["leader"][
                                                            "push_title"
                                                        ] = "내장소 방문알림 🚩"
                                                        group_data["leader"][
                                                            "push_content"
                                                        ] = (
                                                            group_data["member"][
                                                                "mt_name"
                                                            ]
                                                            + "님이 내장소 '"
                                                            + str(
                                                                location_detail.slt_title
                                                            )
                                                            + "'에 방문했어요!"
                                                        )
                                                        group_data["leader"][
                                                            "push_txt"
                                                        ] = group_data["leader"][
                                                            "push_content"
                                                        ]

                                                        # 리더가 등록한 경우 리더에거 push send
                                                        if (
                                                            pt.insert_mt_idx
                                                            == group_data["leader"][
                                                                "mt_idx"
                                                            ]
                                                        ):
                                                            group_data["leader"][
                                                                "send"
                                                            ] = "Y"
                                                        else:
                                                            group_data["leader"][
                                                                "send"
                                                            ] = "N"
                                                    else:
                                                        group_data["leader"][
                                                            "send"
                                                        ] = "N"

                                                    for (
                                                        key,
                                                        group,
                                                    ) in group_data.items():
                                                        if (
                                                            group != ""
                                                            and key != "member"
                                                        ):
                                                            # #테스트
                                                            # if group['mt_idx'] == 79 or group['mt_idx'] == 98 or group['mt_idx'] == 80:
                                                            if group["send"] == "Y":
                                                                push_result = send_push(
                                                                    group[
                                                                        "mt_token_id"
                                                                    ],
                                                                    group["push_title"],
                                                                    group[
                                                                        "push_content"
                                                                    ],
                                                                )
                                                                push_log_add(
                                                                    group["mt_idx"],
                                                                    pt.slt_idx,
                                                                    plt_condition,
                                                                    plt_memo,
                                                                    group["push_title"],
                                                                    group["push_txt"],
                                                                    push_result,
                                                                )

                                                    # 진입여부 수정
                                                    location_result = (
                                                        location_status_update(
                                                            pt.slt_idx, "Y"
                                                        )
                                                    )
                                    except Exception as e:
                                        if pt.mt_idx is None or pt.mt_idx == "":
                                            push_err_log_add(
                                                None,
                                                "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                e,
                                                "멤버 없음",
                                            )
                                        else:
                                            member_info = member_t.find_one_idx(
                                                pt.mt_idx
                                            )
                                            if member_info is None:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                    e,
                                                    "멤버 찾을 수 없음",
                                                )
                                            else:
                                                push_err_log_add(
                                                    None,
                                                    "30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때 오류",
                                                    e,
                                                    member_info.mt_id,
                                                )
                                        print(e)
                                        pass

                        # else:
                        #     logger.info(f"ps_3 내장소 방문 - 입력한 사람과 대상이 같아. mt_idx : {pt.mt_idx}")
                except Exception as e:  # 예외 발생 시 에러 로깅 및 처리
                    logger.error(f"ps_3 내장소 처리 중 오류 발생: {e}")
                    print(f"ps_3 내장소 처리 중 오류 발생: {e}")
                    # 필요에 따라 추가적인 오류 처리 로직 추가 가능

            print("30초 - 장소알림 - 내장소에 입력한 장소의 50미터 반경에 들어왔을때")

    # 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때
    def ps_4():
        logger.info("ps_4 내장소 이탈 시작")
        from smap.models import (
            member_t,
            smap_location_t,
            smap_group_detail_t,
            member_location_log_t,
        )
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import datetime

        with app.app_context():
            plt_condition = "30초 - 장소알림"
            plt_memo = "내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            push_list = smap_location_t.getOutMyplaysList()
            # logger.info(f'ps_4 push_list - {len(push_list)}')

            for pt in push_list:
                logger.info(
                    f"ps_4 내장소 이탈 - {pt.mt_idx} / {pt.slt_lat} / {pt.slt_long} / {pt.mt_idx}"
                )
                logger.info(pt)

                if pt is not None:
                    # 본인이 등록한 내장소 push 무시
                    # if pt.insert_mt_idx != pt.mt_idx:
                    # logger.info(f"ps_4 내장소 이탈 - slt_enter_alarm : {pt.slt_enter_alarm}")
                    if pt.slt_enter_alarm == "Y":
                        # 해당 회원의 마지막 위치값과 장소의 위치값 비교
                        logger.info(
                            f"ps_4 내장소 이탈 - slt_lat : {pt.slt_lat} / slt_long : {pt.slt_long} / mt_idx : {pt.mt_idx}"
                        )
                        member_location = member_location_log_t.getDistance(
                            str(pt.slt_lat), str(pt.slt_long), str(pt.mt_idx)
                        )

                        if member_location is not None:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)

                            push_json = {
                                "lat": "{:.7f}".format(float(pt.slt_lat)),
                                "lng": "{:.7f}".format(float(pt.slt_long)),
                                "distance": str(formatted_distance),
                            }

                            # 마지막 위치 시간과 현재 시간의 차이 계산
                            last_location_time = member_location.mlt_gps_time
                            current_time = datetime.datetime.now()
                            time_difference = current_time - last_location_time

                            logger.info(
                                f"ps_4 내장소 이탈 - distance : {distance} / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work}"
                            )

                            if distance >= 100.0:
                                try:
                                    # 속도가 1 이상이거나 이전보다 걸음수가 오른 경우
                                    b_member_location = (
                                        member_location_log_t.find_last2_mt_idx(
                                            pt.mt_idx
                                        )
                                    )
                                    logger.info(
                                        f"ps_4 내장소 이탈 - b_member_location not None / speed : {member_location.mlt_speed} / health_walk : {member_location.mt_health_work} / b_member_location.mt_health_work : {b_member_location.mt_health_work}"
                                    )

                                    if b_member_location is not None:
                                        if (member_location.mlt_speed > float(1)) or (
                                            member_location.mt_health_work
                                            > b_member_location.mt_health_work
                                        ):
                                            group_detail = (
                                                smap_group_detail_t.get_one_idx(
                                                    pt.sgdt_idx
                                                )
                                            )
                                            location_detail = (
                                                smap_location_t.get_one_idx(pt.slt_idx)
                                            )

                                            if group_detail is not None:
                                                group_data = get_group_member(
                                                    group_detail.sgt_idx, pt.mt_idx
                                                )
                                                if group_data["order"]:
                                                    group_data["order"][
                                                        "push_title"
                                                    ] = "내장소 이탈알림 🚀 "
                                                    group_data["order"][
                                                        "push_content"
                                                    ] = (
                                                        group_data["member"]["mt_name"]
                                                        + "님이 내장소 '"
                                                        + str(location_detail.slt_title)
                                                        + "'에서 이탈했어요!"
                                                    )
                                                    group_data["order"]["push_txt"] = (
                                                        group_data["order"][
                                                            "push_content"
                                                        ]
                                                    )
                                                    group_data["order"]["send"] = "Y"
                                                else:
                                                    group_data["order"]["send"] = "N"

                                                if group_data["leader"]:
                                                    group_data["leader"][
                                                        "push_title"
                                                    ] = "내장소 이탈알림 🚀 "
                                                    group_data["leader"][
                                                        "push_content"
                                                    ] = (
                                                        group_data["member"]["mt_name"]
                                                        + "님이 내장소 '"
                                                        + str(location_detail.slt_title)
                                                        + "'에서 이탈했어요!"
                                                    )
                                                    group_data["leader"]["push_txt"] = (
                                                        group_data["leader"][
                                                            "push_content"
                                                        ]
                                                    )

                                                    # 리더가 등록한 경우 리더에거 push send
                                                    if (
                                                        pt.insert_mt_idx
                                                        == group_data["leader"][
                                                            "mt_idx"
                                                        ]
                                                    ):
                                                        group_data["leader"][
                                                            "send"
                                                        ] = "Y"
                                                    else:
                                                        group_data["leader"][
                                                            "send"
                                                        ] = "N"
                                                else:
                                                    group_data["leader"]["send"] = "N"

                                                for key, group in group_data.items():
                                                    if group and key != "member":
                                                        if group["send"] == "Y":
                                                            push_result = send_push(
                                                                group["mt_token_id"],
                                                                group["push_title"],
                                                                group["push_content"],
                                                            )
                                                            push_log_add(
                                                                group["mt_idx"],
                                                                pt.slt_idx,
                                                                plt_condition,
                                                                plt_memo,
                                                                group["push_title"],
                                                                group["push_txt"],
                                                                push_result,
                                                                push_json,
                                                            )

                                            # 진입여부 수정
                                            location_result = location_status_update(
                                                pt.slt_idx, "N"
                                            )
                                except Exception as e:
                                    member_info = (
                                        member_t.find_one_idx(pt.mt_idx)
                                        if pt.mt_idx
                                        else None
                                    )

                                    if member_info is None:
                                        push_err_log_add(
                                            None,
                                            "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때 오류",
                                            e,
                                            "멤버 없음",
                                        )
                                    else:
                                        push_err_log_add(
                                            None,
                                            "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때 오류",
                                            e,
                                            member_info.mt_idx,
                                        )
                                    logger.error(
                                        f'[ps_4][{member_info.mt_idx if member_info else "None"}] - {e}'
                                    )
            print(
                "30초 - 장소알림 - 내장소에 입력한 장소의 100미터 반경에서 이탈했을때"
            )

    # 일정알림 - 일정에 입력한 알림주기에 알림
    def ps_5():
        logger.info(f"ps_5 일정알림 시작")
        from smap.models import member_t
        from smap.models import smap_schedule_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push, get_group_member

        with app.app_context():
            plt_condition = "1분 - 일정알림"
            plt_memo = "일정에 입력한 알림주기에 알림"
            sst_pick_type_arr = {"minute": "분", "hour": "시간", "day": "일"}

            push_list = smap_schedule_t.get_now_schedule_push()
            for pt in push_list:
                puth_type = 1  # 1개인 2 그룹
                mt_idx = None
                if pt.sgt_idx is None and pt.sgdt_idx == 0:
                    puth_type = 1
                    mt_idx = str(pt.mt_idx)
                else:
                    puth_type = 2
                    sgt_idx = str(pt.sgt_idx)
                    # 그룹에서 해당 회원의 mt_idx가져오기
                    group_member = smap_group_detail_t.get_one_member(str(pt.sgdt_idx))
                    if not group_member is None:
                        mt_idx = str(group_member.mt_idx)

                if not mt_idx is None:
                    try:
                        logger.info(f"ps_5 일정알림 - {pt.mt_idx}")
                        if puth_type == 1:
                            # 본인의 정보가져오기
                            member = member_t.find_one_idx(mt_idx)
                            mt_name = member.mt_name
                            if (
                                not member.mt_nickname is None
                                and member.mt_nickname != ""
                            ):
                                mt_name = member.mt_nickname

                            push_title = "일정 시작알림 ⏰"
                            push_content = (
                                "'"
                                + str(pt.sst_title)
                                + "' 일정 "
                                + str(pt.sst_pick_result)
                                + sst_pick_type_arr[pt.sst_pick_type]
                                + " 전 입니다."
                            )
                            push_txt = push_content
                            push_result = send_push(
                                member.mt_token_id, push_title, push_content
                            )
                            push_log_add(
                                member.mt_idx,
                                pt.sst_idx,
                                plt_condition,
                                plt_memo,
                                push_title,
                                push_txt,
                                push_result,
                            )

                            schedule_status_push_update(pt.sst_idx, "Y")
                        else:
                            # 그룹
                            group_data = get_group_member(sgt_idx, mt_idx)
                            if group_data["order"] != {}:
                                # 오더전송
                                if (
                                    group_data["order"]["mt_idx"]
                                    != group_data["member"]["mt_idx"]
                                ):
                                    group_data["order"][
                                        "push_title"
                                    ] = "일정 시작알림 ⏰"
                                    group_data["order"]["push_content"] = (
                                        group_data["member"]["mt_name"]
                                        + "님의 '"
                                        + str(pt.sst_title)
                                        + "' 일정 "
                                        + str(pt.sst_pick_result)
                                        + sst_pick_type_arr[pt.sst_pick_type]
                                        + " 전 입니다."
                                    )
                                    group_data["order"]["push_txt"] = group_data[
                                        "order"
                                    ]["push_content"]
                                    group_data["order"]["send"] = "Y"
                                else:
                                    group_data["order"]["send"] = "N"

                            if group_data["leader"] != {}:
                                # 리더전송
                                if (
                                    group_data["order"]["mt_idx"]
                                    == group_data["member"]["mt_idx"]
                                ):
                                    group_data["leader"]["send"] = "N"
                                else:
                                    if (
                                        group_data["leader"]["mt_idx"]
                                        != group_data["member"]["mt_idx"]
                                    ):
                                        group_data["leader"][
                                            "push_title"
                                        ] = "일정 시작알림 ⏰"
                                        group_data["leader"]["push_content"] = (
                                            group_data["member"]["mt_name"]
                                            + "님의 '"
                                            + str(pt.sst_title)
                                            + "' 일정 "
                                            + str(pt.sst_pick_result)
                                            + sst_pick_type_arr[pt.sst_pick_type]
                                            + " 전 입니다."
                                        )
                                        group_data["leader"]["push_txt"] = group_data[
                                            "leader"
                                        ]["push_content"]
                                        group_data["leader"]["send"] = "Y"
                                    else:
                                        group_data["leader"]["send"] = "N"
                            else:
                                group_data["leader"]["send"] = "N"

                            if group_data["member"] != {}:
                                group_data["member"]["push_title"] = "일정 시작알림 ⏰"
                                group_data["member"]["push_content"] = (
                                    "'"
                                    + str(pt.sst_title)
                                    + "' 일정 "
                                    + str(pt.sst_pick_result)
                                    + sst_pick_type_arr[pt.sst_pick_type]
                                    + " 전 입니다."
                                )
                                group_data["member"]["push_txt"] = group_data["member"][
                                    "push_content"
                                ]
                                group_data["member"]["send"] = "Y"
                            else:
                                group_data["member"]["send"] = "N"

                            for key, group in group_data.items():
                                if group != "":
                                    if group["send"] == "Y":
                                        push_result = send_push(
                                            group["mt_token_id"],
                                            group["push_title"],
                                            group["push_content"],
                                        )
                                        push_log_add(
                                            group["mt_idx"],
                                            pt.sst_idx,
                                            plt_condition,
                                            plt_memo,
                                            group["push_title"],
                                            group["push_txt"],
                                            push_result,
                                        )
                            schedule_status_push_update(pt.sst_idx, "Y")
                    except Exception as e:
                        if mt_idx is None or mt_idx == "":
                            push_err_log_add(
                                None,
                                "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "1분 - 일정알림 - 일정에 입력한 알림주기에 알림 오류",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_5][" + member_info.mt_idx + "] - " + e)
            print("1분 - 일정알림 - 일정에 입력한 알림주기에 알림")

    def ps_6():
        logger.info(f"ps_6 일정출발 알림 시작")
        from smap.models import member_t
        from smap.models import smap_schedule_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import kmTom, get_group_member, send_push

        with app.app_context():
            plt_condition = "5분 - 장소+일정알림"
            plt_memo = "일정 시작 30분 전 움직임이 없을 경우"
            push_list = smap_schedule_t.start_befor30()

            for pt in push_list:
                member_location = member_location_log_t.getDistance(
                    str(pt.sst_location_lat), str(pt.sst_location_long), str(pt.mt_idx)
                )

                if member_location is not None:
                    # 현재 시간을 가져옵니다.
                    current_time = dt.now()

                    # member_location에는 mlt_gps_time이 있을 것이므로 이를 datetime 객체로 변환합니다.
                    mlt_gps_time = dt.strptime(
                        member_location["mlt_gps_time"], "%Y-%m-%d %H:%M:%S"
                    )

                    # 현재 시간과 mlt_gps_time의 차이를 계산합니다.
                    time_difference = current_time - mlt_gps_time

                    if time_difference <= timedelta(minutes=35):
                        try:
                            distance = kmTom(member_location.distance)
                            formatted_distance = "{:,.1f}".format(distance)
                            push_json = {
                                "lat": "{:.7f}".format(float(pt.sst_location_lat)),
                                "lng": "{:.7f}".format(float(pt.sst_location_long)),
                                "distance": str(formatted_distance),
                            }

                            if 500.0 < distance:
                                logger.info(f"ps_6 일정출발 알림 - {pt.mt_idx}")
                                group_data = get_group_member(pt.sgt_idx, pt.mt_idx)

                                if group_data["order"] != {}:
                                    if (
                                        group_data["order"]["mt_idx"]
                                        != group_data["member"]["mt_idx"]
                                    ):
                                        group_data["order"][
                                            "push_title"
                                        ] = "일정 이동알림 🔔 "
                                        group_data["order"]["push_content"] = (
                                            group_data["member"]["mt_name"]
                                            + "님이 다음 '"
                                            + str(pt.sst_title)
                                            + "' 일정을 위해서 이동을 시작해야할 시간이에요."
                                        )
                                        group_data["order"]["push_txt"] = group_data[
                                            "order"
                                        ]["push_content"]
                                        group_data["order"]["send"] = "Y"
                                    else:
                                        group_data["order"]["send"] = "N"
                                else:
                                    group_data["order"]["send"] = "N"

                                if group_data["leader"] != {}:
                                    if (
                                        group_data["order"]["mt_idx"]
                                        == group_data["member"]["mt_idx"]
                                    ):
                                        group_data["leader"]["send"] = "N"
                                    else:
                                        if (
                                            group_data["leader"]["mt_idx"]
                                            != group_data["member"]["mt_idx"]
                                        ):
                                            group_data["leader"][
                                                "push_title"
                                            ] = "일정 이동알림 🔔 "
                                            group_data["leader"]["push_content"] = (
                                                group_data["member"]["mt_name"]
                                                + "님이 다음 '"
                                                + str(pt.sst_title)
                                                + "' 일정을 위해서 이동을 시작해야할 시간이에요."
                                            )
                                            group_data["leader"]["push_txt"] = (
                                                group_data["leader"]["push_content"]
                                            )
                                            group_data["leader"]["send"] = "Y"
                                        else:
                                            group_data["leader"]["send"] = "N"
                                else:
                                    group_data["leader"]["send"] = "N"

                                if group_data["member"] != {}:
                                    group_data["member"][
                                        "push_title"
                                    ] = "일정 이동알림 🔔 "
                                    group_data["member"]["push_content"] = (
                                        "다음 '"
                                        + str(pt.sst_title)
                                        + "' 일정을 위해서 이동을 시작해야해요."
                                    )
                                    group_data["member"]["push_txt"] = group_data[
                                        "member"
                                    ]["push_content"]
                                    group_data["member"]["send"] = "Y"
                                else:
                                    group_data["member"]["send"] = "N"

                                for key, group in group_data.items():
                                    if group != "":
                                        if group["send"] == "Y":
                                            push_result = send_push(
                                                group["mt_token_id"],
                                                group["push_title"],
                                                group["push_content"],
                                            )
                                            push_log_add(
                                                group["mt_idx"],
                                                pt.sst_idx,
                                                plt_condition,
                                                plt_memo,
                                                group["push_title"],
                                                group["push_txt"],
                                                push_result,
                                                push_json,
                                            )
                        except Exception as e:
                            if pt.mt_idx is None or pt.mt_idx == "":
                                push_err_log_add(
                                    None,
                                    "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                    e,
                                    "멤버 없음",
                                )
                            else:
                                member_info = member_t.find_one_idx(pt.mt_idx)
                                if member_info is None:
                                    push_err_log_add(
                                        None,
                                        "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                        e,
                                        "멤버 찾을 수 없음",
                                    )
                                else:
                                    push_err_log_add(
                                        None,
                                        "5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우",
                                        e,
                                        member_info.mt_idx,
                                    )
                            logger.error(f"[ps_6][{member_info.mt_idx}] - {e}")

            print("5분 - 장소+일정알림 - 일정 시작 30분 전 움직임이 없을 경우")

    # 구독 - 가입 후 3일 남음
    def ps_7():
        import datetime
        from smap.models import member_t
        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "오전 10시 = 구독"
            plt_memo = "가입 후 11일 경과"
            after_3_day = dt.now() + timedelta(days=3)
            after_3_day_s = after_3_day.strftime("%m월%d일")

            # 구독하지 않은 오더 list
            push_list = member_t.getNotJoinGroup3()
            for pt in push_list:
                if pt.sgdt_owner_chk == "Y":
                    try:
                        mt_name = pt.mt_name
                        if not pt.mt_nickname is None and pt.mt_nickname != "":
                            mt_name = pt.mt_nickname

                        push_title = "서비스 안내 🧾"
                        push_content = (
                            "안녕하세요, "
                            + str(mt_name)
                            + " 님!\nSMAP Pro 서비스 구독 기간이 곧 종료될 예정이에요.\n"
                            + after_3_day_s
                            + "부터는 Basic 서비스로 전환됩니다.\n감사합니다!"
                        )
                        push_txt = push_content
                        push_result = send_push(
                            pt.mt_token_id, push_title, push_content
                        )
                        push_log_add(
                            pt.mt_idx,
                            None,
                            plt_condition,
                            plt_memo,
                            push_title,
                            push_txt,
                            push_result,
                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "오전 10시 - 구독 - 가입 후 11일 경과",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "오전 10시 - 구독 - 가입 후 11일 경과",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "오전 10시 - 구독 - 가입 후 11일 경과",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_7][" + member_info.mt_idx + "] - " + e)
            print("오전 10시 - 구독 - 가입 후 11일 경과")

    # 구독 - 가입 후 13일 경과
    def ps_8():
        from smap.models import member_t
        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "오전 10시 = 구독"
            plt_memo = "가입 후 11일 경과"

            # 구독하지 않은 오더 list
            push_list = member_t.getNotJoinGroup11()
            for pt in push_list:
                if pt.sgdt_owner_chk == "Y":
                    try:
                        mt_name = pt.mt_name
                        if not pt.mt_nickname is None and pt.mt_nickname != "":
                            mt_name = pt.mt_nickname

                        push_title = "서비스 안내 🧾"
                        push_content = (
                            "안녕하세요, "
                            + str(mt_name)
                            + " 님! \n내일부터 내장소 입력이 2개로 제한되고, 일부 광고가 표시될 예정입니다."
                        )
                        push_result = send_push(
                            pt.mt_token_id, push_title, push_content
                        )
                        push_txt = push_content
                        push_log_add(
                            pt.mt_idx,
                            None,
                            plt_condition,
                            plt_memo,
                            push_title,
                            push_txt,
                            push_result,
                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "오전 10시 - 구독 - 가입 후 11일 경과",
                                e,
                                "멤버없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "오전 10시 - 구독 - 가입 후 11일 경과",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "오전 10시 - 구독 - 가입 후 11일 경과",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_8][" + member_info.mt_idx + "] - " + e)
            print("오전 10시 - 구독 - 가입 후 13일 경과")

    # 날씨 - 오전 7시 + 사용자위치
    def ps_9():
        from smap.models import member_t
        from smap.apis.weather import Weather
        from smap.models import member_location_log_t
        from smap.apis.lib_func import (
            get_latlong_to_add_naver,
            send_push,
            get_weather_emoji,
            get_weather_sky,
        )

        with app.app_context():
            plt_condition = "오전 7시 - 날씨"
            plt_memo = "해당일 일기예보 발송"

            now = datetime.datetime.now()
            now = now.strftime("%Y-%m-%d")

            push_list = member_t.getTokenList()
            for pt in push_list:
                try:
                    logger.info(f"ps_9 날씨 - pt.mt_idx : {pt.mt_idx}")

                    # 최근 위치 가져오기
                    member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
                    if member_info is None:
                        # 해당 계정 마지막 로그 구하기
                        member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                        if member_info is None:
                            # 서울 명동으로 위치 지정
                            mlt_lat = 37.56668050000000
                            mlt_long = 126.97841470000000
                        else:
                            mlt_lat = float(member_info.mlt_lat)
                            mlt_long = float(member_info.mlt_long)
                    else:
                        logger.info(
                            f"ps_9 날씨 - mlt_lat : {member_info.mlt_lat} / mlt_long : {member_info.mlt_long}"
                        )
                        mlt_lat = float(member_info.mlt_lat)
                        mlt_long = float(member_info.mlt_long)

                    # 단기예보
                    categorys1 = ["TMN", "TMX", "POP"]
                    user_weather = Weather()
                    response1 = user_weather.requestForecast(
                        mlt_lat, mlt_long, 6, "", 0
                    )
                    today_weather1 = user_weather.parseWeather(response1, categorys1)

                    # 초단기예보
                    categorys2 = ["SKY", "PTY"]
                    response2 = user_weather.requestForecast(
                        mlt_lat, mlt_long, 0, "", 0
                    )
                    today_weather2 = user_weather.parseWeather(response2, categorys2)
                    emoji = get_weather_emoji(today_weather2)

                    # 사용자 위치로 주소 가져오기
                    coords = f"{mlt_long},{mlt_lat}"
                    user_add = get_latlong_to_add_naver(coords)

                    push_title = f"날씨 정보 {emoji}"
                    push_content = f"{user_add['area1']} {user_add['area2']}/{user_add['area3']}\n강수확률 : {today_weather1['POP']}\n최저기온 : {today_weather1['TMN']}\n최고기온 : {today_weather1['TMX']}"
                    push_result = send_push(pt.mt_token_id, push_title, push_content)
                    push_txt = push_content
                    push_log_add(
                        pt.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )

                    logger.info(f"회원 {pt.mt_idx}에 대한 처리 완료")

                except Exception as e:
                    error_message = f"[ps_9][{pt.mt_idx}] - {str(e)}"
                    logger.error(error_message)
                    try:
                        # 에러 로그 추가 및 관리자 푸시 알림
                        member_info = member_t.find_one_idx(pt.mt_idx)
                        if member_info is None:
                            push_err_log_add(
                                None,
                                "1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우",
                                e,
                                "멤버 찾을 수 없음",
                            )
                        else:
                            push_err_log_add(
                                None,
                                "1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우",
                                e,
                                member_info.mt_idx,
                            )
                        admin_send_push(error_message)
                    except Exception as inner_e:
                        logger.error(f"추가 에러 처리 중 오류 발생: {str(inner_e)}")

            logger.info("오전 7시 - 날씨 - 해당일 일기예보 발송 완료")

    # 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우
    def ps_10():
        from smap.models import member_t
        from smap.models import smap_group_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "가입후 3시간 경과 "
            plt_memo = "그룹 생성 안했을 경우"

            push_list = member_t.getSignIn3()
            for pt in push_list:
                sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
                sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
                sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)

                if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgdt_cnt == 0:
                    try:
                        push_title = "그룹을 생성해보세요. 👫 "
                        push_content = "서비스를 더 잘 이용하시려면 그룹을 생성해보세요.\n그룹을 통해 그룹원의 위치를 파악하고, 일정을 공유할 수 있습니다."
                        push_txt = push_content
                        push_result = send_push(
                            pt.mt_token_id, push_title, push_content
                        )
                        push_log_add(
                            pt.mt_idx,
                            None,
                            plt_condition,
                            plt_memo,
                            push_title,
                            push_txt,
                            push_result,
                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_10][" + member_info.mt_idx + "] - " + e)
            print("1시간 - 사용독려 - 가입후 3시간 경과 + 그룹 생성 안했을 경우")

    # 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우
    def ps_11():
        from smap.models import member_t
        from smap.models import smap_group_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "가입후 24시간 경과 "
            plt_memo = "그룹 생성 안했을 경우"

            push_list = member_t.getSignIn24()
            for pt in push_list:
                sgt_cnt = smap_group_t.get_group_count(pt.mt_idx)
                sgdt_leader_cnt = smap_group_detail_t.get_gd_leader_count(pt.mt_idx)
                sgdt_cnt = smap_group_detail_t.get_gd_count(pt.mt_idx)

                if sgt_cnt == 0 and sgdt_leader_cnt == 0 and sgdt_cnt == 0:
                    try:
                        push_title = "그룹을 생성해보세요. 👥"
                        push_content = "그룹을 만들면 서비스를 더 효과적으로 이용할 수 있습니다.\n 지금 바로 그룹을 만들어보세요."
                        push_txt = push_content
                        push_result = send_push(
                            pt.mt_token_id, push_title, push_content
                        )
                        push_log_add(
                            pt.mt_idx,
                            None,
                            plt_condition,
                            plt_memo,
                            push_title,
                            push_txt,
                            push_result,
                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_11][" + member_info.mt_idx + "] - " + e)
            print("1시간 - 사용독려 - 가입후 24시간 경과 + 그룹 생성 안했을 경우")

    # 배터리 - 19시에 배터리체크 후 50% 이하
    def ps_12():
        from smap.models import member_t
        from smap.models import smap_group_detail_t
        from smap.models import member_location_log_t

        from smap.apis.lib_func import get_group_member, send_push

        with app.app_context():
            plt_condition = "오후 7시 - 배터리체크"
            plt_memo = "19시에 배터리체크 후 50% 이하"
            push_list = smap_group_detail_t.get_member_list()
            for pt in push_list:
                # 해당 학생의 마지막로그 가져오기
                mlt_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                if mlt_info != None:
                    try:
                        if mlt_info.mlt_battery <= 50:
                            group_data = get_group_member(pt.sgt_idx, pt.mt_idx)

                            if group_data["order"] != {}:
                                # 오더 전송
                                group_data["order"][
                                    "push_title"
                                ] = "배터리 부족 알림 🪫"
                                group_data["order"]["push_content"] = (
                                    group_data["member"]["mt_name"]
                                    + "님의 핸드폰 배터리가 50% 미만이에요. \n충전 해주세요! 🔌"
                                )
                                group_data["order"]["push_txt"] = group_data["order"][
                                    "push_content"
                                ]
                                group_data["order"]["send"] = "Y"
                            else:
                                group_data["order"]["send"] = "N"

                            if group_data["leader"] != {}:
                                # 리더전송
                                group_data["leader"][
                                    "push_title"
                                ] = "배터리 부족 알림 🪫"
                                group_data["leader"]["push_content"] = (
                                    group_data["member"]["mt_name"]
                                    + "님의 핸드폰 배터리가 50% 미만이에요. \n충전 헤주세요! 🔌"
                                )
                                group_data["leader"]["push_txt"] = group_data["leader"][
                                    "push_content"
                                ]
                                group_data["leader"]["send"] = "Y"
                            else:
                                group_data["leader"]["send"] = "N"

                            if group_data["member"] != {}:
                                # 학생전송
                                group_data["member"][
                                    "push_title"
                                ] = "배터리 부족 알림 🪫"
                                group_data["member"][
                                    "push_content"
                                ] = "현재 핸드폰 배터리가 50% 미만이에요. ⚡️\n충전 해주세요!  🔌"
                                group_data["member"]["push_txt"] = group_data["member"][
                                    "push_content"
                                ]
                                group_data["member"]["send"] = "Y"
                            else:
                                group_data["member"]["send"] = "N"

                            for key, group in group_data.items():
                                if group != "":
                                    if group["send"] == "Y":
                                        push_result = send_push(
                                            group["mt_token_id"],
                                            group["push_title"],
                                            group["push_content"],
                                        )
                                        push_log_add(
                                            group["mt_idx"],
                                            None,
                                            plt_condition,
                                            plt_memo,
                                            group["push_title"],
                                            group["push_txt"],
                                            push_result,
                                        )
                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하",
                                    e,
                                    member_info.mt_idx,
                                )
                        logger.error("[ps_12][" + member_info.mt_idx + "] - " + e)
            print("오후 7시 - 배터리 - 19시에 배터리체크 후 50% 이하")

    # 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우
    def ps_13():
        from smap.models import member_t
        from smap.models import smap_group_detail_t

        from smap.apis.lib_func import get_group_member, send_push

        with app.app_context():
            plt_condition = "1시간 - 권한"
            plt_memo = "그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우"

            push_list = smap_group_detail_t.joinGroup1()

            if push_list:  # push_list에 데이터가 1건 이상 존재하는지 확인
                for pt in push_list:
                    try:
                        group_data = get_group_member(pt.sgt_idx, pt.mt_idx)
                        if group_data["order"] != {}:
                            # 오더 전송
                            group_data["order"]["push_title"] = "권한 설정 요청 🔑 "
                            group_data["order"]["push_content"] = (
                                "정확한 위치 정보 제공을 위해\n"
                                + group_data["member"]["mt_name"]
                                + "님의 핸드폰 권한 설정을 해주세요."
                            )
                            group_data["order"]["push_txt"] = group_data["order"][
                                "push_content"
                            ]
                            group_data["order"]["send"] = "Y"
                        else:
                            group_data["order"]["send"] = "N"

                        if group_data["leader"] != {}:
                            # 리더전송
                            group_data["leader"]["push_title"] = "권한 설정 요청 🔑 "
                            group_data["leader"]["push_content"] = (
                                "정확한 위치 정보 제공을 위해\n"
                                + group_data["member"]["mt_name"]
                                + "님의 핸드폰 권한 설정을 해주세요."
                            )
                            group_data["leader"]["push_txt"] = group_data["leader"][
                                "push_content"
                            ]
                            group_data["leader"]["send"] = "Y"
                        else:
                            group_data["leader"]["send"] = "N"

                        for (
                            key,
                            group,
                        ) in group_data.items():  # 수정된 부분: items() 메서드 사용
                            if group != "" and key != "member":
                                if group["send"] == "Y":
                                    push_result = send_push(
                                        group["mt_token_id"],
                                        group["push_title"],
                                        group["push_content"],
                                    )
                                    push_log_add(
                                        group["mt_idx"],
                                        pt.sst_idx,
                                        plt_condition,
                                        plt_memo,
                                        group["push_title"],
                                        group["push_txt"],
                                        push_result,
                                    )

                    except Exception as e:
                        if pt.mt_idx is None or pt.mt_idx == "":
                            push_err_log_add(
                                None,
                                "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우",
                                e,
                                "멤버 없음",
                            )
                        else:
                            member_info = member_t.find_one_idx(pt.mt_idx)
                            if member_info is None:
                                push_err_log_add(
                                    None,
                                    "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우",
                                    e,
                                    "멤버 찾을 수 없음",
                                )
                            else:
                                push_err_log_add(
                                    None,
                                    "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우",
                                    e,
                                    member_info.mt_idx,
                                )

                        logger.error(
                            "[ps_13][" + member_info.mt_idx + "] - " + str(e)
                        )  # 수정된 부분: str(e) 사용
                print(
                    "1시간 - 권한 - 그룹원이 서비스 이용을 위한 권한 설정이 되어있지 않은 경우"
                )

    def ps_14():
        import json

        from smap.models import smap_group_detail_t
        from smap.models import push_fcm_t
        from smap.models import member_t

        from smap.apis.lib_func import send_push

        with app.app_context():
            plt_condition = "1시간 - 예약 push 발송"
            plt_memo = "예약 push 발송"

            push_list = push_fcm_t.find_push_list()
            for pt in push_list:
                loop_push_update(pt.pft_idx, 1)
                try:
                    push_title = pt.pft_title
                    push_content = pt.pft_content
                    push_txt = pt.pft_content
                    push_url = None
                    if not pt.pft_url is None or pt.pft_url != "":
                        push_url = pt.pft_url

                    if pt.pft_send_type == 1:
                        # 전체 push
                        member_list = member_t.getTokenList()
                        for member in member_list:
                            if not member is None:
                                # if member.mt_idx == 80 or member.mt_idx == 98 or member.mt_idx == 79:
                                push_result = send_push(
                                    member.mt_token_id,
                                    push_title,
                                    push_content,
                                    push_url,
                                )
                                push_log_add(
                                    member.mt_idx,
                                    None,
                                    plt_condition,
                                    plt_memo,
                                    push_title,
                                    push_txt,
                                    push_result,
                                )
                    elif pt.pft_send_type == 2:
                        # 특정 사용자에게 전송
                        mt_list = json.loads(pt.pft_send_mt_idx)
                        for mt_idx in mt_list:
                            member = member_t.find_one_idx(mt_idx)
                            if not member is None:
                                push_result = send_push(
                                    member.mt_token_id,
                                    push_title,
                                    push_content,
                                    push_url,
                                )
                                push_log_add(
                                    member.mt_idx,
                                    None,
                                    plt_condition,
                                    plt_memo,
                                    push_title,
                                    push_txt,
                                    push_result,
                                )
                    elif pt.pft_send_type == 3:
                        # 특정 그룹에 전송
                        group_idx_list = json.loads(pt.pft_send_mt_idx)
                        for group_idx in group_idx_list:
                            group_list = smap_group_detail_t.get_group(group_idx)
                            for group_member in group_list:
                                member = member_t.find_one_idx(group_member.mt_idx)
                                if not member is None:
                                    push_result = send_push(
                                        member.mt_token_id,
                                        push_title,
                                        push_content,
                                        push_url,
                                    )
                                    push_log_add(
                                        member.mt_idx,
                                        None,
                                        plt_condition,
                                        plt_memo,
                                        push_title,
                                        push_txt,
                                        push_result,
                                    )

                    loop_push_update(pt.pft_idx, 2)

                except Exception as e:
                    push_err_log_add(None, "1시간 - 예약 push 발송", e)
                    logger.error("[ps_14][" + member_info.mt_idx + "] - " + e)
            print("1시간 - 예약 push 발송")

    # 10분마다 사용자위치 업데이트
    def ps_15():
        from smap.models import member_t, member_location_log_t
        from smap.apis.lib_func import get_latlong_to_add_naver
        import logging
        import datetime

        # 로그 설정
        # logging.basicConfig(filename='debug.log', level=logging.DEBUG, format='%(asctime)s:%(levelname)s:%(message)s')

        with app.app_context():
            plt_condition = "10분마다 모든 멤버"
            plt_memo = "위치 업데이트"

            now = datetime.datetime.now()
            now = now.strftime("%Y-%m-%d")

            push_list = member_t.getTokenList()
            for pt in push_list:
                try:
                    # 최근 위치 가져오기
                    member_info = member_location_log_t.find_one_mt_idx_now(pt.mt_idx)
                    if member_info is None:
                        # 해당 계정 마지막 로그 구하기
                        member_info = member_location_log_t.find_one_mt_idx(pt.mt_idx)
                        if member_info is None:
                            # 서울 명동으로 위치 지정
                            mlt_lat = "37.56668050000000"
                            mlt_long = "126.97841470000000"
                        else:
                            mlt_lat = member_info.mlt_lat
                            mlt_long = member_info.mlt_long
                    else:
                        mlt_lat = member_info.mlt_lat
                        mlt_long = member_info.mlt_long

                    # 사용자 위치로 주소 가져오기
                    coords = f"{mlt_long},{mlt_lat}"
                    user_add = get_latlong_to_add_naver(coords)

                    # 주소에서 시도, 구, 동 정보 추출
                    mt_sido = user_add["area1"]
                    mt_gu = user_add["area2"]
                    mt_dong = user_add["area3"]

                    # 멤버 정보 업데이트
                    member = member_t.find_one_idx(mt_idx=pt.mt_idx)
                    if member:
                        member.mt_lat = mlt_lat
                        member.mt_long = mlt_long
                        member.mt_sido = mt_sido
                        member.mt_gu = mt_gu
                        member.mt_dong = mt_dong
                        member.mt_udate = (
                            datetime.datetime.now()
                        )  # 현재 시각으로 업데이트
                        db.session.commit()  # 변경 사항을 커밋
                    else:
                        logger.error(f"No member found with mt_idx {pt.mt_idx}")

                except Exception as e:
                    logger.error(f"Error updating member {pt.mt_idx}: {e}")

    # 매일 0시 내장소 진입 후 이탈로 업데이트 되지 않은 건 강제 업데이트
    def ps_16():
        from smap.models import smap_location_t
        from smap.apis.lib_func import get_latlong_to_add_naver
        import logging
        import datetime

        with app.app_context():
            plt_condition = "매일 00시"
            plt_memo = "모든 고객 내장소 초기화"
            push_list = smap_location_t.getOutMyplaysList()

            for pt in push_list:
                if not pt is None:
                    if pt.slt_enter_alarm == "Y":
                        try:
                            # 진입여부 수정
                            location_result = location_status_update(pt.slt_idx, "N")
                        except Exception as e:
                            logger.error("[ps_16][" + pt.mt_idx + "] - " + e)
                            admin_send_push("[ps_16][" + pt.mt_idx + "] - " + e)

    def ps_17():
        logger.info(f"ps_17 로그확인 push 실행")
        from smap.models import smap_group_detail_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            messages = [
                {
                    "title": "오늘의 그룹원 동향 리포트 📊",
                    "content": "그룹원들의 하루 동선이 궁금하신가요?\n로그에서 모든 것을 확인하세요! 🚶‍♀️",
                },
                {
                    "title": "그룹원들의 일상 탐험 📝",
                    "content": "그룹원들의 오늘 하루는 어땠을까요? \n로그에서 힌트를 찾아보세요!🕵️‍♂️",
                },
                {
                    "title": "일상의 기록 📸",
                    "content": "그룹원들의 하루가 로그에 담겼어요.\n로그를 통해 그들의 발자취를 따라가 보세요! 🌟",
                },
                {
                    "title": "그룹원들의 하루 타임라인 ⏱️",
                    "content": "시간별로 그룹원들의 활동을 정리했어요.\n오늘 하루는 어떻게 흘러갔는지 로그에서 확인하세요! 🕰️",
                },
            ]

            plt_condition = "로그확인 push 발송"
            plt_memo = "로그확인 push 발송"

            member_list = smap_group_detail_t.get_owner_leader_list()
            logger.info(member_list)
            selected_message = random.choice(messages)
            logger.info(selected_message)
            push_title = selected_message["title"]
            push_content = selected_message["content"]
            push_txt = push_content
            push_url = "https://app2.smap.site/log"

            for member in member_list:
                try:
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_18():
        from smap.models import smap_group_detail_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            logger.info(f"ps_18 내장소 입력 독려 push 실행")

            messages = [
                {
                    "title": "실시간 위치 알리미 🗺️",
                    "content": "'내 장소'에 관심 지역을 등록하세요!\n그룹원이 100m 반경에 들어오면 바로 알려드려요. 📍",
                },
                {
                    "title": "스마트한 그룹 관리의 시작 🏠",
                    "content": "'내 장소' 기능으로 그룹원 동향을\n 실시간 알림으로 받아보세요! 🚶‍♀️",
                },
                {
                    "title": "그룹원 동향을 한눈에! 👀",
                    "content": "'내 장소'를 설정하고 스마트하게 관리하세요.\n100m 반경 내 그룹원 출입 시 알림을 받을 수 있어요. 🔔",
                },
                {
                    "title": "위치 기반 알림으로 똑똑하게 🌟",
                    "content": "중요한 장소를 '내 장소'로 등록해보세요.\n그룹원의 출입을 실시간으로 확인할 수 있어요! 🏃‍♂️💨",
                },
                {
                    "title": "스마트한 그룹원 관리 📱",
                    "content": "'내 장소'에 중요 지점을 등록하세요.\n그룹원이 등록한 장소에 오면 바로 알려드립니다! 🌟",
                },
            ]

            plt_condition = "내장소 입력 독려 push 발송"
            plt_memo = "내장소 입력 독려 push 발송"

            member_list = smap_group_detail_t.get_my_location_list()

            selected_message = random.choice(messages)
            push_title = selected_message["title"]
            push_content = selected_message["content"]
            push_txt = push_content
            # push_url = "https://youtube.com/shorts/D8viipY-xrU?feature=share"
            push_url = "https://app2.smap.site/location"

            for member in member_list:
                try:
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_19():
        from smap.models import member_location_log_t
        from smap.apis.lib_func import kmTom, send_push, get_group_member
        import random

        with app.app_context():
            logger.info(f"ps_19 앱 한번 실행해줍쇼. push 실행")

            messages = [
                {
                    "title": "중요한 순간을 놓치지 마세요! ⏰",
                    "content": "위치 접근을 '항상 허용'으로 설정하면 더 정확하게 기록할 수 있어요.",
                },
                {
                    "title": "끊김 없는 연결을 경험해보세요! 🔗",
                    "content": "위치 접근을 '항상 허용'으로 설정하면 앱이 더 원활하게 작동해요.",
                },
                {
                    "title": "앗, 기록이 중단됐어요! 😥",
                    "content": "위치 접근을 '항상 허용'으로 바꾸면 기록이 끊기지 않아요!",
                },
                {
                    "title": "정확한 알림을 받고 싶으신가요? 🔔",
                    "content": "위치 접근을 '항상 허용'으로 바꾸거나 앱을 자주 실행해주세요!",
                },
                {
                    "title": "알림이 오지 않나요? 🤔",
                    "content": "위치 접근을 '항상 허용'으로 설정하거나 앱을 자주 실행해보세요.",
                },
                {
                    "title": "위치 정보 업데이트! 🔄",
                    "content": "정확한 알림을 위해 위치 접근을 '항상 허용'으로 설정해주세요.",
                },
            ]

            plt_condition = "앱 한번 실행해줍쇼. push 발송"
            plt_memo = "앱 한번 실행해줍쇼. push 발송"

            member_list = member_location_log_t.find_members_with_outdated_location()

            selected_message = random.choice(messages)
            push_title = selected_message["title"]
            push_content = selected_message["content"]
            push_txt = push_content
            # push_url = "https://youtube.com/shorts/D8viipY-xrU?feature=share"
            push_url = "https://app2.smap.site/log"

            for member in member_list:
                try:
                    push_result = send_push(
                        member.mt_token_id, push_title, push_content, push_url
                    )
                    push_log_add(
                        member.mt_idx,
                        None,
                        plt_condition,
                        plt_memo,
                        push_title,
                        push_txt,
                        push_result,
                    )
                except Exception as e:
                    log_error(
                        f"Error sending push notification to member {member.mt_idx}: {e}"
                    )

    def ps_20():
        from smap.models import member_location_log_t, member_t
        from smap import db
        import logging

        with app.app_context():
            logger.info("ps_20 member_location_log_t와 member_t 동기화 실행")

            try:
                # 최근 1시간 이내에 위치 데이터가 있는 멤버 찾기
                one_hour_ago = datetime.datetime.now() - datetime.timedelta(hours=1)
                active_members = member_location_log_t.query.filter(
                    member_location_log_t.mlt_wdate >= one_hour_ago
                ).order_by(member_location_log_t.mlt_idx.desc()).all()

                for member_log in active_members:
                    # 해당 멤버의 가장 최근 위치 정보 가져오기
                    latest_location = member_location_log_t.query.filter_by(mt_idx=member_log.mt_idx).order_by(member_location_log_t.mlt_idx.desc()).first()

                    if latest_location:
                        # Member_t 테이블에서 해당 멤버 찾기
                        member = member_t.find_one_idx(mt_idx=latest_location.mt_idx)

                        if member:
                            # 멤버 정보 업데이트
                            member.mt_lat = latest_location.mlt_lat
                            member.mt_long = latest_location.mlt_long
                            member.mt_udate = dt.now()  # Use the alias dt

                            db.session.commit()
                            logger.info(f"멤버 {member.mt_idx}의 위치 정보가 업데이트되었습니다.")
                        else:
                            logger.warning(f"멤버 {latest_location.mt_idx}를 찾을 수 없습니다.")
                    else:
                        logger.warning(f"멤버 {member_log.mt_idx}의 최신 위치 정보를 찾을 수 없습니다.")

                logger.info("ps_20 동기화가 완료되었습니다.")

            except Exception as e:
                logger.error(f"ps_20 동기화 중 오류 발생: {str(e)}")
                db.session.rollback()


    

    def log_error(error):
        logger.error(error)

    def admin_send_push(msg):
        from smap.models import member_t

        try:
            admin = member_t.find_one_idx(272)
            logger.info(f"admin_send_push - admin : {admin}")
            push_result = send_push(
                admin.mt_token_id, "Error Msg", msg, "https://app2.smap.site/log"
            )
        except Exception as e:
            log_error(f"Error sending push notification to admin: {e}")
            pass

    def split_list(lst, n):
        """리스트를 n개의 하위 리스트로 분할합니다."""
        k, m = divmod(len(lst), n)
        return [lst[i * k + min(i, m) : (i + 1) * k + min(i + 1, m)] for i in range(n)]

    def send_push_to_group(group, message, plt_condition, plt_memo, push_url):
        from smap.models import smap_group_detail_t

        """그룹에 푸시 알림을 보냅니다."""
        push_title = message["title"]
        push_content = message["content"]
        push_txt = push_content

        for member in group:
            try:
                push_result = send_push(
                    member.mt_token_id, push_title, push_content, push_url
                )
                push_log_add(
                    member.mt_idx,
                    None,
                    plt_condition,
                    plt_memo,
                    push_title,
                    push_txt,
                    push_result,
                )
            except Exception as e:
                log_error(
                    f"Error sending push notification to member {member.mt_idx}: {e}"
                )

    def schedule_push_notifications(func, hour, minute, job_id_prefix):
        """푸시 알림을 예약합니다."""
        with app.app_context():
            messages, plt_condition, plt_memo, push_url = func()

            if func.__name__ == "ps_17":
                member_list = smap_group_detail_t.get_owner_leader_list()
            elif func.__name__ == "ps_18":
                member_list = smap_group_detail_t.get_my_location_list()
            else:
                logger.error(f"Unknown function: {func.__name__}")
                return

            groups = split_list(list(member_list), 10)

            for i, group in enumerate(groups):
                scheduled_time = datetime.now().replace(
                    hour=int(hour), minute=int(minute)
                ) + timedelta(minutes=i * 10)
                message = random.choice(messages)
                schedule.add_job(
                    send_push_to_group,
                    "date",
                    run_date=scheduled_time,
                    args=[group, message, plt_condition, plt_memo, push_url],
                    id=f"{job_id_prefix}_{i}",
                )

    schedule = BackgroundScheduler(daemon=True, timezone="Asia/Seoul")
    schedule.add_job(ps_1, "interval", seconds=30, id="ps_1")
    schedule.add_job(ps_2, "interval", seconds=30, id="ps_2")
    schedule.add_job(ps_3, "interval", seconds=30, id="ps_3")
    schedule.add_job(ps_4, "interval", seconds=30, id="ps_4")
    schedule.add_job(ps_5, "interval", minutes=1, id="ps_5")
    schedule.add_job(ps_6, "cron", minute="*/5", id="ps_6")
    # schedule.add_job(ps_7, 'cron', hour="20", minute="00", id='ps_7')
    # schedule.add_job(ps_8, 'cron', hour="10", minute="00", id='ps_8')
    # 평일 (월요일부터 금요일) 오전 8시 10분에 실행
    schedule.add_job(
        ps_9, "cron", day_of_week="mon-fri", hour=8, minute=10, id="ps_9_weekdays"
    )
    # 주말 (토요일과 일요일) 오전 9시에 실행
    schedule.add_job(ps_9, "cron", day_of_week="sat,sun", hour=9, id="ps_9_weekends")
    logging.info("Scheduled job ps_9: 오전 7시 - 날씨 - 해당일 일기예보 발송")
    schedule.add_job(ps_10, "interval", hours=1, id="ps_10")
    schedule.add_job(ps_11, "interval", hours=1, id="ps_11")
    schedule.add_job(ps_12, "cron", hour="21", minute="00", id="ps_12")
    schedule.add_job(ps_13, "interval", hours=1, id="ps_13")
    schedule.add_job(ps_14, "cron", hour="*/1", id="ps_14")
    schedule.add_job(
        ps_15, "cron", minute="*/20", hour="8-19", id="ps_15"
    )  # Run every 20 minutes from 8 AM to 5:59 PM
    schedule.add_job(ps_16, "cron", hour="0", minute="0", id="ps_16")
    # 작업 예약 - 매 정각마다, 오전 8시부터 오후 6시까지만 실행
    schedule.add_job(ps_17, "cron", hour="18", minute="00", id="ps_17_18")  # 로그
    schedule.add_job(ps_18, "cron", hour="14", minute="00", id="ps_18_14")  # 내장소
    schedule.add_job(ps_19, "cron", hour="19", minute="30", id="ps_18_11")  # 앱실행
    schedule.add_job(ps_20, "interval", seconds=30, id="ps_20") # 위치 동기화

    # Start the scheduler
    schedule.start()

    """Request Json Error"""

    def on_json_loading_failed_return_dict(e):
        return {}

    """REQUEST HOOK"""

    @app.before_request
    def before_request():
        session.permanent = True
        app.permanent_session_lifetime = timedelta(hours=24)

        request.on_json_loading_failed = on_json_loading_failed_return_dict
        g.db = db.session
        g.config = config

    @app.teardown_request
    def teardown_request(exception):
        if hasattr(g, "db"):
            g.db.close()

    @app.errorhandler(404)
    def page_404(error):
        return render_template("/404.html"), 404

    @app.errorhandler(502)
    def page_502(error):
        return render_template("/502.html"), 502

    @app.route("/popup")
    def popup():
        logger.info(f"popup redirect")
        return render_template("popup.html")  # 또는 필요한 로직 실행

    return app
