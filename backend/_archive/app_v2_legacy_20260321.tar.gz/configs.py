import os

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

class Config:
    """Flask Config"""
    APP_TITLE = 'SMAP PYTHON APIS'
    # https://acte.ltd/utils/randomkeygen
    # Encryption key 256 사용
    SECRET_KEY = '88XPDw6QzwQ8FsOOTsJbkvNBIgQmpZxA'
    SESSION_COOKIE_NAME ='smap'
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_pre_ping": True,
        "pool_recycle": 300
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    CACHE_VAL = '2023122601'
    FCM_JSON_PATH = os.path.join(BASE_PATH, "com-dmonster-smap-firebase-adminsdk-2zx5p-2610556cf5.json")
    NCPCLIENTID = 'unxdi5mt3f'
    NCPCLIENTSECRET = 'bKRzkFBbAvfdHDTZB0mJ81jmO8ufULvQavQIQZmp'
    GOOGLE_MAPS_API_KEY = 'AIzaSyBkWlND5fvW4tmxaj11y24XNs_LQfplwpw' #com.dmonster.smap
    OPENWEATHERMAP_API_KEY = '8c90a084ccacf6542289b4d4ee1149a6'
    # SERVICE_KEY = "S26r1Nboahpi0EPnPCY5FKXnMeUSSXm9QRO1WSKvQewZ/HpvdiOvn+NIGw+SacenccO4ElydjH7tcBLnCUQygw=="
    SERVICE_KEY = "eu848OhHKYBTXESTOJk2Zvd2dkcvSgkW/5/w4bN3Doo/FKEjD/zuQLsjVFk4Uwn9KbIUYdvNcbXR1MB9IFHy6w=="

class DevelopmentConfig(Config):
    """Flask Config for dev"""
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://smap2:dmonster@118.67.130.71:3306/smap2_db?charset=utf8mb4'

class TestingConfig(DevelopmentConfig):
    __test__ = False
    TESTING = True
    SQLALCHEMY_DATABASE_URI = f'sqlite:///{os.path.join(BASE_PATH, "sqlite_test.db")}'

class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://smap2:dmonster@localhost:3306/smap2_db?charset=utf8mb4'
    pass
